import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requireAuth } from '@/lib/auth';
import { hashPassword } from '@/lib/security';
import type { Prisma } from '@prisma/client';

export async function POST(request: NextRequest) {
  try {
    const session = await requireAuth();
    if (session.role !== 'SUPER_ADMIN') {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
    }

    const body = await request.json();
    const { action } = body;

    if (action === 'CREATE') {
      const { name, email, password, role } = body;
      if (!name || !email || !password || !role) {
        return NextResponse.json({ error: 'All fields are required.' }, { status: 400 });
      }

      const existingUser = await prisma.user.findUnique({ where: { email } });
      if (existingUser) {
        return NextResponse.json({ error: 'Email address already in use.' }, { status: 400 });
      }

      const newUser = await prisma.user.create({
        data: {
          name,
          email,
          password: hashPassword(password),
          role,
          isActive: true,
        },
      });

      await prisma.auditLog.create({
        data: {
          userId: session.userId,
          action: 'CREATE_USER',
          module: 'USER_MANAGEMENT',
          description: `Created new user account: ${email} (${role})`,
        },
      });

      return NextResponse.json({ success: true, userId: newUser.id });
    }

    if (action === 'UPDATE') {
      const { userId, name, email, password, role } = body;
      if (!userId || !name || !email || !role) {
        return NextResponse.json({ error: 'All fields except password are required for update.' }, { status: 400 });
      }

      const existingUser = await prisma.user.findUnique({ where: { id: userId } });
      if (!existingUser) {
        return NextResponse.json({ error: 'User not found.' }, { status: 404 });
      }

      // Check if email conflicts with another user
      const emailConflict = await prisma.user.findFirst({
        where: {
          email,
          id: { not: userId }
        }
      });
      if (emailConflict) {
        return NextResponse.json({ error: 'Email address already in use by another account.' }, { status: 400 });
      }

      const updateData: Prisma.UserUpdateInput = {
        name,
        email,
        role
      };

      if (password && password.trim() !== '') {
        updateData.password = hashPassword(password);
      }

      await prisma.user.update({
        where: { id: userId },
        data: updateData
      });

      await prisma.auditLog.create({
        data: {
          userId: session.userId,
          action: 'UPDATE_USER',
          module: 'USER_MANAGEMENT',
          description: `Updated account details for: ${email} (${role})`,
        },
      });

      return NextResponse.json({ success: true });
    }

    if (action === 'DELETE') {
      const { userId } = body;
      if (!userId) {
        return NextResponse.json({ error: 'User ID is required.' }, { status: 400 });
      }

      if (userId === session.userId) {
        return NextResponse.json({ error: 'You cannot delete your own account.' }, { status: 400 });
      }

      const userToDelete = await prisma.user.findUnique({ where: { id: userId } });
      if (!userToDelete) {
        return NextResponse.json({ error: 'User not found.' }, { status: 404 });
      }

      await prisma.user.delete({ where: { id: userId } });

      await prisma.auditLog.create({
        data: {
          userId: session.userId,
          action: 'PERMANENT_DELETE_USER',
          module: 'USER_MANAGEMENT',
          description: `Permanently deleted user account: ${userToDelete.email} (${userToDelete.role})`,
        },
      });

      return NextResponse.json({ success: true });
    }

    if (action === 'TOGGLE_ACTIVE') {
      const { userId, isActive } = body;
      if (!userId || typeof isActive !== 'boolean') {
        return NextResponse.json({ error: 'Invalid parameters.' }, { status: 400 });
      }

      if (userId === session.userId) {
        return NextResponse.json({ error: 'Cannot update your own active status.' }, { status: 400 });
      }

      const user = await prisma.user.update({
        where: { id: userId },
        data: { isActive },
      });

      await prisma.auditLog.create({
        data: {
          userId: session.userId,
          action: isActive ? 'ACTIVATE_USER' : 'DEACTIVATE_USER',
          module: 'USER_MANAGEMENT',
          description: `${isActive ? 'Activated' : 'Deactivated'} user account: ${user.email}`,
        },
      });

      return NextResponse.json({ success: true });
    }

    return NextResponse.json({ error: 'Invalid action.' }, { status: 400 });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : 'Server error' }, { status: 500 });
  }
}
