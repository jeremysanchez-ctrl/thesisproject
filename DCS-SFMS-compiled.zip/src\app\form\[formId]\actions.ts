'use server';

import { revalidatePath } from 'next/cache';
import fs from 'fs';
import path from 'path';
import { prisma } from '@/lib/prisma';

export type FormState = {
  success: boolean;
  error: string;
  submissionCount: number;
  controlNo?: string;
};

export async function submitSurvey(prevState: FormState, formData: FormData): Promise<FormState> {
  const formId = formData.get('_formId') as string;
  let stakeholderCategoryId = formData.get('_stakeholderCategoryId') as string;

  // Fallback to native clientType radio button if React state/hidden input failed to synchronize
  if (!stakeholderCategoryId) {
    stakeholderCategoryId = formData.get('clientType') as string;
  }

  if (!formId || !stakeholderCategoryId) {
    return { success: false, error: 'Please select a Client Type.', submissionCount: prevState.submissionCount };
  }

  const form = await prisma.surveyForm.findUnique({
    where: { id: formId },
    include: { Questions: { select: { id: true } } },
  });
  const now = new Date();
  if (!form || form.status !== 'ACTIVE' || (form.scheduledStart && form.scheduledStart > now) || (form.scheduledEnd && form.scheduledEnd < now)) {
    return { success: false, error: 'This survey is not currently accepting responses.', submissionCount: prevState.submissionCount };
  }

  const category = await prisma.stakeholderCategory.findUnique({ where: { id: stakeholderCategoryId }, select: { id: true } });
  if (!category) {
    return { success: false, error: 'Select a valid stakeholder category.', submissionCount: prevState.submissionCount };
  }

  const allowedQuestionIds = new Set(form.Questions.map((question) => question.id));
  const answers = [...formData.keys()]
    .filter((key, index, keys) => key.startsWith('question_') && keys.indexOf(key) === index)
    .map((key) => ({
      questionId: key.replace('question_', ''),
      answerValue: formData.getAll(key).map(String).join(' | '),
    }))
    .filter((answer) => allowedQuestionIds.has(answer.questionId) && answer.answerValue);

  const data = Object.fromEntries(formData.entries());

  // Generate unique control number server-side (Req #2)
  const dateStr = now.getFullYear().toString() +
    String(now.getMonth() + 1).padStart(2, '0') +
    String(now.getDate()).padStart(2, '0');
  const randomSuffix = Math.random().toString(36).substring(2, 8).toUpperCase();
  const generatedControlNo = `SFMS-${dateStr}-${randomSuffix}`;

  // Format date of visit automatically in PHT/locale format (Req #3)
  const autoDateOfVisit = now.toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  // Handle uploaded hard copy photo if provided
  let hardCopyPhotoUrl: string | null = null;
  const photoEntry = formData.get('hardCopyPhoto');
  if (photoEntry && typeof photoEntry === 'object' && 'arrayBuffer' in photoEntry) {
    const file = photoEntry as File;
    if (file.size > 0 && file.name) {
      try {
        const bytes = await file.arrayBuffer();
        const buffer = Buffer.from(bytes);
        const uploadDir = path.join(process.cwd(), 'public', 'uploads');
        await fs.promises.mkdir(uploadDir, { recursive: true });
        const ext = path.extname(file.name) || '.jpg';
        const cleanBase = path.basename(file.name, ext).replace(/[^a-zA-Z0-9_-]/g, '_').slice(0, 30);
        const filename = `hardcopy-${Date.now()}-${randomSuffix}-${cleanBase}${ext}`;
        const filePath = path.join(uploadDir, filename);
        await fs.promises.writeFile(filePath, buffer);
        hardCopyPhotoUrl = `/uploads/${filename}`;
      } catch (err) {
        console.error('Failed to save hard copy photo:', err);
      }
    }
  }

  // Handle drawn e-signature if provided (base64 data URL)
  let signatureUrl: string | null = null;
  const signatureData = formData.get('signatureData')?.toString();
  if (signatureData && signatureData.startsWith('data:image/png;base64,')) {
    try {
      const base64Data = signatureData.replace(/^data:image\/png;base64,/, '');
      const buffer = Buffer.from(base64Data, 'base64');
      const uploadDir = path.join(process.cwd(), 'public', 'uploads', 'signatures');
      await fs.promises.mkdir(uploadDir, { recursive: true });
      const filename = `sig-${Date.now()}-${randomSuffix}.png`;
      const filePath = path.join(uploadDir, filename);
      await fs.promises.writeFile(filePath, buffer);
      signatureUrl = `/uploads/signatures/${filename}`;
    } catch (err) {
      console.error('Failed to save e-signature:', err);
    }
  }

  try {
    await prisma.response.create({
      data: {
        formId,
        stakeholderCategoryId,
        controlNo: generatedControlNo,
        agency: data.agency?.toString() || data.organization?.toString() || null,
        organization: data.agency?.toString() || data.organization?.toString() || null,
        serviceAvailed: data.serviceAvailed?.toString() || null,
        name: data.name?.toString() || null,
        email: data.email?.toString() || null,
        contactNumber: data.contactNumber?.toString() || null,
        purposeOfVisit: data.purposeOfVisit?.toString() || null,
        attendingStaff: data.attendingStaff?.toString() || null,
        department: data.department?.toString() || null,
        hardCopyPhotoUrl,
        signatureUrl,
        dateOfVisit: autoDateOfVisit,
        sex: data.sex?.toString() || null,
        age: data.age?.toString() || null,
        transactionDate: autoDateOfVisit,
        submittedAt: now,
        Answers: { create: answers },
      },
    });
  } catch (error) {
    return { success: false, error: 'Database error occurred: ' + (error instanceof Error ? error.message : String(error)), submissionCount: prevState.submissionCount };
  }

  revalidatePath('/admin/dashboard');
  revalidatePath('/admin/reports');

  return { success: true, error: '', submissionCount: prevState.submissionCount + 1, controlNo: generatedControlNo };
}
