var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/report-requests/route.js")
R.c("server/chunks/[root-of-the-server]__0i-2ocx._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_0htkyro._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_report-requests_route_actions_1yuivq0.js")
R.m(9094)
module.exports=R.m(9094).exports
