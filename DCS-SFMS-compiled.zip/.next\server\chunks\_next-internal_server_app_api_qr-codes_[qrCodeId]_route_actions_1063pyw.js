module.exports=[28022,(__turbopack_context__,module1,exports)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_qr-codes_%5BqrCodeId%5D_route_actions_1063pyw.js.map