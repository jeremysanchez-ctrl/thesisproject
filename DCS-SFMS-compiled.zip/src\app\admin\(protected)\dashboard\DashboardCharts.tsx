'use client';

import {
  ArcElement,
  BarElement,
  CategoryScale,
  Chart as ChartJS,
  Legend,
  LinearScale,
  Tooltip,
} from 'chart.js';
import { Bar, Doughnut } from 'react-chartjs-2';
import type { DashboardData } from '@/lib/analytics';

ChartJS.register(CategoryScale, LinearScale, BarElement, ArcElement, Tooltip, Legend);

const chartOptions = {
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    legend: { labels: { color: '#737373', boxWidth: 12, font: { size: 11, weight: 'bold' as const } } },
  },
  scales: {
    x: { ticks: { color: '#737373', font: { size: 10, weight: 'bold' as const } }, grid: { color: '#f1f1f1' } },
    y: { beginAtZero: true, ticks: { color: '#737373', precision: 0, font: { size: 10 } }, grid: { color: '#f1f1f1' } },
  },
};

// Monochrome ramp (light theme default; charts don't re-render on theme flip instantly)
const palette = ['#0a0a0a', '#4d4d4d', '#8f8f8f', '#bdbdbd', '#2b2b2b', '#6b6b6b'];

export default function DashboardCharts({ data }: { data: DashboardData }) {

  // 1. Number of Respondents per Semester
  const semesterChartData = {
    labels: data.respondentsPerSemester.map((s) => s.semester),
    datasets: [
      {
        label: 'Number of Respondents',
        data: data.respondentsPerSemester.map((s) => s.count),
        backgroundColor: ['#0a0a0a', '#4d4d4d', '#8f8f8f'],
        borderRadius: 4,
      },
    ],
  };

  // 2. Purpose of Visit per Semester
  const allPurposes = Array.from(
    new Set(data.purposePerSemester.flatMap((s) => s.purposes.map((p) => p.purpose)))
  );

  const purposePerSemesterChartData = {
    labels: data.purposePerSemester.map((s) => s.semester),
    datasets: allPurposes.map((purpose, index) => ({
      label: purpose,
      data: data.purposePerSemester.map((s) => {
        const found = s.purposes.find((p) => p.purpose === purpose);
        return found ? found.count : 0;
      }),
      backgroundColor: palette[index % palette.length],
      borderRadius: 3,
    })),
  };

  // 3. Most and Least Satisfied Concerns
  const questionLabels = [
    ...data.questionSatisfaction.mostSatisfied.map((q) => `★ ${q.question.slice(0, 25)}...`),
    ...data.questionSatisfaction.leastSatisfied.map((q) => `· ${q.question.slice(0, 25)}...`),
  ];
  const questionScores = [
    ...data.questionSatisfaction.mostSatisfied.map((q) => q.average),
    ...data.questionSatisfaction.leastSatisfied.map((q) => q.average),
  ];
  const questionBarColors = [
    ...data.questionSatisfaction.mostSatisfied.map(() => '#0a0a0a'),
    ...data.questionSatisfaction.leastSatisfied.map(() => '#8f8f8f'),
  ];

  const satisfactionConcernsChartData = {
    labels: questionLabels.length === 0 ? ['No Ratings Yet'] : questionLabels,
    datasets: [
      {
        label: 'Average Score (out of 5)',
        data: questionScores.length === 0 ? [0] : questionScores,
        backgroundColor: questionBarColors.length === 0 ? ['#e5e5e5'] : questionBarColors,
        borderRadius: 4,
      },
    ],
  };

  // 4. Demographics / Stakeholder Distribution
  const stakeholderChartData = {
    labels: data.stakeholderBreakdown.map((item) => item.name),
    datasets: [
      {
        label: 'Respondents',
        data: data.stakeholderBreakdown.map((item) => item.count),
        backgroundColor: palette,
      },
    ],
  };

  const panel: React.CSSProperties = {
    background: 'var(--gray-50)',
    border: 'var(--hairline)',
    borderRadius: 'var(--radius-lg)',
    padding: '1.5rem',
    boxShadow: 'var(--shadow-card)',
    minWidth: 0,
  };
  const heading: React.CSSProperties = {
    fontFamily: 'var(--font-mono)',
    fontSize: '0.9375rem',
    fontWeight: 600,
    margin: '0 0 0.25rem',
    color: 'var(--ink)',
  };
  const sub: React.CSSProperties = {
    color: 'var(--gray-500)',
    fontSize: '0.8125rem',
    margin: '0 0 1rem',
  };

  return (
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(420px, 1fr))', gap: '1rem' }}>

      {/* 1. Respondents per Semester */}
      <section style={panel}>
        <h2 style={heading}>Number of Respondents per Semester</h2>
        <p style={sub}>Actual respondent volume across academic semesters from live database records.</p>
        <div style={{ height: '300px' }}>
          <Bar data={semesterChartData} options={chartOptions} />
        </div>
      </section>

      {/* 2. Purpose of Visit per Semester */}
      <section style={panel}>
        <h2 style={heading}>Purpose of Visit per Semester</h2>
        <p style={sub}>Distribution of visit reasons grouped by academic semester.</p>
        <div style={{ height: '300px' }}>
          <Bar data={purposePerSemesterChartData} options={chartOptions} />
        </div>
      </section>

      {/* 3. Most and Least Satisfied Concerns */}
      <section style={{ ...panel, gridColumn: '1 / -1' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '0.5rem', marginBottom: '1rem' }}>
          <div>
            <h2 style={{ ...heading, margin: 0 }}>Most and Least Satisfied Concerns</h2>
            <p style={{ ...sub, margin: '0.15rem 0 0' }}>
              Comparison of highest-rated (◆) vs lowest-rated (·) survey questions.
            </p>
          </div>
          <div style={{ display: 'flex', gap: '1rem', fontSize: '0.8125rem', fontFamily: 'var(--font-mono)' }}>
            <span style={{ color: '#0a0a0a' }}>■ High Satisfaction (4.0+)</span>
            <span style={{ color: '#8f8f8f' }}>■ Low Satisfaction / Concern</span>
          </div>
        </div>
        <div style={{ height: '320px' }}>
          <Bar
            data={satisfactionConcernsChartData}
            options={{
              ...chartOptions,
              scales: {
                ...chartOptions.scales,
                y: { beginAtZero: true, max: 5, ticks: { stepSize: 1, color: '#737373' } },
              },
            }}
          />
        </div>
      </section>

      {/* 4. Demographics & Stakeholder Mix */}
      <section style={panel}>
        <h2 style={heading}>Stakeholder Demographics Breakdown</h2>
        <p style={sub}>Real-time proportion of respondents by stakeholder group.</p>
        <div style={{ height: '300px' }}>
          <Doughnut
            data={stakeholderChartData}
            options={{ responsive: true, maintainAspectRatio: false, plugins: chartOptions.plugins }}
          />
        </div>
      </section>

    </div>
  );
}