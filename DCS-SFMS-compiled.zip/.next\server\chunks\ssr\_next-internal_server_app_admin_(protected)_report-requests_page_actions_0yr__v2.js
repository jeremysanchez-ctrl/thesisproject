module.exports=[71907,(__turbopack_context__,module1,exports)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_%28protected%29_report-requests_page_actions_0yr__v2.js.map