module.exports=[79543,(__turbopack_context__,module1,exports)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_auth_logout_route_actions_0regwyr.js.map