import { prisma } from '@/lib/prisma';
import { requireAuth } from '@/lib/auth';
import { redirect } from 'next/navigation';
import PageGuideNote from '@/components/PageGuideNote';
import UserManagementClient from './UserManagementClient';

export default async function UsersPage() {
  const session = await requireAuth();
  if (session.role !== 'SUPER_ADMIN') {
    redirect('/admin/dashboard');
  }

  const users = await prisma.user.findMany({
    select: { id: true, name: true, email: true, role: true, isActive: true, createdAt: true },
    orderBy: { createdAt: 'asc' }
  });

  return (
    <div className="content-wrap" style={{ display: 'grid', gap: '1.75rem' }}>
      <header className="rise">
        <span className="num-label">07 — user management</span>
        <h1 className="page-title" style={{ fontSize: 'clamp(1.8rem, 4vw, 2.6rem)' }}>System Users &amp; Admin Accounts</h1>
        <p className="page-desc">
          Create accounts, assign roles, and manage access permissions for system administrators.
        </p>
      </header>

      <PageGuideNote
        pageTitle="User Management"
        overview="Super Administrators can create and manage system accounts for other administrators, department heads, and quality assurance officers. Role assignment determines what features and data each account can access."
        steps={[
          { title: 'SUPER_ADMIN Role', description: 'Full access: Manage users, approve reports, archive/restore forms, view all logs.' },
          { title: 'ADMIN Role', description: 'Manage forms, QR codes, view reports, request report generation.' },
          { title: 'DEPT_HEAD / QA_OFFICER', description: 'View dashboard and respond to department reports as appropriate.' }
        ]}
      />

      <div className="rise rise-1">
        <UserManagementClient users={users} currentUserId={session.userId} />
      </div>
    </div>
  );
}