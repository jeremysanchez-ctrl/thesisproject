'use server';

import { randomUUID } from 'crypto';
import { revalidatePath } from 'next/cache';
import { requireAuth } from '@/lib/auth';
import { prisma } from '@/lib/prisma';

export async function createQRCode(eventId: string, expiresAt?: string) {
  const session = await requireAuth();
  if (!['SUPER_ADMIN', 'ADMIN'].includes(session.role)) {
    throw new Error('FORBIDDEN');
  }

  const event = await prisma.event.findUnique({ where: { id: eventId }, select: { id: true, name: true } });
  if (!event) {
    throw new Error('Select a valid event.');
  }

  const expiry = expiresAt ? new Date(expiresAt) : null;
  if (expiry && (Number.isNaN(expiry.getTime()) || expiry <= new Date())) {
    throw new Error('Expiration must be a future date and time.');
  }

  const qrCode = await prisma.qRCode.create({
    data: {
      eventId: event.id,
      codeString: randomUUID(),
      expiresAt: expiry,
    },
  });

  await prisma.auditLog.create({
    data: {
      userId: session.userId,
      action: 'CREATE_QR_CODE',
      module: 'QR_CODES',
      description: `Created QR code for event ${event.name}.`,
    },
  });

  revalidatePath('/admin/qr-codes');
  return qrCode.id;
}

export async function archiveQRCode(qrCodeId: string) {
  const session = await requireAuth();
  if (!['SUPER_ADMIN', 'ADMIN'].includes(session.role)) {
    throw new Error('FORBIDDEN');
  }

  const qrCode = await prisma.qRCode.findUnique({ where: { id: qrCodeId }, select: { id: true, event: { select: { name: true } } } });
  if (!qrCode) {
    throw new Error('QR code not found.');
  }

  await prisma.qRCode.update({
    where: { id: qrCodeId },
    data: { archivedAt: new Date() },
  });

  await prisma.auditLog.create({
    data: {
      userId: session.userId,
      action: 'ARCHIVE_QR_CODE',
      module: 'QR_CODES',
      description: `Archived QR code for event ${qrCode.event.name}.`,
    },
  });

  revalidatePath('/admin/qr-codes');
}
