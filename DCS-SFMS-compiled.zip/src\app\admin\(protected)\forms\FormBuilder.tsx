'use client';

import { useState } from 'react';
import { createForm, type FormDraft, type QuestionDraft } from './actions';

type Category = { id: string; name: string };

const questionTypes: { value: QuestionDraft['questionType']; label: string }[] = [
  { value: 'LIKERT', label: 'Likert scale' },
  { value: 'MULTIPLE_CHOICE', label: 'Multiple choice' },
  { value: 'CHECKBOXES', label: 'Checkboxes' },
  { value: 'TEXT', label: 'Text response' },
  { value: 'YES_NO', label: 'Yes / No' },
  { value: 'RATING', label: 'Rating scale' },
];

const defaultOptions: Record<QuestionDraft['questionType'], string[]> = {
  LIKERT: ['Strongly agree', 'Agree', 'Neither agree nor disagree', 'Disagree', 'Strongly disagree'],
  MULTIPLE_CHOICE: ['Option 1', 'Option 2'],
  CHECKBOXES: ['Option 1', 'Option 2'],
  TEXT: [],
  YES_NO: [],
  RATING: [],
};

const emptyQuestion = (): QuestionDraft => ({
  questionText: '',
  questionType: 'LIKERT',
  options: defaultOptions.LIKERT,
});

export default function FormBuilder({ categories }: { categories: Category[] }) {
  const [draft, setDraft] = useState<FormDraft>({
    title: '',
    academicYear: 'AY 2026–2027',
    semester: 'First Semester',
    version: 1,
    eventName: '',
    department: 'Computer Studies Department',
    stakeholderCategoryId: categories[0]?.id ?? '',
    status: 'DRAFT',
    questions: [emptyQuestion()],
  });
  const [isSaving, setIsSaving] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const updateDraft = <Key extends keyof FormDraft>(key: Key, value: FormDraft[Key]) => {
    setDraft((current) => ({ ...current, [key]: value }));
  };

  const updateQuestion = (index: number, update: Partial<QuestionDraft>) => {
    setDraft((current) => ({
      ...current,
      questions: current.questions.map((question, questionIndex) =>
        questionIndex === index ? { ...question, ...update } : question,
      ),
    }));
  };

  const save = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setError('');
    setSuccess('');
    setIsSaving(true);
    try {
      await createForm(draft);
      setSuccess('Form and corresponding QR record generated successfully.');
      setDraft((current) => ({ ...current, title: '', eventName: '', questions: [emptyQuestion()] }));
      window.location.assign('/admin/forms');
    } catch (caughtError) {
      setError(caughtError instanceof Error ? caughtError.message : 'Unable to create the form.');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <form onSubmit={save} style={{ display: 'grid', gap: '1.5rem' }}>
      <section className="card" style={{ padding: '1.5rem', background: 'var(--bg)', display: 'grid', gap: '1rem' }}>
        <div>
          <p className="microlabel" style={{ marginBottom: '0.35rem' }}>configuration</p>
          <h2 style={{ fontFamily: 'var(--font-mono)', fontSize: '1rem', fontWeight: 600, margin: 0 }}>Form &amp; Academic Period Configuration</h2>
        </div>
        <p style={{ color: 'var(--gray-500)', fontSize: '0.875rem', margin: 0 }}>
          Review and edit Academic Year, Semester, and event details before generating the survey form.
        </p>
        <div style={gridStyle}>
          <Field label="Academic Year"><input required value={draft.academicYear} onChange={(event) => updateDraft('academicYear', event.target.value)} className="input" placeholder="e.g. AY 2026–2027" /></Field>
          <Field label="Semester"><select value={draft.semester} onChange={(event) => updateDraft('semester', event.target.value as FormDraft['semester'])} className="input"><option value="First Semester">First Semester</option><option value="Midyear">Midyear</option><option value="Second Semester">Second Semester</option></select></Field>
          <Field label="Form title"><input required value={draft.title} onChange={(event) => updateDraft('title', event.target.value)} className="input" placeholder="e.g. Industry Partner Satisfaction Survey" /></Field>
          <Field label="Event name"><input required value={draft.eventName} onChange={(event) => updateDraft('eventName', event.target.value)} className="input" placeholder="e.g. 2026 Industry Consultation" /></Field>
          <Field label="Status"><select value={draft.status} onChange={(event) => updateDraft('status', event.target.value as FormDraft['status'])} className="input"><option value="DRAFT">Draft</option><option value="ACTIVE">Active</option><option value="CLOSED">Closed</option></select></Field>
          <Field label="Version"><input required type="number" min="1" step="1" value={draft.version} onChange={(event) => updateDraft('version', Number(event.target.value))} className="input" /></Field>
          <Field label="Department"><input required value={draft.department} onChange={(event) => updateDraft('department', event.target.value)} className="input" /></Field>
          <Field label="Stakeholder category"><select required value={draft.stakeholderCategoryId} onChange={(event) => updateDraft('stakeholderCategoryId', event.target.value)} className="input">{categories.map((category) => <option key={category.id} value={category.id}>{category.name}</option>)}</select></Field>
          <div style={{ gridColumn: '1 / -1' }}>
            <Field label="Schedule (optional)"><div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '0.5rem' }}><input type="datetime-local" value={draft.scheduledStart ?? ''} onChange={(event) => updateDraft('scheduledStart', event.target.value)} className="input" aria-label="Start date" /><input type="datetime-local" value={draft.scheduledEnd ?? ''} onChange={(event) => updateDraft('scheduledEnd', event.target.value)} className="input" aria-label="End date" /></div></Field>
          </div>
        </div>
      </section>

      <section className="card" style={{ padding: '1.5rem', background: 'var(--bg)', display: 'grid', gap: '1rem' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: '1rem', flexWrap: 'wrap' }}>
          <div>
            <p className="microlabel" style={{ marginBottom: '0.35rem' }}>questionnaire</p>
            <h2 style={{ fontFamily: 'var(--font-mono)', fontSize: '1rem', fontWeight: 600, margin: 0 }}>Questions</h2>
            <p style={{ color: 'var(--gray-500)', fontSize: '0.875rem', margin: '0.25rem 0 0' }}>Build a questionnaire using any of the six response types.</p>
          </div>
          <button type="button" onClick={() => setDraft((current) => ({ ...current, questions: [...current.questions, emptyQuestion()] }))} className="btn btn-ghost">+ Add question</button>
        </div>
        <div style={{ display: 'grid', gap: '0.75rem' }}>
          {draft.questions.map((question, index) => {
            const needsOptions = ['LIKERT', 'MULTIPLE_CHOICE', 'CHECKBOXES'].includes(question.questionType);
            return (
              <article key={index} className="card" style={{ padding: '1.25rem', background: 'var(--gray-50)', display: 'grid', gap: '0.75rem' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', gap: '1rem', alignItems: 'center' }}>
                  <span className="microlabel" style={{ color: 'var(--ink)' }}>Question {String(index + 1).padStart(2, '0')}</span>
                  {draft.questions.length > 1 && <button type="button" onClick={() => setDraft((current) => ({ ...current, questions: current.questions.filter((_, questionIndex) => questionIndex !== index) }))} className="link-btn" style={{ color: 'var(--danger)' }}>Remove</button>}
                </div>
                <div style={gridStyle}>
                  <Field label="Question"><input required value={question.questionText} onChange={(event) => updateQuestion(index, { questionText: event.target.value })} className="input" placeholder="Write the question" /></Field>
                  <Field label="Response type"><select value={question.questionType} onChange={(event) => { const questionType = event.target.value as QuestionDraft['questionType']; updateQuestion(index, { questionType, options: defaultOptions[questionType] }); }} className="input">{questionTypes.map((type) => <option key={type.value} value={type.value}>{type.label}</option>)}</select></Field>
                </div>
                {needsOptions && <Field label="Options (one per line)"><textarea required value={question.options.join('\n')} onChange={(event) => updateQuestion(index, { options: event.target.value.split('\n') })} className="input" style={{ minHeight: '100px' }} /></Field>}
                {question.questionType === 'YES_NO' && <p style={helperStyle}>Respondents choose Yes or No.</p>}
                {question.questionType === 'RATING' && <p style={helperStyle}>Respondents select a rating from 1 to 5.</p>}
              </article>
            );
          })}
        </div>
      </section>

      {error && <p role="alert" style={{ color: 'var(--danger)', margin: 0, fontSize: '0.9375rem' }}>{error}</p>}
      {success && <p role="status" style={{ color: 'var(--positive)', margin: 0, fontSize: '0.9375rem' }}>{success}</p>}
      <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
        <button disabled={isSaving} className="btn btn-primary">{isSaving ? 'Creating form…' : 'Create form →'}</button>
      </div>
    </form>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label style={{ display: 'grid', gap: '0.35rem', color: 'var(--gray-500)', fontSize: '0.8125rem', fontWeight: 600 }}>
      <span className="microlabel" style={{ color: 'var(--gray-500)' }}>{label}</span>
      {children}
    </label>
  );
}

const helperStyle: React.CSSProperties = { margin: '0', color: 'var(--gray-500)', fontSize: '0.8125rem' };
const gridStyle: React.CSSProperties = { display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(230px, 1fr))', gap: '1rem' };