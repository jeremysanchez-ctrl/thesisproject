module.exports=[37559,(__turbopack_context__,module1,exports)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_reports_%5BreportType%5D_route_actions_1fwpbsq.js.map