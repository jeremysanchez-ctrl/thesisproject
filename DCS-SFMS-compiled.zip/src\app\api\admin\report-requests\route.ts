import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requireAuth } from '@/lib/auth';

export async function POST(request: NextRequest) {
  try {
    const session = await requireAuth();
    if (!['SUPER_ADMIN', 'ADMIN'].includes(session.role)) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
    }

    const body = await request.json();
    const { action } = body;

    if (action === 'CREATE') {
      const { academicYear, semester, reportType } = body;
      if (!academicYear || !semester || !reportType) {
        return NextResponse.json({ error: 'All parameters are required.' }, { status: 400 });
      }

      const newRequest = await prisma.reportRequest.create({
        data: {
          requestedBy: session.userId,
          academicYear,
          semester,
          reportType,
          status: 'PENDING',
        },
      });

      await prisma.auditLog.create({
        data: {
          userId: session.userId,
          action: 'REQUEST_REPORT',
          module: 'REPORT_REQUESTS',
          description: `Submitted approval request for ${reportType}: ${academicYear} (${semester})`,
        },
      });

      return NextResponse.json({ success: true, requestId: newRequest.id });
    }

    if (action === 'APPROVE') {
      const { requestId } = body;
      if (!requestId) {
        return NextResponse.json({ error: 'Request ID parameter is missing.' }, { status: 400 });
      }

      if (session.role !== 'SUPER_ADMIN') {
        return NextResponse.json({ error: 'Only Super Administrators can approve requests.' }, { status: 403 });
      }

      const reqRecord = await prisma.reportRequest.findUnique({ where: { id: requestId } });
      if (!reqRecord) {
        return NextResponse.json({ error: 'Request record not found.' }, { status: 404 });
      }

      if (reqRecord.requestedBy === session.userId) {
        return NextResponse.json({ error: 'Self-approval is forbidden.' }, { status: 400 });
      }

      await prisma.reportRequest.update({
        where: { id: requestId },
        data: {
          status: 'APPROVED',
          reviewedBy: session.userId,
          reviewedAt: new Date(),
        },
      });

      await prisma.auditLog.create({
        data: {
          userId: session.userId,
          action: 'APPROVE_REPORT_REQUEST',
          module: 'REPORT_REQUESTS',
          description: `Approved report request ID: ${requestId}`,
        },
      });

      return NextResponse.json({ success: true });
    }

    if (action === 'REJECT') {
      const { requestId, rejectionNote } = body;
      if (!requestId || !rejectionNote) {
        return NextResponse.json({ error: 'Request ID and rejection reason are required.' }, { status: 400 });
      }

      if (session.role !== 'SUPER_ADMIN') {
        return NextResponse.json({ error: 'Only Super Administrators can reject requests.' }, { status: 403 });
      }

      const reqRecord = await prisma.reportRequest.findUnique({ where: { id: requestId } });
      if (!reqRecord) {
        return NextResponse.json({ error: 'Request record not found.' }, { status: 404 });
      }

      if (reqRecord.requestedBy === session.userId) {
        return NextResponse.json({ error: 'Self-rejection is forbidden.' }, { status: 400 });
      }

      await prisma.reportRequest.update({
        where: { id: requestId },
        data: {
          status: 'REJECTED',
          rejectionNote,
          reviewedBy: session.userId,
          reviewedAt: new Date(),
        },
      });

      await prisma.auditLog.create({
        data: {
          userId: session.userId,
          action: 'REJECT_REPORT_REQUEST',
          module: 'REPORT_REQUESTS',
          description: `Rejected report request ID: ${requestId}. Reason: ${rejectionNote}`,
        },
      });

      return NextResponse.json({ success: true });
    }

    return NextResponse.json({ error: 'Invalid action parameter.' }, { status: 400 });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : 'Server error' }, { status: 500 });
  }
}
