import { PrismaClient } from '@prisma/client';
import { hashPassword } from '../src/lib/security';

const prisma = new PrismaClient();

async function main() {
  console.log('Seeding database...');

  // 1. Create demo users
  const users = [
    { name: 'Super Administrator', email: 'admin@sfms.local', password: 'password123', role: 'SUPER_ADMIN' },
    { name: 'Regular Administrator', email: 'regadmin@sfms.local', password: 'password123', role: 'ADMIN' },
    { name: 'Department Head', email: 'depthead@sfms.local', password: 'password123', role: 'DEPT_HEAD' },
    { name: 'Quality Assurance Officer', email: 'qa@sfms.local', password: 'password123', role: 'QA_OFFICER' },
  ];

  for (const user of users) {
    const existingUser = await prisma.user.findUnique({ where: { email: user.email } });
    if (!existingUser) {
      await prisma.user.create({
        data: {
          name: user.name,
          email: user.email,
          password: hashPassword(user.password),
          role: user.role,
        }
      });
      console.log(`Created ${user.role} user: ${user.email} / ${user.password}`);
    } else {
      await prisma.user.update({
        where: { id: existingUser.id },
        data: {
          role: user.role,
          ...(existingUser.password.startsWith('scrypt$') ? {} : { password: hashPassword(user.password) })
        },
      });
    }
  }

  // 2. Create Stakeholder Categories
  const categories = [
    'Citizen',
    'Business',
    'Government',
    'Students',
    'Alumni',
    'Parents/Guardians',
    'Industry Partners',
    'Internship Supervisors',
    'Employers',
    'Faculty Members',
    'Accrediting Bodies'
  ];

  let citizenCategoryId = '';

  for (const name of categories) {
    let existing = await prisma.stakeholderCategory.findUnique({
      where: { name }
    });
    if (!existing) {
      existing = await prisma.stakeholderCategory.create({ data: { name } });
      console.log(`Created Stakeholder Category: ${name}`);
    }
    if (name === 'Citizen') citizenCategoryId = existing.id;
  }

  // 3. Create Default Event and Form based on the uploaded images
  const eventName = 'General Client Satisfaction 2026';
  
  // Find or create event
  let event = await prisma.event.findFirst({ where: { name: eventName } });
  if (!event) {
    event = await prisma.event.create({
      data: {
        name: eventName,
        department: 'Registrar / Admin Office',
        stakeholderCategoryId: citizenCategoryId,
        createdBy: 'admin@sfms.local'
      }
    });
    console.log(`Created Event: ${eventName}`);
  }

  // Check if form exists
  const formTitle = "STAKEHOLDERS' FEEDBACK FORM (HRDO-QF-07)";
  const existingForm = await prisma.surveyForm.findFirst({ where: { title: formTitle } });
  
  if (!existingForm) {
    const form = await prisma.surveyForm.create({
      data: {
        eventId: event.id,
        title: formTitle,
        status: 'ACTIVE',
        version: 1
      }
    });

    console.log(`Created Form: ${form.title}`);

    const hrdoLikertOptions = JSON.stringify([
      '5 - Highly satisfied',
      '4 - Very satisfied',
      '3 - Moderately satisfied',
      '2 - Barely satisfied',
      '1 - Not satisfied'
    ]);

    // Add HRDO-QF-07 Questions from official form
    const questions = [
      { text: 'A. Courtesy', type: 'LIKERT', order: 1, options: hrdoLikertOptions },
      { text: 'B1. Service — Quality', type: 'LIKERT', order: 2, options: hrdoLikertOptions },
      { text: 'B2. Service — Timeliness', type: 'LIKERT', order: 3, options: hrdoLikertOptions },
      { text: 'B3. Service — Efficiency', type: 'LIKERT', order: 4, options: hrdoLikertOptions },
      { text: 'C1. Physical condition of office/workspace — Cleanliness', type: 'LIKERT', order: 5, options: hrdoLikertOptions },
      { text: 'C2. Physical condition of office/workspace — Comfort', type: 'LIKERT', order: 6, options: hrdoLikertOptions },
      { text: 'Comments / Suggestions', type: 'TEXT', order: 7 }
    ];

    for (const q of questions) {
      await prisma.formQuestion.create({
        data: {
          formId: form.id,
          questionText: q.text,
          questionType: q.type,
          order: q.order,
          optionsJson: q.options || null
        }
      });
    }
    console.log('Added HRDO-QF-07 Questions to the Form');
  }

  console.log('Seeding finished.');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
