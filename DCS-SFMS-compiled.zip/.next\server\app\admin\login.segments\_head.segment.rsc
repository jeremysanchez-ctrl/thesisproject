1:"$Sreact.fragment"
2:I[97367,["/_next/static/chunks/1ijzfoexyz21j.js","/_next/static/chunks/1b-9a2femdom1.js"],"ViewportBoundary"]
3:I[97367,["/_next/static/chunks/1ijzfoexyz21j.js","/_next/static/chunks/1b-9a2femdom1.js"],"MetadataBoundary"]
4:"$Sreact.suspense"
5:I[27201,["/_next/static/chunks/1ijzfoexyz21j.js","/_next/static/chunks/1b-9a2femdom1.js"],"IconMark"]
0:{"rsc":["$","$1","h",{"children":[null,["$","$L2",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","div",null,{"hidden":true,"children":["$","$L3",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"CvSU-Imus DCS SFMS"}],["$","meta","1",{"name":"description","content":"Collect and analyze stakeholder feedback."}],["$","link","2",{"rel":"icon","href":"/favicon.ico?favicon.2vob68tjqpejf.ico","sizes":"256x256","type":"image/x-icon"}],["$","$L5","3",{}]]}]}]}],null]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"JexLKIp_5JzLv0J00Vo-g"}
