module.exports=[50176,(__turbopack_context__,module1,exports)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_%28protected%29_system-control_page_actions_14a_8f5.js.map