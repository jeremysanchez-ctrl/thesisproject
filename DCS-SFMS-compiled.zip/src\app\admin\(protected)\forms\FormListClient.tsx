'use client';

import { useState } from 'react';
import Link from 'next/link';
import { archiveForm, toggleFormStatus } from './actions';

type FormItem = {
  id: string;
  title: string;
  academicYear?: string | null;
  semester?: string | null;
  status: 'DRAFT' | 'ACTIVE' | 'CLOSED' | string;
  event: { name: string };
  _count: { Questions: number; Responses: number };
};

export default function FormListClient({ forms }: { forms: FormItem[] }) {
  const [loadingId, setLoadingId] = useState<string | null>(null);

  const handleArchive = async (id: string, title: string) => {
    if (!confirm(`Move form "${title}" to Trash/Archive? Existing response data will be preserved safely.`)) return;
    setLoadingId(id);
    try {
      await archiveForm(id);
    } catch {
      alert('Failed to archive form.');
    } finally {
      setLoadingId(null);
    }
  };

  const handleToggleStatus = async (id: string, currentStatus: string) => {
    const nextStatus = currentStatus === 'ACTIVE' ? 'CLOSED' : 'ACTIVE';
    setLoadingId(id);
    try {
      await toggleFormStatus(id, nextStatus as 'ACTIVE' | 'CLOSED');
    } catch {
      alert('Failed to update form status.');
    } finally {
      setLoadingId(null);
    }
  };

  if (forms.length === 0) {
    return <p style={{ color: 'var(--gray-500)' }}>No active forms have been created yet.</p>;
  }

  const statusChip = (status: string) => {
    if (status === 'ACTIVE') return <span className="chip-inverted">active</span>;
    if (status === 'CLOSED') return <span className="chip">closed</span>;
    return <span className="chip">draft</span>;
  };

  return (
    <div style={{ display: 'grid', gap: '0.6rem' }}>
      {forms.map((form) => {
        const isLoading = loadingId === form.id;
        return (
          <div
            key={form.id}
            className="card"
            style={{
              display: 'flex',
              justifyContent: 'space-between',
              gap: '1rem',
              alignItems: 'center',
              padding: '1.15rem 1.25rem',
              background: 'var(--bg)',
              opacity: isLoading ? 0.5 : 1,
              flexWrap: 'wrap',
            }}
          >
            <div style={{ minWidth: 0 }}>
              <Link
                href={`/form/${form.id}`}
                style={{ color: 'var(--ink)', fontWeight: 600, fontSize: '1rem', textDecoration: 'none' }}
              >
                {form.title}
              </Link>
              <p style={{ color: 'var(--gray-500)', margin: '0.35rem 0 0', fontSize: '0.875rem' }}>
                {form.event.name} · <strong style={{ color: 'var(--ink)', fontWeight: 600 }}>{form.academicYear || 'AY 2026–2027'} ({form.semester || 'First Semester'})</strong> · {form._count.Questions} questions · {form._count.Responses} responses
              </p>
            </div>

            <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem', flexWrap: 'wrap' }}>
              {statusChip(form.status)}

              <button
                onClick={() => handleToggleStatus(form.id, form.status)}
                disabled={isLoading}
                className="btn btn-ghost"
                style={{ fontSize: '0.75rem', padding: '0.45rem 0.9rem' }}
              >
                {form.status === 'ACTIVE' ? 'close' : 'activate'}
              </button>

              <button
                onClick={() => handleArchive(form.id, form.title)}
                disabled={isLoading}
                title="Move to Trash / Archive"
                className="btn btn-danger"
                style={{ fontSize: '0.75rem', padding: '0.45rem 0.9rem' }}
              >
                archive
              </button>
            </div>
          </div>
        );
      })}
    </div>
  );
}