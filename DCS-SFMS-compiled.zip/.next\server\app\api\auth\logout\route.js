var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/logout/route.js")
R.c("server/chunks/[root-of-the-server]__1m1_1im._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_0htkyro._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_logout_route_actions_0regwyr.js")
R.m(83932)
module.exports=R.m(83932).exports
