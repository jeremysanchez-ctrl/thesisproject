'use client';

import { useEffect, useState } from 'react';
import Image from 'next/image';
import { archiveQRCode } from './actions';

type QRCode = {
  id: string;
  codeString: string;
  scanCount: number;
  expiresAt: Date | null;
  event: { name: string; department: string };
};

export default function QRCodeList({ qrCodes, baseUrl }: { qrCodes: QRCode[]; baseUrl: string }) {
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [effectiveBaseUrl, setEffectiveBaseUrl] = useState(baseUrl);

  useEffect(() => {
    const customUrl = localStorage.getItem('sfms_public_app_url');
    if (customUrl) {
      // Sync cached base URL after mount; avoids SSR/hydration mismatch.
      // eslint-disable-next-line react-hooks/set-state-in-effect
      setEffectiveBaseUrl(customUrl);
    }
  }, [baseUrl]);

  const handleArchive = async (id: string, eventName: string) => {
    if (!confirm(`Archive the QR code for "${eventName}"? It will be moved to the safety bin.`)) return;
    setDeletingId(id);
    try {
      await archiveQRCode(id);
      window.location.reload();
    } catch {
      alert('Failed to archive QR code. Please try again.');
      setDeletingId(null);
    }
  };

  // Build the QR image src with the user's configured base URL
  const qrImageSrc = (qrCodeId: string) => {
    const encodedBase = encodeURIComponent(effectiveBaseUrl.replace(/\/$/, ''));
    return `/api/qr-codes/${qrCodeId}?baseUrl=${encodedBase}`;
  };

  if (qrCodes.length === 0) {
    return <p style={{ color: 'var(--gray-500)', fontSize: '0.9375rem' }}>No QR codes have been generated yet.</p>;
  }

  return (
    <div style={{ display: 'grid', gap: '0.75rem' }}>
      {qrCodes.map((qrCode) => {
        const cleanBase = effectiveBaseUrl.replace(/\/$/, '');
        const scanUrl = `${cleanBase}/q/${qrCode.codeString}`;
        const isDeleting = deletingId === qrCode.id;

        return (
          <article
            key={qrCode.id}
            className="card"
            style={{
              display: 'grid',
              gridTemplateColumns: '110px 1fr auto',
              gap: '1.25rem',
              alignItems: 'center',
              padding: '1.25rem',
              background: 'var(--bg)',
              opacity: isDeleting ? 0.5 : 1,
              transition: 'opacity var(--motion-1)',
            }}
          >
            <Image
              src={qrImageSrc(qrCode.id)}
              alt={`QR code for ${qrCode.event.name}`}
              width={110}
              height={110}
              unoptimized
              style={{ width: '110px', height: '110px', borderRadius: 'var(--radius-sm)', border: 'var(--hairline)', background: '#fff' }}
            />
            <div style={{ minWidth: 0 }}>
              <strong style={{ fontFamily: 'var(--font-mono)', fontSize: '1.05rem', fontWeight: 600 }}>
                {qrCode.event.name}
              </strong>
              <p style={{ color: 'var(--gray-500)', margin: '0.35rem 0 0.6rem', fontSize: '0.906rem', wordWrap: 'break-word' }}>
                {qrCode.event.department} · <strong style={{ color: 'var(--ink)', fontWeight: 600 }}>{qrCode.scanCount} scans</strong> · {qrCode.expiresAt ? `Expires ${new Date(qrCode.expiresAt).toLocaleString()}` : 'No expiration'}
              </p>
              <div style={{
                wordBreak: 'break-all', display: 'inline-block', background: 'var(--gray-50)',
                padding: '0.35rem 0.6rem', borderRadius: 'var(--radius-xs)', border: 'var(--hairline)',
              }}>
                <a href={scanUrl} target="_blank" rel="noreferrer" style={{ fontFamily: 'var(--font-mono)', fontSize: '0.8125rem', color: 'var(--ink)', textDecoration: 'underline', textDecorationColor: 'var(--gray-400)' }}>
                  {scanUrl} ↗
                </a>
              </div>
            </div>
            <div style={{ display: 'flex', gap: '0.6rem', flexWrap: 'wrap', justifyContent: 'flex-end' }}>
              <a
                href={qrImageSrc(qrCode.id)}
                download={`QR_${qrCode.event.name.replace(/[^a-zA-Z0-9]/g, '_')}.png`}
                className="btn btn-primary"
                style={{ fontSize: '0.8125rem' }}
              >
                Download PNG
              </a>
              <button
                onClick={() => handleArchive(qrCode.id, qrCode.event.name)}
                disabled={isDeleting}
                title="Archive QR code"
                className="btn btn-danger"
                style={{ fontSize: '0.8125rem' }}
              >
                {isDeleting ? 'Archiving…' : 'Archive'}
              </button>
            </div>
          </article>
        );
      })}
    </div>
  );
}