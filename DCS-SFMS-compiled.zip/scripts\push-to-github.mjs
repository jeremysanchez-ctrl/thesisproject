import { execSync } from 'node:child_process';
import readline from 'node:readline';

function run(command, inheritStdio = true) {
  try {
    return execSync(command, {
      stdio: inheritStdio ? 'inherit' : 'pipe',
      encoding: 'utf8',
    });
  } catch (error) {
    if (!inheritStdio && error.stderr) {
      return error.stderr.toString();
    }
    throw error;
  }
}

function ask(questionText) {
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
  });
  return new Promise((resolve) => {
    rl.question(questionText, (answer) => {
      rl.close();
      resolve(answer.trim());
    });
  });
}

async function main() {
  console.log('\n========================================');
  console.log('🚀 GitHub Push & Auto-Sync Automation');
  console.log('========================================\n');

  // 1. Verify Git installation
  try {
    run('git --version', false);
  } catch {
    console.error('❌ Git is not installed or not found in system PATH.');
    console.error('👉 Install Git via terminal: winget install --id Git.Git -e --source winget');
    console.error('👉 Or download: https://git-scm.com/download/win');
    process.exit(1);
  }

  // 2. Check if git repo is initialized
  try {
    run('git rev-parse --is-inside-work-tree', false);
  } catch {
    console.log('📦 Initializing Git repository...');
    run('git init');
  }

  // 3. Check / Add Remote Origin
  let hasOrigin = false;
  try {
    const remotes = run('git remote', false);
    hasOrigin = remotes.split('\n').map((r) => r.trim()).includes('origin');
  } catch {}

  if (!hasOrigin) {
    console.log('🔗 No remote "origin" detected.');
    const repoUrl = await ask('👉 Enter your GitHub Repository URL (HTTPS or SSH): ');
    if (!repoUrl) {
      console.error('❌ Repository URL cannot be empty.');
      process.exit(1);
    }
    run(`git remote add origin ${repoUrl}`);
    console.log(`✅ Remote origin linked to: ${repoUrl}`);
  }

  // 4. Ensure branch is 'main'
  try {
    run('git branch -M main');
  } catch (err) {
    console.warn('⚠️ Could not set branch to main:', err.message);
  }

  // 5. Stage changes
  console.log('\n📂 Staging modified & new files...');
  run('git add .');

  // 6. Check status / Commit message
  const statusOutput = run('git status --porcelain', false);
  if (!statusOutput || !statusOutput.trim()) {
    console.log('✨ No changes to commit. Working tree clean.');
  } else {
    const commitMsg = process.argv.slice(2).join(' ') || 'Auto-update project files and QR scanner web app';
    console.log(`📝 Creating commit: "${commitMsg}"...`);
    try {
      run(`git commit -m "${commitMsg}"`);
    } catch {
      console.log('⚠️ Commit skipped (no staged changes).');
    }
  }

  // 7. Push to GitHub
  console.log('\n⬆️ Pushing changes to GitHub (origin main)...');
  try {
    run('git push -u origin main');
    console.log('\n========================================');
    console.log('🎉 Successfully pushed to GitHub!');
    console.log('========================================\n');
  } catch (err) {
    console.error('\n❌ Push failed. Common solutions:');
    console.error(' 1. Remote has existing commits: Try pulling first -> git pull origin main --rebase');
    console.error(' 2. Authentication: Sign in with GitHub Credential Manager or use a Personal Access Token (PAT).');
    console.error(' 3. Force push (Caution - overwrites remote): git push -u origin main --force\n');
    process.exit(1);
  }
}

main();
