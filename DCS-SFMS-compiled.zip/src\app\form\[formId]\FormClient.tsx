'use client';

import { useActionState, useEffect, useState } from 'react';
import { submitSurvey } from './actions';
import type { FormState } from './actions';
import PageGuideNote from '@/components/PageGuideNote';
import SignaturePad from './SignaturePad';

interface Category {
  id: string;
  name: string;
}

interface Question {
  id: string;
  questionText: string;
  questionType: string;
  optionsJson: string | null;
}

interface Form {
  id: string;
  Questions: Question[];
}

function generateControlNumber() {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const d = String(now.getDate()).padStart(2, '0');
  const rand = Math.random().toString(36).substring(2, 8).toUpperCase();
  return `SFMS-${y}${m}${d}-${rand}`;
}

const initialState: FormState = { success: false, error: '', submissionCount: 0 };

export default function FormClient({
  form,
  eventName,
  categories,
}: {
  form: Form;
  formTitle: string;
  eventName: string;
  categories: Category[];
}) {
  const [state, formAction, isPending] = useActionState(submitSurvey, initialState);
  const [selectedCategory, setSelectedCategory] = useState('');
  const [controlNumber, setControlNumber] = useState('');
  const [liveTimestamp, setLiveTimestamp] = useState('');
  const [photoPreview, setPhotoPreview] = useState<string | null>(null);
  const [photoFileName, setPhotoFileName] = useState<string | null>(null);
  const [signatureData, setSignatureData] = useState<string | null>(null);

  const handlePhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setPhotoFileName(file.name);
      const reader = new FileReader();
      reader.onload = () => {
        setPhotoPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    } else {
      setPhotoPreview(null);
      setPhotoFileName(null);
    }
  };

  const handleRemovePhoto = () => {
    setPhotoPreview(null);
    setPhotoFileName(null);
    const input = document.getElementById('hardCopyPhotoInput') as HTMLInputElement;
    if (input) input.value = '';
  };

  // Initialize client-only states on mount
  useEffect(() => {
    // Generated once client-side to keep the server render deterministic.
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setControlNumber(generateControlNumber());

    const updateLive = () => setLiveTimestamp(new Date().toLocaleString('en-US', {
      dateStyle: 'full',
      timeStyle: 'medium'
    }));

    const timer = setInterval(updateLive, 1000);
    return () => clearInterval(timer);
  }, []);

  // React to successful submissions
  useEffect(() => {
    if (state.success && state.submissionCount > 0) {
      const ctrl = state.controlNo || controlNumber;
      window.location.href = `/form/${form.id}/success?ctrl=${encodeURIComponent(ctrl)}`;
    }
  }, [state.submissionCount, state.success, state.controlNo, controlNumber, form.id]);

  // Show error alerts
  useEffect(() => {
    if (state.error) {
      alert(state.error);
    }
  }, [state.error, state.submissionCount]);

  const inputStyle: React.CSSProperties = {
    width: '100%',
    padding: '0.65rem 0.85rem',
    borderRadius: 'var(--radius-xs)',
    border: 'var(--hairline)',
    fontFamily: 'var(--font-body)',
    fontSize: '0.9375rem',
    color: 'var(--ink)',
    background: 'var(--gray-50)',
    outline: 'none',
    boxSizing: 'border-box',
    transition: 'border-color var(--motion-1)',
  };

  const labelStyle: React.CSSProperties = {
    display: 'flex',
    alignItems: 'center',
    gap: '0.35rem',
    fontFamily: 'var(--font-mono)',
    fontSize: '0.75rem',
    letterSpacing: '0.05em',
    textTransform: 'uppercase',
    marginBottom: '0.5rem',
    color: 'var(--gray-500)',
    fontWeight: 500,
  };

  const ratingOptions = [
    { label: 'Highly satisfied', val: '5 - Highly satisfied', score: 5 },
    { label: 'Very satisfied', val: '4 - Very satisfied', score: 4 },
    { label: 'Moderately satisfied', val: '3 - Moderately satisfied', score: 3 },
    { label: 'Barely satisfied', val: '2 - Barely satisfied', score: 2 },
    { label: 'Not satisfied', val: '1 - Not satisfied', score: 1 },
  ];

  return (
    <div style={{ maxWidth: '900px', margin: '0 auto', fontFamily: 'var(--font-body)' }}>

      {/* Interactive System Guide Tutorial Note */}
      <PageGuideNote
        pageTitle="this Feedback Survey"
        overview="Welcome to the Cavite State University - Imus Campus Stakeholders' Feedback Form. Your honest responses help us continuously improve department services, staff courtesy, and workspace facilities."
        steps={[
          { title: 'Fill Demographics', description: 'Enter your Name, Agency / Office, Email Address, and select your Stakeholder Category.' },
          { title: 'Rate Areas of Concern', description: 'Rate Courtesy, Service Quality, Timeliness, Efficiency, Cleanliness, and Comfort from 5 (Highly satisfied) to 1 (Not satisfied).' },
          { title: 'Submit & Get Control No.', description: 'Click Submit Feedback to receive your official submission Control Number.' }
        ]}
      />

      {/* Official Muted Header matching HRDO-QF-07 */}
      <div style={{
        background: 'var(--ink)',
        color: 'var(--bg)',
        borderRadius: 'var(--radius-lg) var(--radius-lg) 0 0',
        padding: '2rem 1.5rem',
        textAlign: 'center',
        position: 'relative',
      }}>
        <div className="hrdo-badge">
          HRDO-QF-07
        </div>
        <div className="microlabel" style={{ color: 'var(--gray-400)', letterSpacing: '0.14em' }}>
          Republic of the Philippines
        </div>
        <h2 style={{
          fontFamily: 'var(--font-mono)',
          fontSize: '1.4rem',
          fontWeight: 600,
          margin: '0.4rem 0',
          letterSpacing: '0.03em',
          textTransform: 'uppercase',
          color: 'var(--bg)',
        }}>
          CAVITE STATE UNIVERSITY
        </h2>
        <div className="microlabel" style={{ color: 'var(--gray-400)' }}>
          Imus Campus · Imus City, Cavite
        </div>
      </div>

      {/* Main Container Card */}
      <div className="main-container-card">

        {/* Title & Control Bar */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem', marginBottom: '1.5rem' }}>
          <div>
            <h1 style={{ fontFamily: 'var(--font-mono)', fontSize: '1.4rem', color: 'var(--ink)', margin: 0, fontWeight: 600 }}>
              STAKEHOLDERS&apos; FEEDBACK FORM
            </h1>
            <p style={{ margin: '0.4rem 0 0 0', color: 'var(--gray-500)', fontSize: '0.9375rem', fontWeight: 500 }}>
              Event: {eventName}
            </p>
          </div>
          <div style={{
            background: 'var(--gray-50)',
            border: 'var(--hairline)',
            borderRadius: 'var(--radius-sm)',
            padding: '0.6rem 1rem',
            textAlign: 'right',
          }}>
            <span className="microlabel" style={{ display: 'block' }}>Control No.</span>
            <span style={{ fontFamily: 'var(--font-mono)', fontSize: '1rem', fontWeight: 600, color: 'var(--ink)' }}>{controlNumber}</span>
          </div>
        </div>

        {/* Subtitle / Instructions */}
        <div style={{
          background: 'var(--gray-50)',
          borderLeft: '4px solid var(--ink)',
          padding: '1.1rem 1.25rem',
          borderRadius: 'var(--radius-sm)',
          marginBottom: '2rem',
          fontSize: '0.9375rem',
          color: 'var(--gray-600)',
          lineHeight: 1.6,
          fontWeight: 400,
        }}>
          Please let us know how we can improve our service by giving your honest feedback. We value our
          stakeholders, hence, your comments and suggestions will be highly appreciated.
        </div>

        {/* Form Body */}
        <form action={formAction} encType="multipart/form-data" style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
          <input type="hidden" name="_formId" value={form.id} />
          <input type="hidden" name="_stakeholderCategoryId" value={selectedCategory} />

          {/* Section 1: Demographics / Stakeholder Information */}
          <div className="form-section">
            <h3 className="form-section-title">
              <span>01 &nbsp; Respondent &amp; Transaction Details</span>
              <span className="microlabel" style={{ color: 'var(--gray-400)' }}>{liveTimestamp}</span>
            </h3>

            {/* Upload Photo Option (Top of selection of department questions) */}
            <div style={{
              marginBottom: '1.5rem',
              padding: '1.15rem 1.25rem',
              background: 'var(--gray-50)',
              border: photoPreview ? '1.5px solid var(--primary)' : '1.5px dashed var(--gray-300)',
              borderRadius: 'var(--radius-sm)',
              transition: 'all var(--motion-1)',
            }}>
              {/* Indication required by user */}
              <div style={{
                display: 'flex',
                alignItems: 'center',
                gap: '0.45rem',
                color: 'var(--primary)',
                fontWeight: 600,
                fontSize: '0.875rem',
                marginBottom: '0.4rem',
                fontFamily: 'var(--font-mono)',
              }}>
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/>
                  <circle cx="12" cy="13" r="4"/>
                </svg>
                <span>Upload the photo here if already had an copy of form</span>
              </div>
              <p style={{ margin: '0 0 0.85rem 0', fontSize: '0.8125rem', color: 'var(--gray-500)', lineHeight: 1.4 }}>
                If you already have a physical/hard copy of the Detailed Stakeholder Response Report, you can attach a photo of it here.
              </p>

              <div>
                <input
                  id="hardCopyPhotoInput"
                  type="file"
                  name="hardCopyPhoto"
                  accept="image/*"
                  onChange={handlePhotoChange}
                  style={{ display: 'none' }}
                />

                {!photoPreview ? (
                  <label
                    htmlFor="hardCopyPhotoInput"
                    style={{
                      display: 'inline-flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      gap: '0.6rem',
                      padding: '0.75rem 1.25rem',
                      background: 'var(--bg)',
                      border: '1px solid var(--primary)',
                      color: 'var(--primary)',
                      borderRadius: 'var(--radius-xs)',
                      cursor: 'pointer',
                      fontWeight: 600,
                      fontSize: '0.875rem',
                      fontFamily: 'var(--font-mono)',
                      transition: 'all var(--motion-1)',
                    }}
                  >
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
                      <polyline points="17 8 12 3 7 8"/>
                      <line x1="12" y1="3" x2="12" y2="15"/>
                    </svg>
                    Choose Photo / Capture
                  </label>
                ) : (
                  <div style={{
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '0.75rem',
                    background: 'var(--bg)',
                    padding: '0.85rem',
                    borderRadius: 'var(--radius-xs)',
                    border: 'var(--hairline)',
                  }}>
                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '0.75rem' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', overflow: 'hidden' }}>
                        <span style={{ color: 'var(--success)', fontWeight: 700, fontSize: '0.875rem' }}>✓</span>
                        <span style={{ fontSize: '0.8125rem', fontWeight: 600, color: 'var(--ink)', textOverflow: 'ellipsis', overflow: 'hidden', whiteSpace: 'nowrap' }}>
                          {photoFileName}
                        </span>
                      </div>
                      <div style={{ display: 'flex', gap: '0.65rem', flexShrink: 0 }}>
                        <label
                          htmlFor="hardCopyPhotoInput"
                          style={{
                            fontSize: '0.75rem',
                            color: 'var(--primary)',
                            cursor: 'pointer',
                            fontWeight: 600,
                            textDecoration: 'underline',
                          }}
                        >
                          Change
                        </label>
                        <button
                          type="button"
                          onClick={handleRemovePhoto}
                          style={{
                            background: 'transparent',
                            border: 'none',
                            color: 'var(--danger)',
                            fontSize: '0.75rem',
                            cursor: 'pointer',
                            fontWeight: 600,
                            padding: 0,
                          }}
                        >
                          Remove
                        </button>
                      </div>
                    </div>

                    {/* Image Preview */}
                    <div style={{
                      position: 'relative',
                      width: '100%',
                      maxHeight: '260px',
                      overflow: 'hidden',
                      borderRadius: 'var(--radius-xs)',
                      border: 'var(--hairline)',
                      background: 'var(--gray-900)',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                    }}>
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img
                        src={photoPreview}
                        alt="Hard copy preview"
                        style={{
                          maxWidth: '100%',
                          maxHeight: '260px',
                          objectFit: 'contain',
                        }}
                      />
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Department Selection (First Question) */}
            <div style={{ marginBottom: '1.25rem' }}>
              <label style={labelStyle}>
                Department <span style={{ color: 'var(--danger)' }}>*</span>
              </label>
              <select
                name="department"
                required
                defaultValue=""
                style={{
                  ...inputStyle,
                  cursor: 'pointer',
                  appearance: 'auto',
                }}
              >
                <option value="" disabled>— Select Department —</option>
                <option value="Department of Computer Studies">Department of Computer Studies</option>
                <option value="Department of Hospitality Management">Department of Hospitality Management</option>
                <option value="Department of Languages and Mass Communication">Department of Languages and Mass Communication</option>
                <option value="Department of Management">Department of Management</option>
                <option value="Department of Physical Education">Department of Physical Education</option>
                <option value="Department of Social Sciences and Humanities">Department of Social Sciences and Humanities</option>
                <option value="Teacher Education Department">Teacher Education Department</option>
              </select>
            </div>

            {/* Stakeholder Category Selection */}
            <div style={{ marginBottom: '1.25rem' }}>
              <label style={labelStyle}>
                Stakeholder / Client Category <span style={{ color: 'var(--danger)' }}>*</span>
              </label>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.6rem' }} className="category-selection-container">
                {categories.map((cat) => (
                  <label
                    key={cat.id}
                    className="category-box-label"
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '0.6rem',
                      padding: '0.65rem 1rem',
                      border: selectedCategory === cat.id ? '1px solid var(--ink)' : 'var(--hairline)',
                      borderRadius: 'var(--radius-sm)',
                      cursor: 'pointer',
                      background: selectedCategory === cat.id ? 'var(--ink)' : 'var(--bg)',
                      fontSize: '0.906rem',
                      fontWeight: selectedCategory === cat.id ? 600 : 400,
                      color: selectedCategory === cat.id ? 'var(--bg)' : 'var(--ink)',
                      transition: 'all var(--motion-1)',
                      minHeight: '44px',
                      boxSizing: 'border-box',
                    }}
                  >
                    <input
                      type="radio"
                      name="clientType"
                      value={cat.id}
                      checked={selectedCategory === cat.id}
                      onChange={() => setSelectedCategory(cat.id)}
                      style={{ width: '1.1rem', height: '1.1rem', accentColor: 'var(--ink)' }}
                    />
                    {cat.name}
                  </label>
                ))}
              </div>
            </div>

            {/* Grid 1: Name & Agency (REQUIRED) */}
            <div className="responsive-grid-2">
              <div>
                <label style={labelStyle}>
                  Name (Pangalan) <span style={{ color: 'var(--danger)' }}>*</span>
                </label>
                <input
                  type="text"
                  name="name"
                  required
                  placeholder="Juan Dela Cruz"
                  style={inputStyle}
                />
              </div>
              <div>
                <label style={labelStyle}>
                  Agency / Office / Organization <span style={{ color: 'var(--danger)' }}>*</span>
                </label>
                <input
                  type="text"
                  name="agency"
                  required
                  placeholder="Company / Agency Name"
                  style={inputStyle}
                />
              </div>
            </div>

            {/* Grid 2: Email & Date of Visit (Auto-recorded) */}
            <div className="responsive-grid-2">
              <div>
                <label style={labelStyle}>
                  Email Address <span style={{ color: 'var(--danger)' }}>*</span>
                </label>
                <input
                  type="email"
                  name="email"
                  required
                  placeholder="example@domain.com"
                  style={inputStyle}
                />
              </div>
              <div>
                <label style={labelStyle}>
                  Date of Visit <span style={{ color: 'var(--gray-400)', fontSize: '0.625rem', letterSpacing: '0.08em' }}>(Automatically Recorded)</span>
                </label>
                <div style={{
                  padding: '0.65rem 1rem',
                  borderRadius: 'var(--radius-xs)',
                  border: 'var(--hairline)',
                  background: 'var(--gray-100)',
                  fontSize: '0.9375rem',
                  fontWeight: 600,
                  color: 'var(--gray-600)',
                  fontFamily: 'var(--font-mono)',
                }}>
                  {new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}
                </div>
              </div>
            </div>

            {/* Grid 3: Purpose of Visit & Attending Staff */}
            <div className="responsive-grid-2">
              <div>
                <label style={labelStyle}>Purpose of Visit (Layunin ng Pagbisita)</label>
                <input
                  type="text"
                  name="purposeOfVisit"
                  placeholder="Inquiry / Document Request / Submission"
                  style={inputStyle}
                />
              </div>
              <div>
                <label style={labelStyle}>Attending Staff (Kawaninh Dumalo)</label>
                <input
                  type="text"
                  name="attendingStaff"
                  placeholder="Staff Name / Window No."
                  style={inputStyle}
                />
              </div>
            </div>
          </div>

          {/* Section 2: Areas of Concern Ratings */}
          <div className="form-section" style={{ background: 'var(--gray-50)' }}>
            <h3 className="form-section-title">
              02 &nbsp; Areas of Concern Rating
            </h3>

            <p style={{ fontSize: '0.906rem', color: 'var(--gray-500)', marginBottom: '1.25rem', lineHeight: 1.5 }}>
              Please rate your level of satisfaction for each area of concern below:
            </p>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
              {form.Questions.map((q) => {
                if (q.questionType !== 'LIKERT') return null;

                return (
                  <div key={q.id} className="card" style={{
                    background: 'var(--bg)',
                    padding: '1.25rem',
                  }}>
                    <label style={{
                      display: 'block',
                      fontFamily: 'var(--font-body)',
                      fontSize: '1.05rem',
                      fontWeight: 600,
                      color: 'var(--ink)',
                      marginBottom: '1rem',
                      lineHeight: 1.4,
                    }}>
                      {q.questionText} {!photoPreview && <span style={{ color: 'var(--danger)' }}>*</span>}
                    </label>

                    {/* Rating Options Grid */}
                    <div className="rating-options-grid">
                      {ratingOptions.map((opt) => (
                        <label
                          key={opt.score}
                          style={{
                            display: 'flex',
                            flexDirection: 'column',
                            alignItems: 'center',
                            justifyContent: 'center',
                            padding: '0.8rem 0.5rem',
                            border: 'var(--hairline)',
                            borderRadius: 'var(--radius-sm)',
                            cursor: 'pointer',
                            background: 'var(--bg)',
                            textAlign: 'center',
                            minHeight: '60px',
                            boxSizing: 'border-box',
                            transition: 'all var(--motion-1)',
                          }}
                          className="rating-box-label"
                        >
                          <input
                            type="radio"
                            name={`question_${q.id}`}
                            value={opt.val}
                            required={!photoPreview}
                            style={{ width: '1.1rem', height: '1.1rem', accentColor: 'var(--ink)', marginBottom: '0.3rem' }}
                          />
                          <span style={{ fontFamily: 'var(--font-mono)', fontSize: '1rem', fontWeight: 600, color: 'var(--ink)' }}>{opt.score}</span>
                          <span style={{ fontSize: '0.75rem', color: 'var(--gray-500)', marginTop: '0.15rem', lineHeight: 1.2 }}>{opt.label}</span>
                        </label>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Section 3: Comments & Suggestions */}
          <div className="form-section">
            <h3 className="form-section-title">
              03 &nbsp; Comments / Suggestions
            </h3>
            {form.Questions.filter((q) => q.questionType === 'TEXT').map((q) => (
              <div key={q.id}>
                <label style={labelStyle}>{q.questionText}</label>
                <textarea
                  name={`question_${q.id}`}
                  rows={5}
                  placeholder="Type your comments or suggestions here..."
                  style={{
                    ...inputStyle,
                    resize: 'vertical',
                    minHeight: '120px',
                  }}
                />
              </div>
            ))}
          </div>

          {/* Section 4: E-Signature (Electronic Signature) */}
          <div className="form-section">
            <h3 className="form-section-title">
              04 &nbsp; Respondent E-Signature (Lagda)
            </h3>
            <p style={{ fontSize: '0.875rem', color: 'var(--gray-500)', margin: '0 0 1rem', lineHeight: 1.5 }}>
              Please provide your signature below using your finger (touchscreen) or mouse. This will be officially recorded on your feedback submission.
            </p>
            <input type="hidden" name="signatureData" value={signatureData || ''} />
            <SignaturePad onSignatureChange={setSignatureData} />
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            disabled={isPending}
            className="btn btn-primary"
            style={{
              padding: '1.25rem',
              fontSize: '0.9375rem',
              width: '100%',
              marginTop: '0.5rem',
            }}
          >
            {isPending ? 'Submitting Feedback…' : 'Submit Stakeholder Feedback →'}
          </button>
        </form>

        {/* Footer Code matching photo */}
        <div style={{
          marginTop: '2rem',
          paddingTop: '1.25rem',
          borderTop: 'var(--hairline)',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          color: 'var(--gray-500)',
          fontSize: '0.8125rem',
          gap: '1rem',
          flexWrap: 'wrap',
        }}>
          <span>CvSU Imus Campus — Stakeholder Feedback Management System</span>
          <span>V01-2018-06-19</span>
        </div>
      </div>

      <style>{`
        .hrdo-badge {
          background: var(--bg);
          color: var(--ink);
          padding: 0.3rem 0.7rem;
          border-radius: var(--radius-xs);
          font-family: var(--font-mono);
          font-size: 0.75rem;
          font-weight: 600;
          letter-spacing: 0.08em;
          display: inline-block;
          margin-bottom: 0.75rem;
        }

        .main-container-card {
          background: var(--bg);
          border-radius: 0 0 var(--radius-lg) var(--radius-lg);
          padding: 2rem 1.75rem;
          border: var(--hairline);
          border-top: none;
          box-shadow: var(--shadow-card);
        }

        .form-section {
          background: var(--gray-50);
          border: var(--hairline);
          border-radius: var(--radius-lg);
          padding: 1.5rem;
        }

        .form-section-title {
          font-family: var(--font-mono);
          font-size: 0.8125rem;
          font-weight: 600;
          letter-spacing: 0.04em;
          text-transform: uppercase;
          color: var(--ink);
          margin: 0 0 1.25rem;
          padding-bottom: 0.75rem;
          border-bottom: var(--hairline);
          display: flex;
          align-items: center;
          justify-content: space-between;
          flex-wrap: wrap;
          gap: 0.5rem;
        }

        .responsive-grid-2 {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 1.25rem;
          margin-bottom: 1.25rem;
        }

        .category-selection-container {
          display: grid !important;
          grid-template-columns: repeat(auto-fill, minmax(260px, 1fr)) !important;
          gap: 0.6rem !important;
        }

        .category-box-label {
          box-sizing: border-box;
          width: 100%;
        }

        .rating-options-grid {
          display: grid;
          grid-template-columns: repeat(5, 1fr);
          gap: 0.6rem;
        }

        .rating-box-label {
          box-sizing: border-box;
          width: 100%;
        }

        .rating-box-label:hover {
          border-color: var(--ink) !important;
          background: var(--gray-50) !important;
        }

        @media (min-width: 769px) {
          .hrdo-badge {
            position: absolute;
            top: 1.25rem;
            right: 1.25rem;
            margin-bottom: 0;
          }
        }

        @media (max-width: 768px) {
          .main-container-card {
            padding: 1rem !important;
          }
          .form-section {
            padding: 1.25rem !important;
          }
          .responsive-grid-2 {
            grid-template-columns: 1fr !important;
          }
          .category-selection-container {
            grid-template-columns: 1fr !important;
          }
          .rating-options-grid {
            grid-template-columns: 1fr !important;
          }
          .rating-box-label {
            flex-direction: row !important;
            justify-content: flex-start !important;
            padding: 0.8rem 1rem !important;
            gap: 0.75rem !important;
            min-height: 50px !important;
            text-align: left !important;
          }
          .rating-box-label input[type="radio"] {
            margin-bottom: 0 !important;
          }
        }
      `}</style>
    </div>
  );
}