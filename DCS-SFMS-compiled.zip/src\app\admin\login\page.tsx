'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import ThemeToggle from '@/components/ThemeToggle';

export default function LoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });

      const data = await res.json();

      if (!res.ok) {
        setError(data.error || 'Login failed.');
        setLoading(false);
        return;
      }

      router.push('/admin/dashboard');
    } catch {
      setError('An unexpected error occurred.');
      setLoading(false);
    }
  };

  return (
    <div style={{
      minHeight: '100vh',
      display: 'flex',
      flexDirection: 'column',
      background: 'var(--bg)',
      fontFamily: 'var(--font-body)',
      position: 'relative',
      zIndex: 1,
    }}>
      {/* Top bar */}
      <header style={{
        maxWidth: '1200px', width: '100%', margin: '0 auto',
        padding: '1.5rem 1.5rem', display: 'flex', justifyContent: 'space-between', alignItems: 'center',
        borderBottom: 'var(--hairline)',
      }}>
        <Link href="/" style={{ fontFamily: 'var(--font-mono)', fontSize: '0.8125rem', color: 'var(--ink)', textDecoration: 'none' }}>
          ← back to landing
        </Link>
        <ThemeToggle />
      </header>

      <main style={{
        flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center',
        padding: '2rem 1rem',
      }}>
        <form onSubmit={handleSubmit} style={{
          width: '100%', maxWidth: '420px',
          background: 'var(--gray-50)', border: 'var(--hairline)',
          borderRadius: 'var(--radius-lg)', padding: '2.5rem', boxShadow: 'var(--shadow-card)',
          display: 'grid', gap: '1.25rem',
        }}>
          <div>
            <span className="num-label">01 — portal</span>
            <h1 style={{ fontFamily: 'var(--font-mono)', fontSize: '1.5rem', fontWeight: 600, letterSpacing: '-0.01em', margin: '0 0 0.75rem' }}>
              Sign in to Portal
            </h1>
            <p className="microlabel" style={{ color: 'var(--gray-500)', margin: 0 }}>
              Enter your admin credentials to manage forms and view analytics
            </p>
          </div>

          {error && (
            <div role="alert" style={{
              border: 'var(--hairline)', borderRadius: 'var(--radius-sm)',
              padding: '0.75rem 1rem', fontSize: '0.875rem', fontWeight: 600,
              color: 'var(--danger)', background: 'var(--bg)',
            }}>
              ⚠ {error}
            </div>
          )}

          <div style={{ display: 'grid', gap: '0.4rem' }}>
            <label className="microlabel" htmlFor="email" style={{ color: 'var(--gray-500)' }}>Email Address</label>
            <input
              id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="admin@sfms.local"
              required
              className="input"
            />
          </div>

          <div style={{ display: 'grid', gap: '0.4rem' }}>
            <label className="microlabel" htmlFor="password" style={{ color: 'var(--gray-500)' }}>Password</label>
            <input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              required
              className="input"
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="btn btn-primary"
            style={{ width: '100%', padding: '0.85rem', fontSize: '0.875rem' }}
          >
            {loading ? 'authenticating…' : 'sign in →'}
          </button>

          <p className="microlabel" style={{ textAlign: 'center', color: 'var(--gray-400)' }}>
            CvSU HRDO-QF-07 compliant system
          </p>
        </form>
      </main>
    </div>
  );
}