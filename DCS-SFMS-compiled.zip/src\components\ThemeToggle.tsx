'use client';

import { useEffect, useState } from 'react';

type Theme = 'light' | 'dark' | 'system';

function getSystemTheme(): 'light' | 'dark' {
  return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
}

export default function ThemeToggle() {
  const [theme, setTheme] = useState<Theme>('system');

  useEffect(() => {
    const stored = localStorage.getItem('bm-theme') as Theme | null;
    if (stored) {
      // Read cached theme after mount to keep SSR markup deterministic.
      // eslint-disable-next-line react-hooks/set-state-in-effect
      setTheme(stored);
    }
  }, []);

  useEffect(() => {
    const apply = () => {
      const resolved = theme === 'system' ? getSystemTheme() : theme;
      document.documentElement.setAttribute('data-theme', resolved);
    };
    apply();
    localStorage.setItem('bm-theme', theme);

    if (theme === 'system') {
      const mql = window.matchMedia('(prefers-color-scheme: dark)');
      mql.addEventListener('change', apply);
      return () => mql.removeEventListener('change', apply);
    }
  }, [theme]);

  const cycle = () => {
    const order: Theme[] = ['system', 'light', 'dark'];
    const next = order[(order.indexOf(theme) + 1) % order.length];
    setTheme(next);
  };

  const label = theme === 'system' ? 'sys' : theme;

  return (
    <button
      type="button"
      onClick={cycle}
      title="Toggle theme (system / light / dark)"
      style={{
        background: 'transparent',
        border: 'none',
        cursor: 'pointer',
        fontFamily: 'var(--font-mono)',
        fontSize: '0.625rem',
        letterSpacing: '0.12em',
        textTransform: 'uppercase',
        color: 'var(--gray-400)',
        padding: '0.25rem 0.25rem',
        transition: 'color var(--motion-1)',
        display: 'inline-flex',
        alignItems: 'center',
        gap: '0.4rem',
      }}
    >
      <span style={{ fontSize: '0.85rem', lineHeight: 1 }}>{theme === 'light' ? '◐' : theme === 'dark' ? '◑' : '◓'}</span>
      theme: {label}
    </button>
  );
}