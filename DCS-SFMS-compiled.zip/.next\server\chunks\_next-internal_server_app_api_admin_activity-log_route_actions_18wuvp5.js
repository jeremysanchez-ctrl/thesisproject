module.exports=[60096,(__turbopack_context__,module1,exports)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_activity-log_route_actions_18wuvp5.js.map