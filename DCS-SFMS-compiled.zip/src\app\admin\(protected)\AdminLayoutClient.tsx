'use client';

import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { useState } from 'react';
import ThemeToggle from '@/components/ThemeToggle';

interface SessionPayload {
  userId: string;
  email: string;
  name: string;
  role: string;
}

const navItems = [
  { href: '/admin/dashboard', label: 'dashboard', roles: ['SUPER_ADMIN', 'ADMIN', 'DEPT_HEAD', 'QA_OFFICER'] },
  { href: '/admin/forms', label: 'form builder', roles: ['SUPER_ADMIN', 'ADMIN'] },
  { href: '/admin/qr-codes', label: 'qr access', roles: ['SUPER_ADMIN', 'ADMIN'] },
  { href: '/admin/archive', label: 'trash / archive', roles: ['SUPER_ADMIN', 'ADMIN'] },
  { href: '/admin/reports', label: 'reports', roles: ['SUPER_ADMIN', 'ADMIN', 'DEPT_HEAD', 'QA_OFFICER'] },
  { href: '/admin/report-requests', label: 'report approvals', roles: ['SUPER_ADMIN', 'ADMIN'] },
  { href: '/admin/users', label: 'user management', roles: ['SUPER_ADMIN'] },
  { href: '/admin/system-control', label: 'system control', roles: ['SUPER_ADMIN'] },
  { href: '/admin/activity-log', label: 'activity log', roles: ['SUPER_ADMIN'] },
  { href: '/admin/credits', label: 'credits', roles: ['SUPER_ADMIN', 'ADMIN', 'DEPT_HEAD', 'QA_OFFICER'] },
];

export default function AdminLayoutClient({ session, children }: { session: SessionPayload; children: React.ReactNode }) {
  const pathname = usePathname();
  const router = useRouter();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const availableNavItems = navItems.filter((item) => item.roles.includes(session.role));

  const handleLogout = async () => {
    await fetch('/api/auth/logout', { method: 'POST' });
    router.push('/admin/login');
  };

  return (
    <>
      <style>{`
        .admin-layout { display: flex; min-height: 100vh; background: var(--bg); }
        .admin-sidebar {
          width: 14rem;
          flex-shrink: 0;
          border-right: var(--hairline);
          background: var(--bg);
          display: flex;
          flex-direction: column;
          position: sticky;
          top: 0;
          height: 100vh;
          overflow-y: auto;
          z-index: 50;
          transition: transform var(--motion-2);
        }
        .admin-main {
          flex: 1;
          min-width: 0;
          padding: 3.5rem 1.5rem;
          position: relative;
          z-index: 1;
        }
        .top-bar { display: none; }
        .hamburger-btn { display: none; }
        .sidebar-backdrop { display: none; }

        @media (max-width: 1023px) {
          .top-bar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 1rem;
            position: sticky;
            top: 0;
            z-index: 1001;
            padding: 0.8rem 1rem;
            background: color-mix(in srgb, var(--bg) 90%, transparent);
            backdrop-filter: blur(8px);
            -webkit-backdrop-filter: blur(8px);
            border-bottom: var(--hairline);
          }
          .hamburger-btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 40px;
            height: 40px;
            border: var(--hairline);
            border-radius: var(--radius-sm);
            background: var(--bg);
            color: var(--ink);
            cursor: pointer;
            font-size: 1.2rem;
          }
          .admin-sidebar {
            position: fixed;
            top: 0;
            left: 0;
            bottom: 0;
            z-index: 1000;
            height: 100vh;
            transform: translateX(-100%);
            box-shadow: var(--shadow-modal);
          }
          .admin-sidebar.open { transform: translateX(0); }
          .sidebar-backdrop {
            display: block;
            position: fixed;
            inset: 0;
            background: rgba(0, 0, 0, 0.4);
            z-index: 999;
            opacity: 0;
            pointer-events: none;
            transition: opacity var(--motion-1);
          }
          .sidebar-backdrop.open { opacity: 1; pointer-events: auto; }
          .admin-main { padding: 2rem 1rem; }
        }
      `}</style>

      <div className="admin-layout">
        {/* Mobile top bar */}
        <div className="top-bar">
          <button className="hamburger-btn" onClick={() => setSidebarOpen(!sidebarOpen)} aria-label="Toggle menu">
            {sidebarOpen ? '✕' : '☰'}
          </button>
          <div style={{ textAlign: 'right' }}>
            <span className="microlabel" style={{ display: 'block', lineHeight: 1.2 }}>DCS · SFMS</span>
            <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.8125rem', color: 'var(--ink)' }}>admin</span>
          </div>
        </div>

        <div className={`sidebar-backdrop ${sidebarOpen ? 'open' : ''}`} onClick={() => setSidebarOpen(false)} />

        <aside className={`admin-sidebar ${sidebarOpen ? 'open' : ''}`}>
          <div style={{ padding: '1.5rem 1.25rem', borderBottom: 'var(--hairline)' }}>
            <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: '0.75rem' }}>
              <span className="chip-inverted">CvSU — Imus</span>
              <ThemeToggle />
            </div>
            <h2 style={{ fontFamily: 'var(--font-mono)', fontSize: '1.05rem', fontWeight: 600, letterSpacing: '-0.01em', margin: 0, lineHeight: 1.3 }}>
              Stakeholder Feedback
              <br />
              Management System
            </h2>
            <p className="microlabel" style={{ marginTop: '0.5rem' }}>Department of Computer Studies</p>
          </div>

          <nav style={{ flex: 1, padding: '1rem 0.75rem', display: 'flex', flexDirection: 'column' }}>
            {availableNavItems.map((item, idx) => {
              const isActive = pathname.startsWith(item.href);
              return (
                <div key={item.href} style={{ borderTop: idx === 0 ? 'none' : 'var(--hairline)', padding: '0.15rem 0' }}>
                  <Link
                    href={item.href}
                    onClick={() => setSidebarOpen(false)}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '0.6rem',
                      padding: '0.6rem 0.7rem',
                      textDecoration: 'none',
                      color: isActive ? 'var(--primary)' : 'var(--gray-500)',
                      fontFamily: 'var(--font-mono)',
                      fontSize: '0.8125rem',
                      letterSpacing: '0.02em',
                      fontWeight: isActive ? 600 : 400,
                      transition: 'color var(--motion-1)',
                    }}
                    onMouseEnter={(e) => {
                      if (!isActive) e.currentTarget.style.color = 'var(--primary)';
                    }}
                    onMouseLeave={(e) => {
                      if (!isActive) e.currentTarget.style.color = 'var(--gray-500)';
                    }}
                  >
                    <span style={{ opacity: isActive ? 1 : 0, transition: 'opacity var(--motion-1)', fontWeight: 600, color: 'var(--primary)' }}>
                      {String(idx + 1).padStart(2, '0')}
                    </span>
                    <span style={{ color: isActive ? 'var(--primary)' : 'inherit' }}>{isActive ? '→' : <span style={{ opacity: 0 }}>→</span>}</span>
                    <span style={{ letterSpacing: '0.04em' }}>{item.label}</span>
                  </Link>
                </div>
              );
            })}
          </nav>

          <div style={{ padding: '1rem 1.25rem', borderTop: 'var(--hairline)' }}>
            <p className="microlabel" style={{ marginBottom: '0.35rem' }}>Signed in as</p>
            <p style={{ fontSize: '0.8125rem', fontWeight: 600, color: 'var(--ink)', marginBottom: '0.1rem' }}>{session.name}</p>
            <p className="microlabel" style={{ marginBottom: '0.9rem' }}>{session.role}</p>
            <button
              onClick={handleLogout}
              className="btn btn-ghost"
              style={{ width: '100%', fontSize: '0.75rem' }}
            >
              ← sign out
            </button>
          </div>
        </aside>

        <main className="admin-main">{children}</main>
      </div>
    </>
  );
}