module.exports=[57665,(__turbopack_context__,module1,exports)=>{}];

//# sourceMappingURL=_next-internal_server_app__not-found_page_actions_0pt47yr.js.map