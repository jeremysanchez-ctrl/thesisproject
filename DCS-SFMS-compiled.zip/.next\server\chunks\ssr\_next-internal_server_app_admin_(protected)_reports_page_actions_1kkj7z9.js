module.exports=[27660,(__turbopack_context__,module1,exports)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_%28protected%29_reports_page_actions_1kkj7z9.js.map