module.exports=[762,(__turbopack_context__,module1,exports)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_report-requests_route_actions_1yuivq0.js.map