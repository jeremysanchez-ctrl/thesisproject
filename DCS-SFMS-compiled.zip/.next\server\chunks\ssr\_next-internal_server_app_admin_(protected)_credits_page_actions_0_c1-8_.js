module.exports=[19464,(__turbopack_context__,module1,exports)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_%28protected%29_credits_page_actions_0_c1-8_.js.map