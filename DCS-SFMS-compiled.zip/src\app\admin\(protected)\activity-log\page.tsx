import { prisma } from '@/lib/prisma';
import { requireAuth } from '@/lib/auth';
import { redirect } from 'next/navigation';
import PageGuideNote from '@/components/PageGuideNote';
import ActivityLogActions from './ActivityLogActions';

export default async function ActivityLogPage() {
  const session = await requireAuth();
  if (session.role !== 'SUPER_ADMIN') {
    redirect('/admin/dashboard');
  }

  const logs = await prisma.auditLog.findMany({
    include: { user: { select: { name: true, email: true, role: true } } },
    orderBy: { createdAt: 'desc' },
    take: 200,
  });

  const actionColor = (action: string) => {
    if (action.includes('DELETE') || action.includes('REJECT') || action.includes('SHUTDOWN')) return 'var(--danger)';
    if (action.includes('CREATE') || action.includes('APPROVE') || action.includes('RESTORE')) return 'var(--positive)';
    return 'var(--gray-600)';
  };

  return (
    <div className="content-wrap" style={{ display: 'grid', gap: '1.75rem' }}>
      <header className="rise">
        <span className="num-label">09 — security & audit</span>
        <h1 className="page-title" style={{ fontSize: 'clamp(1.8rem, 4vw, 2.6rem)' }}>Activity Log History</h1>
        <p className="page-desc">
          Chronological record of operations performed by users and administrators. Logs cannot be modified.
        </p>
      </header>

      <PageGuideNote
        pageTitle="Activity Log"
        overview="The activity log tracks all critical actions taken inside the system, documenting the administrator name, role, date, time, and specific operational details for compliance auditing."
        steps={[
          { title: 'Immutable Log Policy', description: 'Logs are stored permanently and cannot be cleared by ordinary admins or users.' },
          { title: 'Purge & Archive Policy', description: 'Super Admins can archive logs to PDF format and purge records older than 30 days.' }
        ]}
      />

      <div className="rise rise-1"><ActivityLogActions /></div>

      <section className="card rise rise-2" style={{ padding: '1.5rem', background: 'var(--bg)' }}>
        <div className="table-scroll">
          <table className="table">
            <thead>
              <tr>
                <th>Timestamp</th>
                <th>User / Account</th>
                <th>Role</th>
                <th>Action</th>
                <th>Details</th>
              </tr>
            </thead>
            <tbody>
              {logs.length === 0 ? (
                <tr>
                  <td colSpan={5} style={{ padding: '2rem', textAlign: 'center', color: 'var(--gray-500)' }}>
                    No activities recorded in the log yet.
                  </td>
                </tr>
              ) : logs.map((log) => (
                <tr key={log.id}>
                  <td style={{ whiteSpace: 'nowrap', color: 'var(--gray-500)', fontFamily: 'var(--font-mono)', fontSize: '0.8125rem' }}>
                    {new Date(log.createdAt).toLocaleString()}
                  </td>
                  <td>
                    <strong style={{ color: 'var(--ink)', display: 'block', fontWeight: 600 }}>{log.user.name}</strong>
                    <span className="microlabel" style={{ color: 'var(--gray-400)' }}>{log.user.email}</span>
                  </td>
                  <td>
                    <span className={log.user.role === 'SUPER_ADMIN' ? 'chip-inverted' : 'chip'}>{log.user.role.toLowerCase()}</span>
                  </td>
                  <td>
                    <span style={{
                      fontWeight: 600, fontFamily: 'var(--font-mono)', fontSize: '0.8125rem',
                      color: actionColor(log.action),
                    }}>
                      {log.action}
                    </span>
                  </td>
                  <td style={{ color: 'var(--gray-600)' }}>{log.description}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}