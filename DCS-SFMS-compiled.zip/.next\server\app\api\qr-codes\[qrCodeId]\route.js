var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/qr-codes/[qrCodeId]/route.js")
R.c("server/chunks/[root-of-the-server]__1__i0_3._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/[root-of-the-server]__1x_1hss._.js")
R.c("server/chunks/_next-internal_server_app_api_qr-codes_[qrCodeId]_route_actions_1063pyw.js")
R.m(97846)
module.exports=R.m(97846).exports
