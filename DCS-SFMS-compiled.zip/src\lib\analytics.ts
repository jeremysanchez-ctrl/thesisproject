import { prisma } from '@/lib/prisma';

export type DashboardData = Awaited<ReturnType<typeof getDashboardData>>;
export type ReportRow = Awaited<ReturnType<typeof getReportRows>>[number];

const positiveLikert = new Set(['5 - highly satisfied', '4 - very satisfied', 'strongly agree', 'agree']);

function getNumericScore(answerValue: string): number | null {
  const normalized = answerValue.trim().toLowerCase();
  const match = normalized.match(/^([1-5])/);
  if (match) return parseInt(match[1], 10);
  const num = Number(normalized);
  if (Number.isFinite(num) && num >= 1 && num <= 5) return Math.round(num);
  if (positiveLikert.has(normalized)) return 5;
  return null;
}

export async function getDashboardData() {
  const [forms, responses, qrCodes, categories, events] = await Promise.all([
    prisma.surveyForm.findMany({
      include: {
        event: true,
        _count: { select: { Questions: true, Responses: true } },
      },
      orderBy: { createdAt: 'desc' },
    }),
    prisma.response.findMany({
      where: { isArchived: false },
      include: {
        stakeholderCategory: true,
        form: { include: { event: true } },
        Answers: { include: { question: true } },
      },
      orderBy: { submittedAt: 'asc' },
    }),
    prisma.qRCode.findMany({
      where: { archivedAt: null },
      include: { event: true },
      orderBy: { scanCount: 'desc' },
    }),
    prisma.stakeholderCategory.findMany({ orderBy: { name: 'asc' } }),
    prisma.event.findMany({ orderBy: { createdAt: 'desc' } }),
  ]);

  // 1. Respondents per Semester (Req #11)
  const semesterMap: Record<string, number> = {
    'First Semester': 0,
    'Midyear': 0,
    'Second Semester': 0,
  };

  // 2. Purpose of Visit per Semester (Req #12)
  const purposeSemesterMap: Record<string, Record<string, number>> = {
    'First Semester': {},
    'Midyear': {},
    'Second Semester': {},
  };

  // 3. Question Satisfaction Scores (Req #13)
  const questionScoreMap = new Map<string, { title: string; totalScore: number; count: number }>();

  // 4. Stakeholder Breakdown & Demographics (Req #14)
  const stakeholderMap = new Map<string, number>();
  const purposeMap = new Map<string, number>();

  let scoredAnswersCount = 0;
  let totalSatisfactionSum = 0;

  for (const resp of responses) {
    const sem = resp.form.semester || 'First Semester';
    semesterMap[sem] = (semesterMap[sem] || 0) + 1;

    const categoryName = resp.stakeholderCategory.name;
    stakeholderMap.set(categoryName, (stakeholderMap.get(categoryName) || 0) + 1);

    const purpose = resp.purposeOfVisit?.trim() || 'General Inquiry';
    purposeMap.set(purpose, (purposeMap.get(purpose) || 0) + 1);

    if (!purposeSemesterMap[sem]) purposeSemesterMap[sem] = {};
    purposeSemesterMap[sem][purpose] = (purposeSemesterMap[sem][purpose] || 0) + 1;

    for (const ans of resp.Answers) {
      const score = getNumericScore(ans.answerValue);
      if (score !== null) {
        scoredAnswersCount++;
        totalSatisfactionSum += score;

        const qTitle = ans.question.questionText;
        const existing = questionScoreMap.get(qTitle) || { title: qTitle, totalScore: 0, count: 0 };
        existing.totalScore += score;
        existing.count += 1;
        questionScoreMap.set(qTitle, existing);
      }
    }
  }

  // Calculate Most & Least Satisfied Concerns
  const questionAverages = [...questionScoreMap.values()].map((item) => ({
    question: item.title,
    average: parseFloat((item.totalScore / item.count).toFixed(2)),
    count: item.count,
  }));

  const sortedQuestions = [...questionAverages].sort((a, b) => b.average - a.average);
  const mostSatisfied = sortedQuestions.slice(0, 5);
  const leastSatisfied = sortedQuestions.slice(-5).reverse();

  // Find Most Common Stakeholder & Most Common Purpose
  let mostCommonStakeholder = 'N/A';
  let maxStakeholderCount = 0;
  for (const [stk, count] of stakeholderMap.entries()) {
    if (count > maxStakeholderCount) {
      maxStakeholderCount = count;
      mostCommonStakeholder = stk;
    }
  }

  let mostCommonPurpose = 'N/A';
  let maxPurposeCount = 0;
  for (const [purp, count] of purposeMap.entries()) {
    if (count > maxPurposeCount) {
      maxPurposeCount = count;
      mostCommonPurpose = purp;
    }
  }

  // Active AY and Semester from latest active form
  const activeForm = forms.find((f) => f.status === 'ACTIVE') || forms[0];
  const currentAcademicYear = activeForm?.academicYear || 'AY 2026–2027';
  const currentSemester = activeForm?.semester || 'First Semester';

  const overallSatisfactionRate = scoredAnswersCount === 0
    ? 0
    : Math.round((totalSatisfactionSum / (scoredAnswersCount * 5)) * 100);

  return {
    totals: {
      totalRespondents: responses.length,
      currentAcademicYear,
      currentSemester,
      mostCommonStakeholder,
      mostCommonPurpose,
      forms: forms.length,
      activeForms: forms.filter((f) => f.status === 'ACTIVE').length,
      events: events.length,
      categories: categories.length,
      qrCodes: qrCodes.length,
      scans: qrCodes.reduce((sum, qr) => sum + qr.scanCount, 0),
      satisfactionRate: overallSatisfactionRate,
    },
    respondentsPerSemester: Object.entries(semesterMap).map(([semester, count]) => ({ semester, count })),
    purposePerSemester: Object.entries(purposeSemesterMap).map(([semester, purposes]) => ({
      semester,
      purposes: Object.entries(purposes).map(([purpose, count]) => ({ purpose, count })),
    })),
    questionSatisfaction: {
      mostSatisfied,
      leastSatisfied,
      all: questionAverages,
    },
    stakeholderBreakdown: [...stakeholderMap.entries()].map(([name, count]) => ({ name, count })),
    purposeBreakdown: [...purposeMap.entries()].map(([name, count]) => ({ name, count })),
    topQrCodes: qrCodes.slice(0, 5).map((qr) => ({
      id: qr.id,
      eventName: qr.event.name,
      scanCount: qr.scanCount,
      expiresAt: qr.expiresAt?.toISOString() ?? null,
    })),
    recentResponses: responses.slice(-8).reverse().map((resp) => ({
      id: resp.id,
      controlNo: resp.controlNo || 'SFMS-N/A',
      formTitle: resp.form.title,
      eventName: resp.form.event.name,
      department: resp.department || 'N/A',
      categoryName: resp.stakeholderCategory.name,
      dateOfVisit: resp.dateOfVisit || 'N/A',
      hardCopyPhotoUrl: resp.hardCopyPhotoUrl || null,
      submittedAt: resp.submittedAt.toISOString(),
    })),
  };
}

export async function getReportRows() {
  const responses = await prisma.response.findMany({
    where: { isArchived: false },
    include: {
      stakeholderCategory: true,
      form: { include: { event: true } },
      Answers: { include: { question: true }, orderBy: { question: { order: 'asc' } } },
    },
    orderBy: { submittedAt: 'desc' },
  });

  return responses.flatMap((response) =>
    response.Answers.map((answer) => ({
      controlNo: response.controlNo ?? '',
      academicYear: response.form.academicYear ?? 'AY 2026–2027',
      semester: response.form.semester ?? 'First Semester',
      submittedAt: response.submittedAt.toISOString(),
      dateOfVisit: response.dateOfVisit ?? response.transactionDate ?? '',
      transactionDate: response.dateOfVisit ?? response.transactionDate ?? '',
      stakeholderCategory: response.stakeholderCategory.name,
      name: response.name ?? '',
      agency: response.agency ?? response.organization ?? '',
      email: response.email ?? '',
      contactNumber: response.contactNumber ?? '',
      purposeOfVisit: response.purposeOfVisit ?? '',
      attendingStaff: response.attendingStaff ?? '',
      sex: response.sex ?? '',
      age: response.age ?? '',
      serviceAvailed: response.serviceAvailed ?? '',
      event: response.form.event.name,
      department: response.department ?? 'Department of Computer Studies (DCS)',
      form: response.form.title,
      formVersion: response.form.version,
      question: answer.question.questionText,
      questionType: answer.question.questionType,
      answer: answer.answerValue,
    })),
  );
}
