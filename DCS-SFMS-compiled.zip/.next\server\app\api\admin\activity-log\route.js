var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/activity-log/route.js")
R.c("server/chunks/[root-of-the-server]__1in6hr8._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_0htkyro._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_activity-log_route_actions_18wuvp5.js")
R.m(8841)
module.exports=R.m(8841).exports
