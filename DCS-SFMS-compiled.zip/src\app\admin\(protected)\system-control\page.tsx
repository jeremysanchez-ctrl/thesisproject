import { requireAuth } from '@/lib/auth';
import { redirect } from 'next/navigation';
import PageGuideNote from '@/components/PageGuideNote';
import SystemControlClient from './SystemControlClient';

export default async function SystemControlPage() {
  const session = await requireAuth();
  if (session.role !== 'SUPER_ADMIN') {
    redirect('/admin/dashboard');
  }

  return (
    <div className="content-wrap" style={{ display: 'grid', gap: '1.75rem' }}>
      <header className="rise">
        <span className="num-label">08 — system maintenance</span>
        <h1 className="page-title" style={{ fontSize: 'clamp(1.8rem, 4vw, 2.6rem)' }}>System Control &amp; Shutdown</h1>
        <p className="page-desc">
          Manage the background server processes directly from the browser window.
        </p>
      </header>

      <PageGuideNote
        pageTitle="System Control"
        overview="This maintenance screen permits Super Administrators to view status details and safely shut down the backend Node processes remotely."
        steps={[
          { title: 'Remote Shutdown', description: 'Gracefully halts the PM2 application process running on the host system.' },
          { title: 'Restarting Server', description: 'If shut down, the system must be manually turned back on using the Desktop startup script.' }
        ]}
      />

      <div className="rise rise-1">
        <SystemControlClient />
      </div>
    </div>
  );
}