import QRCodeManager from './QRCodeManager';
import QRCodeList from './QRCodeList';
import { prisma } from '@/lib/prisma';
import { requireAuth } from '@/lib/auth';
import { redirect } from 'next/navigation';
import { getAppUrl } from '@/lib/appUrl';
import PageGuideNote from '@/components/PageGuideNote';

export default async function QRCodesPage() {
  const session = await requireAuth();
  if (!['SUPER_ADMIN', 'ADMIN'].includes(session.role)) {
    redirect('/admin/dashboard');
  }
  const [events, qrCodes] = await Promise.all([
    prisma.event.findMany({
      include: { Forms: { where: { status: 'ACTIVE' }, orderBy: { createdAt: 'desc' }, take: 1 } },
      orderBy: { createdAt: 'desc' },
    }),
    prisma.qRCode.findMany({
      where: { archivedAt: null },
      include: { event: { include: { Forms: true } } },
      orderBy: { createdAt: 'desc' }
    }),
  ]);
  const baseUrl = await getAppUrl();

  return (
    <div className="content-wrap" style={{ display: 'grid', gap: '1.75rem' }}>
      <header className="rise">
        <span className="num-label">03 — qr access</span>
        <h1 className="page-title" style={{ fontSize: 'clamp(1.8rem, 4vw, 2.6rem)' }}>Generate Event QR Codes</h1>
        <p className="page-desc">Each scan is tracked in real-time and routes respondents directly to the event&apos;s active survey form.</p>
      </header>

      <PageGuideNote
        pageTitle="QR Access"
        overview="QR Access allows Administrators to generate downloadable QR code images for active campus events and configure public server/ngrok URLs for seamless mobile phone scanning."
        steps={[
          { title: 'Set Public / Ngrok URL', description: 'Enter or paste your free Ngrok URL (e.g. https://xxxx.ngrok-free.app) or LAN IP in the configurator field so phones on external networks can scan.' },
          { title: 'Select Event & Generate', description: 'Pick an active campus event and click Generate QR Code to create a unique scannable QR image.' },
          { title: 'Download & Share', description: 'Download high-resolution PNG QR images to display at event counters, windows, or bulletin boards.' }
        ]}
      />

      <div className="rise rise-1">
        <QRCodeManager
          currentAppUrl={baseUrl}
          events={events.map((event) => ({
            id: event.id,
            name: event.name,
            department: event.department,
            activeFormTitle: event.Forms[0]?.title ?? null,
          }))}
        />
      </div>

      <section className="rise rise-2">
        <p className="microlabel" style={{ marginBottom: '0.75rem' }}>generated codes</p>
        <h2 style={{ fontFamily: 'var(--font-mono)', fontSize: '1.05rem', fontWeight: 600, margin: '0 0 1rem' }}>Generated QR Codes</h2>
        <QRCodeList qrCodes={qrCodes} baseUrl={baseUrl} />
      </section>
    </div>
  );
}