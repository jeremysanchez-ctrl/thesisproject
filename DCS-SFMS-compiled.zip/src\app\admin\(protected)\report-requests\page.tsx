import { prisma } from '@/lib/prisma';
import { requireAuth } from '@/lib/auth';
import { redirect } from 'next/navigation';
import PageGuideNote from '@/components/PageGuideNote';
import ReportRequestsClient from './ReportRequestsClient';

export default async function ReportRequestsPage() {
  const session = await requireAuth();
  if (!['SUPER_ADMIN', 'ADMIN'].includes(session.role)) {
    redirect('/admin/dashboard');
  }

  // Super admins see ALL requests (for approval/rejection)
  // Regular admins see only their OWN requests
  const requests = await prisma.reportRequest.findMany({
    where: session.role === 'SUPER_ADMIN'
      ? { requester: { role: { not: 'SUPER_ADMIN' } } }   // exclude fellow super-admin self-requests
      : { requestedBy: session.userId },
    include: { requester: { select: { name: true, email: true } } },
    orderBy: { requestedAt: 'desc' }
  });

  const serializedRequests = requests.map(r => ({
    id: r.id,
    academicYear: r.academicYear,
    semester: r.semester,
    reportType: r.reportType,
    status: r.status,
    rejectionNote: r.rejectionNote,
    requestedAt: r.requestedAt.toISOString(),
    requester: {
      name: r.requester.name,
      email: r.requester.email
    }
  }));

  return (
    <div className="content-wrap" style={{ display: 'grid', gap: '1.75rem' }}>
      <header className="rise">
        <span className="num-label">06 — compliance & audit</span>
        <h1 className="page-title" style={{ fontSize: 'clamp(1.8rem, 4vw, 2.6rem)' }}>Report Generation Approvals</h1>
        <p className="page-desc">
          {session.role === 'SUPER_ADMIN'
            ? 'Review and approve or decline report requests submitted by Admins.'
            : 'Submit report requests and track their approval status.'}
        </p>
      </header>

      <PageGuideNote
        pageTitle="Report Approvals"
        overview={
          session.role === 'SUPER_ADMIN'
            ? 'As Super Admin, you can approve or decline report download requests from other administrators. You do not need to file requests yourself — you can download any report directly.'
            : 'To prevent unauthorized data distribution, report generation is protected. Submit a request, and wait for Super Admin approval before the download becomes available.'
        }
        steps={
          session.role === 'SUPER_ADMIN'
            ? [
                { title: 'Review Pending Requests', description: 'Admins who need to generate reports must request access. Approve or decline here.' },
                { title: 'Direct Download', description: 'As Super Admin, go to the Reports page to download any report immediately without filing a request.' },
              ]
            : [
                { title: '1. Submit Request', description: 'Select Academic Year, Semester, and Type of report required.' },
                { title: '2. Pending Review', description: 'Your request will be reviewed by a Super Admin.' },
                { title: '3. Download Enabled', description: 'Once approved, the download button is enabled on the Reports page.' },
              ]
        }
      />

      <div className="rise rise-1">
        <ReportRequestsClient
          requests={serializedRequests}
          currentUserId={session.userId}
          userRole={session.role}
        />
      </div>
    </div>
  );
}