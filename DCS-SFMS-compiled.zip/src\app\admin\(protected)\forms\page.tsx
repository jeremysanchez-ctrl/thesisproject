import FormBuilder from './FormBuilder';
import FormListClient from './FormListClient';
import { prisma } from '@/lib/prisma';
import { requireAuth } from '@/lib/auth';
import { redirect } from 'next/navigation';
import PageGuideNote from '@/components/PageGuideNote';

export default async function FormsPage() {
  const session = await requireAuth();
  if (!['SUPER_ADMIN', 'ADMIN'].includes(session.role)) {
    redirect('/admin/dashboard');
  }

  const [categories, forms] = await Promise.all([
    prisma.stakeholderCategory.findMany({ orderBy: { name: 'asc' } }),
    prisma.surveyForm.findMany({
      where: { status: { not: 'ARCHIVED' } },
      include: { event: true, _count: { select: { Questions: true, Responses: true } } },
      orderBy: { createdAt: 'desc' },
    }),
  ]);

  return (
    <div className="content-wrap" style={{ display: 'grid', gap: '1.75rem' }}>
      <header className="rise">
        <span className="num-label">02 — form builder</span>
        <h1 className="page-title" style={{ fontSize: 'clamp(1.8rem, 4vw, 2.6rem)' }}>Create &amp; Manage Feedback Forms</h1>
        <p className="page-desc">Set up events, define target stakeholder audiences, and publish tailored questionnaires.</p>
      </header>

      <PageGuideNote
        pageTitle="Form Management"
        overview="Form Management allows Administrators to create custom survey questionnaires linked to specific campus events and stakeholder categories."
        steps={[
          { title: 'Create Event & Form Title', description: 'Enter the event name, department office, and select the target stakeholder category.' },
          { title: 'Define Questions & Rating Scales', description: 'Add 5-point Likert ratings, multiple-choice items, or open text feedback questions.' },
          { title: 'Publish & Version Control', description: 'Toggle forms between ACTIVE and CLOSED status to control response collection.' }
        ]}
      />

      <div className="rise rise-1"><FormBuilder categories={categories} /></div>

      <section className="rise rise-2">
        <p className="microlabel" style={{ marginBottom: '0.75rem' }}>survey archive</p>
        <h2 style={{ fontFamily: 'var(--font-mono)', fontSize: '1.05rem', fontWeight: 600, margin: '0 0 1rem' }}>Existing Survey Forms</h2>
        <FormListClient forms={forms} />
      </section>
    </div>
  );
}