import os from 'os';
import fs from 'fs';
import path from 'path';

/**
 * Resolves the dynamic Base URL for QR codes and public links.
 * Priority:
 *   1. .tunnel_url file if present and valid
 *   2. NEXT_PUBLIC_APP_URL env var (if not localhost)
 *   3. Machine's active local LAN IP address
 *   4. Fallback to localhost
 */
export async function getAppUrl(): Promise<string> {
  const port = process.env.PORT || '3000';

  // 1. Check for live .tunnel_url file dynamically on every request without requiring a server restart
  try {
    const tunnelFilePath = path.join(process.cwd(), '.tunnel_url');
    if (fs.existsSync(tunnelFilePath)) {
      const tunnel = fs.readFileSync(tunnelFilePath, 'utf8').trim();
      if (tunnel.startsWith('http://') || tunnel.startsWith('https://')) {
        return tunnel.replace(/\/$/, '');
      }
    }
  } catch (err) {
    // Ignore read errors
  }

  // 2. Use the configured public URL if it's not localhost
  const envUrl = process.env.NEXT_PUBLIC_APP_URL;
  if (envUrl && !envUrl.includes('localhost') && !envUrl.includes('127.0.0.1')) {
    return envUrl.replace(/\/$/, '');
  }
  
  // 3. Find local network IP address
  const interfaces = os.networkInterfaces();
  for (const name of Object.keys(interfaces)) {
    const networkInterface = interfaces[name];
    if (!networkInterface) continue;
    
    for (const iface of networkInterface) {
      if (iface.family === 'IPv4' && !iface.internal) {
        return `http://${iface.address}:${port}`;
      }
    }
  }

  return `http://localhost:${port}`;
}
