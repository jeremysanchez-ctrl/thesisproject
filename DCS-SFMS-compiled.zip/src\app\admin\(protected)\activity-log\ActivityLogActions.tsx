'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function ActivityLogActions() {
  const [cleaning, setCleaning] = useState(false);
  const router = useRouter();

  const handleCleanup = async () => {
    if (!confirm('⚠ WARNING: This will permanently delete audit logs older than 30 days. Please ensure you have downloaded the PDF archive first. Proceed?')) {
      return;
    }

    setCleaning(true);
    try {
      const res = await fetch('/api/admin/activity-log', {
        method: 'DELETE'
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Cleanup operation failed');
      alert(`Cleanup completed! Removed ${data.count} older log entries.`);
      router.refresh();
      window.location.reload();
    } catch (err) {
      alert(err instanceof Error ? err.message : 'Error executing log cleanup');
    } finally {
      setCleaning(false);
    }
  };

  const handleClearAllHistory = async () => {
    if (!confirm('🚨 CLEAR COMPLETE ACTIVITY LOG HISTORY?\n\nThis will permanently delete all activity log entries.\nMake sure you have downloaded the PDF archive if needed.\n\nProceed to clear all history?')) {
      return;
    }

    setCleaning(true);
    try {
      const res = await fetch('/api/admin/activity-log?all=true', {
        method: 'DELETE'
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to clear activity log');
      alert(`Activity log history cleared! Removed ${data.count} entries.`);
      router.refresh();
      window.location.reload();
    } catch (err) {
      alert(err instanceof Error ? err.message : 'Error clearing activity log');
    } finally {
      setCleaning(false);
    }
  };

  return (
    <div className="card" style={{
      padding: '1.25rem 1.5rem', background: 'var(--bg)',
      display: 'flex', justifyContent: 'space-between', alignItems: 'center',
      flexWrap: 'wrap', gap: '1rem',
    }}>
      <div>
        <p className="microlabel" style={{ marginBottom: '0.35rem' }}>archive & maintenance</p>
        <strong style={{ fontFamily: 'var(--font-mono)', fontSize: '0.9375rem', fontWeight: 600, display: 'block' }}>
          Archive &amp; Maintenance Tools
        </strong>
        <p style={{ margin: '0.25rem 0 0', color: 'var(--gray-500)', fontSize: '0.875rem' }}>
          Back up all logged system telemetry to a secure PDF report, purge older logs, or clear complete activity history.
        </p>
      </div>

      <div style={{ display: 'flex', gap: '0.6rem', flexWrap: 'wrap' }}>
        <a
          href="/api/admin/activity-log"
          className="btn btn-primary"
        >
          Download PDF Archive
        </a>
        <button
          onClick={handleCleanup}
          disabled={cleaning}
          className="btn"
          style={{ background: 'var(--gray-100)', color: 'var(--ink)' }}
        >
          {cleaning ? 'Purging…' : 'Purge Logs (>30 days)'}
        </button>
        <button
          onClick={handleClearAllHistory}
          disabled={cleaning}
          className="btn btn-danger"
        >
          {cleaning ? 'Clearing History…' : 'Clear History'}
        </button>
      </div>
    </div>
  );
}