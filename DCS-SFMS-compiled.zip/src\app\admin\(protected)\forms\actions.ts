'use server';

import { revalidatePath } from 'next/cache';
import { requireAuth } from '@/lib/auth';
import { prisma } from '@/lib/prisma';

export type QuestionDraft = {
  questionText: string;
  questionType: 'LIKERT' | 'MULTIPLE_CHOICE' | 'CHECKBOXES' | 'TEXT' | 'YES_NO' | 'RATING';
  options: string[];
};

export type FormDraft = {
  title: string;
  academicYear: string;
  semester: 'First Semester' | 'Midyear' | 'Second Semester';
  version: number;
  eventName: string;
  department: string;
  stakeholderCategoryId: string;
  status: 'DRAFT' | 'ACTIVE' | 'CLOSED';
  scheduledStart?: string;
  scheduledEnd?: string;
  questions: QuestionDraft[];
};

const optionQuestionTypes = new Set<QuestionDraft['questionType']>([
  'LIKERT',
  'MULTIPLE_CHOICE',
  'CHECKBOXES',
]);

function parseDate(value: string | undefined, field: string) {
  if (!value) return null;
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) {
    throw new Error(`Invalid ${field}.`);
  }
  return date;
}

export async function createForm(draft: FormDraft) {
  const session = await requireAuth();
  if (!['SUPER_ADMIN', 'ADMIN'].includes(session.role)) {
    throw new Error('FORBIDDEN');
  }

  const title = draft.title.trim();
  const eventName = draft.eventName.trim();
  const department = draft.department.trim();
  const questions = draft.questions.filter((question) => question.questionText.trim());

  if (!title || !eventName || !department || !draft.stakeholderCategoryId) {
    throw new Error('Complete the form, event, department, and stakeholder category fields.');
  }
  if (!Number.isInteger(draft.version) || draft.version < 1) {
    throw new Error('The version must be a whole number of at least 1.');
  }
  if (questions.length === 0) {
    throw new Error('Add at least one question.');
  }

  const scheduledStart = parseDate(draft.scheduledStart, 'start date');
  const scheduledEnd = parseDate(draft.scheduledEnd, 'end date');
  if (scheduledStart && scheduledEnd && scheduledEnd < scheduledStart) {
    throw new Error('The end date must be after the start date.');
  }

  const category = await prisma.stakeholderCategory.findUnique({
    where: { id: draft.stakeholderCategoryId },
    select: { id: true },
  });
  if (!category) {
    throw new Error('Select a valid stakeholder category.');
  }

  const event = await prisma.event.create({
    data: {
      name: eventName,
      department,
      stakeholderCategoryId: category.id,
      createdBy: session.email,
    },
  });

  const form = await prisma.surveyForm.create({
    data: {
      eventId: event.id,
      title,
      academicYear: draft.academicYear.trim() || 'AY 2026–2027',
      semester: draft.semester || 'First Semester',
      version: draft.version,
      status: draft.status,
      scheduledStart,
      scheduledEnd,
      createdBy: session.email,
      Questions: {
        create: questions.map((question, index) => {
          const options = question.options.map((option) => option.trim()).filter(Boolean);
          if (optionQuestionTypes.has(question.questionType) && options.length < 2) {
            throw new Error(`${question.questionType} questions need at least two options.`);
          }

          return {
            questionText: question.questionText.trim(),
            questionType: question.questionType,
            order: index + 1,
            optionsJson: options.length > 0 ? JSON.stringify(options) : null,
          };
        }),
      },
    },
  });

  await prisma.auditLog.create({
    data: {
      userId: session.userId,
      action: 'CREATE_FORM',
      module: 'FORMS',
      description: `Created form "${form.title}" for ${draft.academicYear} (${draft.semester}).`,
    },
  });

  revalidatePath('/admin/forms');
  revalidatePath('/admin/archive');
  return form.id;
}

export async function archiveForm(formId: string) {
  const session = await requireAuth();
  if (!['SUPER_ADMIN', 'ADMIN'].includes(session.role)) {
    throw new Error('FORBIDDEN');
  }

  const form = await prisma.surveyForm.findUnique({
    where: { id: formId },
    select: { title: true, status: true },
  });
  if (!form) throw new Error('Form not found.');

  await prisma.surveyForm.update({
    where: { id: formId },
    data: {
      status: 'ARCHIVED',
      archivedAt: new Date(),
      archivedBy: session.email,
    },
  });

  await prisma.auditLog.create({
    data: {
      userId: session.userId,
      action: 'ARCHIVE_FORM',
      module: 'FORMS',
      description: `Archived form "${form.title}".`,
    },
  });

  revalidatePath('/admin/forms');
  revalidatePath('/admin/archive');
}

export async function restoreForm(formId: string) {
  const session = await requireAuth();
  if (!['SUPER_ADMIN', 'ADMIN'].includes(session.role)) {
    throw new Error('FORBIDDEN');
  }

  const form = await prisma.surveyForm.findUnique({
    where: { id: formId },
    select: { title: true },
  });
  if (!form) throw new Error('Form not found.');

  await prisma.surveyForm.update({
    where: { id: formId },
    data: {
      status: 'ACTIVE',
      archivedAt: null,
      archivedBy: null,
    },
  });

  await prisma.auditLog.create({
    data: {
      userId: session.userId,
      action: 'RESTORE_FORM',
      module: 'FORMS',
      description: `Restored form "${form.title}" from archive.`,
    },
  });

  revalidatePath('/admin/forms');
  revalidatePath('/admin/archive');
}

export async function deleteFormPermanently(formId: string) {
  const session = await requireAuth();
  if (session.role !== 'SUPER_ADMIN') {
    throw new Error('FORBIDDEN: Only Super Admin can permanently delete records.');
  }

  const form = await prisma.surveyForm.findUnique({
    where: { id: formId },
    select: { title: true },
  });
  if (!form) throw new Error('Form not found.');

  await prisma.surveyForm.delete({ where: { id: formId } });

  await prisma.auditLog.create({
    data: {
      userId: session.userId,
      action: 'PERMANENT_DELETE_FORM',
      module: 'FORMS',
      description: `Permanently deleted form "${form.title}".`,
    },
  });

  revalidatePath('/admin/forms');
  revalidatePath('/admin/archive');
}

export async function toggleFormStatus(formId: string, newStatus: 'DRAFT' | 'ACTIVE' | 'CLOSED') {
  const session = await requireAuth();
  if (!['SUPER_ADMIN', 'ADMIN'].includes(session.role)) {
    throw new Error('FORBIDDEN');
  }

  const form = await prisma.surveyForm.findUnique({
    where: { id: formId },
    select: { title: true },
  });
  if (!form) throw new Error('Form not found.');

  await prisma.surveyForm.update({
    where: { id: formId },
    data: { status: newStatus },
  });

  await prisma.auditLog.create({
    data: {
      userId: session.userId,
      action: 'UPDATE_FORM_STATUS',
      module: 'FORMS',
      description: `Changed form "${form.title}" status to ${newStatus}.`,
    },
  });

  revalidatePath('/admin/forms');
  revalidatePath('/scan');
}
