import { prisma } from '@/lib/prisma';
import { notFound } from 'next/navigation';
import FormClient from './FormClient';

export default async function FormPage({ params }: { params: Promise<{ formId: string }> }) {
  const resolvedParams = await params;
  const form = await prisma.surveyForm.findUnique({
    where: { id: resolvedParams.formId },
    include: {
      Questions: {
        orderBy: { order: 'asc' }
      },
      event: {
        include: {
          stakeholderCategory: true
        }
      }
    }
  });

  if (!form) {
    notFound();
  }

  // Fetch all stakeholder categories for the client type dropdown
  const categories = await prisma.stakeholderCategory.findMany({
    orderBy: { name: 'asc' }
  });

  return (
    <div className="form-page-wrapper">
      <main className="form-page-main">
        <FormClient
          form={form}
          formTitle={form.title}
          eventName={form.event.name}
          categories={categories.map(c => ({ id: c.id, name: c.name }))}
        />
      </main>

      <style>{`
        .form-page-wrapper {
          min-height: 100vh;
          padding: 2.5rem 1.5rem;
          background: var(--bg);
          display: flex;
          flex-direction: column;
          align-items: center;
          position: relative;
          z-index: 1;
        }
        .form-page-main {
          width: 100%;
          max-width: 900px;
          box-sizing: border-box;
        }
        @media (max-width: 768px) {
          .form-page-wrapper {
            padding: 0.5rem;
          }
        }
      `}</style>
    </div>
  );
}