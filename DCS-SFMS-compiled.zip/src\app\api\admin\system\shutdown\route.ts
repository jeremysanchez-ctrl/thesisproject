import { NextResponse } from 'next/server';
import { requireAuth } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { exec } from 'child_process';
import { readFileSync } from 'fs';
import path from 'path';

const APP_DIR = path.join(process.cwd());
const PID_FILE = path.join(APP_DIR, '.sfms_pid');

export async function POST() {
  try {
    const session = await requireAuth();
    if (session.role !== 'SUPER_ADMIN') {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
    }

    // Record the shutdown in the audit log before shutting down
    await prisma.auditLog.create({
      data: {
        userId: session.userId,
        action: 'SHUTDOWN_SYSTEM',
        module: 'SYSTEM',
        description: `Initiated remote system shutdown from admin panel.`,
      },
    });

    // Try to read PID file and kill the process + its children
    let killCmd = '';
    try {
      const pid = readFileSync(PID_FILE, 'utf-8').trim();
      if (pid && !isNaN(Number(pid))) {
        killCmd = `taskkill /PID ${pid} /T /F & powershell -Command "Get-NetTCPConnection -LocalPort 3000 -ErrorAction SilentlyContinue | ForEach-Object { Stop-Process -Id $_.OwningProcess -Force -ErrorAction SilentlyContinue }" & del "${PID_FILE.replace(/\//g, '\\')}"`;
      }
    } catch {
      // PID file not found — fall back to killing by port
      killCmd = `powershell -Command "Get-NetTCPConnection -LocalPort 3000 -ErrorAction SilentlyContinue | ForEach-Object { Stop-Process -Id $_.OwningProcess -Force -ErrorAction SilentlyContinue }"`;
    }

    // Execute the kill command asynchronously after sending the response
    setTimeout(() => {
      exec(killCmd, (err) => {
        if (err) console.error('[SYSTEM] Shutdown execution error:', err.message);
      });
    }, 1500); // 1.5s delay to allow the JSON response to be sent first

    return NextResponse.json({ success: true, message: 'Shutdown sequence initiated.' });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Server error' },
      { status: 500 }
    );
  }
}
