import { prisma } from '@/lib/prisma';
import Link from 'next/link';

export default async function ScanPage() {
  const activeForms = await prisma.surveyForm.findMany({
    where: { status: 'ACTIVE' },
    include: { event: true }
  });

  return (
    <div style={{
      minHeight: '100vh',
      background: 'var(--bg)',
      color: 'var(--ink)',
      fontFamily: 'var(--font-body)',
      position: 'relative',
      zIndex: 1,
    }}>
      <main className="content-wrap page-pad" style={{ padding: '3rem 1.5rem 4rem' }}>
        <span className="num-label rise">01 — active surveys</span>
        <h1 className="page-title rise rise-1" style={{ fontSize: 'clamp(2rem, 5vw, 3rem)' }}>Active Surveys</h1>
        <p className="page-desc rise rise-2" style={{ maxWidth: '42rem' }}>
          Select a survey below to participate. In a production environment, this page would act as a QR code
          scanner or you would access the specific survey link directly via the QR code.
        </p>

        <div className="stack-lg rise rise-3" style={{ gap: '0.75rem' }}>
          {activeForms.length === 0 ? (
            <div className="card" style={{ padding: '2rem', textAlign: 'center', borderStyle: 'dashed' }}>
              <p className="microlabel" style={{ color: 'var(--gray-500)', margin: 0 }}>No active surveys found.</p>
            </div>
          ) : (
            activeForms.map(form => (
              <Link
                key={form.id}
                href={`/form/${form.id}`}
                className="card card-hover"
                style={{
                  display: 'flex',
                  flexDirection: 'column',
                  gap: '0.4rem',
                  padding: '1.5rem',
                  textDecoration: 'none',
                  background: 'var(--bg)',
                }}
              >
                <span className="microlabel" style={{ color: 'var(--gray-400)' }}>survey</span>
                <h3 style={{ fontFamily: 'var(--font-mono)', fontSize: '1.05rem', fontWeight: 600, margin: 0 }}>{form.title}</h3>
                <p style={{ color: 'var(--gray-500)', fontSize: '0.906rem', margin: 0 }}>
                  Event: {form.event.name}
                </p>
                <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.8125rem', color: 'var(--ink)', alignSelf: 'flex-end' }}>
                  open ↗
                </span>
              </Link>
            ))
          )}
        </div>

        <div style={{ marginTop: '2.5rem' }}>
          <Link href="/" className="link-btn">back to home</Link>
        </div>
      </main>
    </div>
  );
}