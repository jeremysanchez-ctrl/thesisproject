module.exports=[30570,(__turbopack_context__,module1,exports)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_%28protected%29_activity-log_page_actions_0i9wqnl.js.map