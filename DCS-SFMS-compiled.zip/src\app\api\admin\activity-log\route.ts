import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requireAuth } from '@/lib/auth';

export async function GET() {
  try {
    const session = await requireAuth();
    if (session.role !== 'SUPER_ADMIN') {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
    }

    const { jsPDF } = await import('jspdf');
    const { default: autoTable } = await import('jspdf-autotable');

    // Retrieve ALL logs (or filter for older logs to download before cleanup)
    const logs = await prisma.auditLog.findMany({
      include: { user: { select: { name: true, email: true, role: true } } },
      orderBy: { createdAt: 'desc' }
    });

    const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
    
    // Header CvSU styling
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(14);
    doc.text('CAVITE STATE UNIVERSITY', 105, 15, { align: 'center' });
    doc.setFontSize(11);
    doc.text('Imus Campus - Department of Computer Studies', 105, 20, { align: 'center' });
    doc.setFontSize(12);
    doc.text('OFFICIAL MONTHLY SECURITY AUDIT LOG ARCHIVE', 105, 26, { align: 'center' });
    
    doc.setFontSize(9);
    doc.setFont('helvetica', 'normal');
    doc.text(`Generated On: ${new Date().toLocaleString()} (PHT)`, 14, 34);
    doc.text(`Total Records: ${logs.length}`, 14, 39);
    doc.line(14, 42, 196, 42);

    const bodyRows = logs.map((log) => [
      new Date(log.createdAt).toLocaleString(),
      `${log.user.name}\n(${log.user.email})`,
      log.user.role,
      log.action,
      log.description
    ]);

    autoTable(doc, {
      startY: 45,
      head: [['Timestamp', 'User Details', 'Role', 'Action', 'Operational Details']],
      body: bodyRows,
      theme: 'grid',
      headStyles: { fillColor: [0, 85, 255], textColor: [255, 255, 255], fontStyle: 'bold' },
      styles: { fontSize: 8, cellPadding: 2 },
      columnStyles: {
        0: { cellWidth: 35 },
        1: { cellWidth: 45 },
        2: { cellWidth: 25 },
        3: { cellWidth: 35 },
        4: { cellWidth: 50 }
      }
    });

    const pdfBuffer = doc.output('arraybuffer');
    const filename = `monthly_activity_log_${new Date().toISOString().slice(0, 10)}.pdf`;

    return new NextResponse(new Uint8Array(pdfBuffer), {
      headers: {
        'Content-Type': 'application/pdf',
        'Content-Disposition': `attachment; filename="${filename}"`
      }
    });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : 'Server error' }, { status: 500 });
  }
}

// DELETE triggers log cleanup: if ?all=true clears all activity history, otherwise purges > 30 days
export async function DELETE(request: NextRequest) {
  try {
    const session = await requireAuth();
    if (session.role !== 'SUPER_ADMIN') {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
    }

    const { searchParams } = new URL(request.url);
    const clearAll = searchParams.get('all') === 'true';

    let deleteResult;
    if (clearAll) {
      deleteResult = await prisma.auditLog.deleteMany({});
      
      // Add a fresh initialization log
      await prisma.auditLog.create({
        data: {
          userId: session.userId,
          action: 'CLEAR_ACTIVITY_LOG',
          module: 'SECURITY',
          description: `Super Admin cleared complete activity log history.`,
        },
      });
    } else {
      const oneMonthAgo = new Date();
      oneMonthAgo.setDate(oneMonthAgo.getDate() - 30);

      deleteResult = await prisma.auditLog.deleteMany({
        where: {
          createdAt: {
            lt: oneMonthAgo,
          },
        },
      });

      // Record the cleanup action itself
      await prisma.auditLog.create({
        data: {
          userId: session.userId,
          action: 'CLEANUP_AUDIT_LOGS',
          module: 'SECURITY',
          description: `Executed manual audit logs maintenance. Cleared ${deleteResult.count} records older than 30 days.`,
        },
      });
    }

    return NextResponse.json({ success: true, count: deleteResult.count });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : 'Server error' }, { status: 500 });
  }
}
