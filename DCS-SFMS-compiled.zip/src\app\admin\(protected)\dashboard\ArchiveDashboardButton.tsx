'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { archiveAllActiveRecords } from '../archive/actions';

export default function ArchiveDashboardButton({ userRole }: { userRole: string }) {
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  if (!['SUPER_ADMIN', 'ADMIN'].includes(userRole)) {
    return null;
  }

  const handleArchiveAll = async () => {
    const confirmed = confirm(
      '📦 ARCHIVE ALL FEEDBACK RECORDS & RESET DASHBOARD?\n\n' +
      '• All submitted stakeholder responses will be moved to the Trash / Archive.\n' +
      '• All charts, metrics, and response counts on this dashboard will reset to 0.\n' +
      '• Active survey forms and QR codes will NOT be affected (respondents can continue scanning without interruption).\n' +
      '• You can view, restore, or permanently delete the archived records anytime from the Trash / Archive page.\n\n' +
      'Do you want to proceed?'
    );

    if (!confirmed) return;

    setLoading(true);
    try {
      const result = await archiveAllActiveRecords();
      alert(`Success! Archived ${result.responsesArchived} response(s). Dashboard metrics have reset while QR codes remain active.`);
      router.refresh();
      window.location.reload();
    } catch (err) {
      alert(err instanceof Error ? err.message : 'Failed to archive records.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <button
      onClick={handleArchiveAll}
      disabled={loading}
      className="btn"
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        gap: '0.45rem',
        background: 'var(--gray-100)',
        color: 'var(--ink)',
        border: 'var(--hairline)',
        borderRadius: 'var(--radius-xs)',
        padding: '0.55rem 1rem',
        fontSize: '0.875rem',
        fontFamily: 'var(--font-mono)',
        fontWeight: 600,
        cursor: loading ? 'wait' : 'pointer',
        transition: 'all var(--motion-1)',
      }}
      title="Move all current records to Trash/Archive and reset dashboard data"
    >
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <polyline points="21 8 21 21 3 21 3 8" />
        <rect x="1" y="3" width="22" height="5" />
        <line x1="10" y1="12" x2="14" y2="12" />
      </svg>
      {loading ? 'Archiving Records…' : 'Archive All Records'}
    </button>
  );
}
