'use client';

import { useState } from 'react';
import { restoreForm, deleteFormPermanently } from '../forms/actions';
import { restoreResponse, deleteResponsePermanently, emptyArchiveTrash } from './actions';

type ArchivedForm = {
  id: string;
  title: string;
  academicYear?: string | null;
  semester?: string | null;
  createdAt: Date;
  archivedAt?: Date | null;
  archivedBy?: string | null;
  createdBy?: string | null;
  event: { name: string };
  _count: { Questions: number; Responses: number };
};

type ArchivedResponse = {
  id: string;
  controlNo: string | null;
  name: string | null;
  department: string | null;
  dateOfVisit: string | null;
  submittedAt: Date;
  archivedAt: Date | null;
  hardCopyPhotoUrl: string | null;
  form: { title: string };
  stakeholderCategory: { name: string };
};

export default function ArchiveListClient({
  forms,
  responses,
  userRole,
}: {
  forms: ArchivedForm[];
  responses: ArchivedResponse[];
  userRole: string;
}) {
  const [activeTab, setActiveTab] = useState<'all' | 'responses' | 'forms'>('all');
  const [loadingId, setLoadingId] = useState<string | null>(null);
  const [emptying, setEmptying] = useState(false);

  const isSuperAdmin = userRole === 'SUPER_ADMIN';

  const handleRestoreForm = async (id: string, title: string) => {
    if (!confirm(`Restore form "${title}" to active list?`)) return;
    setLoadingId(id);
    try {
      await restoreForm(id);
      window.location.reload();
    } catch {
      alert('Failed to restore form.');
      setLoadingId(null);
    }
  };

  const handleDeleteFormPermanent = async (id: string, title: string) => {
    if (!confirm(`PERMANENTLY delete form "${title}"? This cannot be undone!`)) return;
    setLoadingId(id);
    try {
      await deleteFormPermanently(id);
      window.location.reload();
    } catch (err) {
      alert(err instanceof Error ? err.message : 'Failed to permanently delete form.');
      setLoadingId(null);
    }
  };

  const handleRestoreResp = async (id: string, controlNo: string | null) => {
    if (!confirm(`Restore response record ${controlNo || id} back to active dashboard?`)) return;
    setLoadingId(id);
    try {
      await restoreResponse(id);
      window.location.reload();
    } catch {
      alert('Failed to restore response.');
      setLoadingId(null);
    }
  };

  const handleDeleteRespPermanent = async (id: string, controlNo: string | null) => {
    if (!confirm(`PERMANENTLY delete response record ${controlNo || id}? This cannot be undone!`)) return;
    setLoadingId(id);
    try {
      await deleteResponsePermanently(id);
      window.location.reload();
    } catch (err) {
      alert(err instanceof Error ? err.message : 'Failed to delete response.');
      setLoadingId(null);
    }
  };

  const handleEmptyTrash = async () => {
    if (!confirm('🚨 PERMANENTLY EMPTY ENTIRE TRASH / ARCHIVE?\n\nThis will permanently delete ALL archived responses and archived forms from the database.\nThis action is irreversible!\n\nAre you absolutely sure?')) {
      return;
    }

    setEmptying(true);
    try {
      const res = await emptyArchiveTrash();
      alert(`Trash emptied! Permanently deleted ${res.deletedResponses} response(s) and ${res.deletedForms} form(s).`);
      window.location.reload();
    } catch (err) {
      alert(err instanceof Error ? err.message : 'Failed to empty trash.');
      setEmptying(false);
    }
  };

  const totalArchived = forms.length + responses.length;

  return (
    <div style={{ display: 'grid', gap: '1.25rem' }}>
      {/* Top Action Bar with Tabs & Empty Trash Button */}
      <div className="card" style={{
        padding: '1rem 1.25rem',
        background: 'var(--bg)',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        flexWrap: 'wrap',
        gap: '1rem',
      }}>
        <div style={{ display: 'flex', gap: '0.4rem', flexWrap: 'wrap' }}>
          <button
            onClick={() => setActiveTab('all')}
            className={`btn ${activeTab === 'all' ? 'btn-primary' : ''}`}
            style={{ fontSize: '0.8125rem', padding: '0.45rem 0.85rem' }}
          >
            All Items ({totalArchived})
          </button>
          <button
            onClick={() => setActiveTab('responses')}
            className={`btn ${activeTab === 'responses' ? 'btn-primary' : ''}`}
            style={{ fontSize: '0.8125rem', padding: '0.45rem 0.85rem' }}
          >
            Archived Responses ({responses.length})
          </button>
          <button
            onClick={() => setActiveTab('forms')}
            className={`btn ${activeTab === 'forms' ? 'btn-primary' : ''}`}
            style={{ fontSize: '0.8125rem', padding: '0.45rem 0.85rem' }}
          >
            Archived Forms ({forms.length})
          </button>
        </div>

        {isSuperAdmin && totalArchived > 0 && (
          <button
            onClick={handleEmptyTrash}
            disabled={emptying}
            className="btn btn-danger"
            style={{
              fontSize: '0.8125rem',
              display: 'inline-flex',
              alignItems: 'center',
              gap: '0.4rem',
            }}
          >
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <polyline points="3 6 5 6 21 6" />
              <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" />
            </svg>
            {emptying ? 'Emptying Trash…' : 'Empty Trash Permanently'}
          </button>
        )}
      </div>

      {totalArchived === 0 ? (
        <div className="card" style={{
          padding: '3.5rem 2rem',
          textAlign: 'center',
          border: 'var(--hairline)',
          borderStyle: 'dashed',
          color: 'var(--gray-500)',
          display: 'grid',
          gap: '0.4rem',
          justifyItems: 'center',
        }}>
          <span style={{ fontFamily: 'var(--font-mono)', fontSize: '1.25rem' }}>[ empty ]</span>
          <strong className="microlabel" style={{ color: 'var(--ink)', fontSize: '0.9375rem' }}>Trash / Archive is currently empty</strong>
          <p style={{ margin: 0, fontSize: '0.875rem' }}>When you click "Archive All Records" on the dashboard or archive a form, the items will appear here.</p>
        </div>
      ) : (
        <div style={{ display: 'grid', gap: '1rem' }}>
          {/* ARCHIVED RESPONSES SECTION */}
          {(activeTab === 'all' || activeTab === 'responses') && responses.length > 0 && (
            <div style={{ display: 'grid', gap: '0.6rem' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.2rem' }}>
                <span className="microlabel" style={{ color: 'var(--primary)' }}>feedback responses ({responses.length})</span>
              </div>
              {responses.map((resp) => {
                const isLoading = loadingId === resp.id;
                return (
                  <div
                    key={resp.id}
                    className="card"
                    style={{
                      display: 'flex',
                      justifyContent: 'space-between',
                      gap: '1rem',
                      alignItems: 'center',
                      padding: '1.15rem 1.25rem',
                      background: 'var(--bg)',
                      opacity: isLoading ? 0.6 : 1,
                      flexWrap: 'wrap',
                    }}
                  >
                    <div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', flexWrap: 'wrap' }}>
                        <strong style={{ color: 'var(--ink)', fontSize: '0.95rem', fontWeight: 600, fontFamily: 'var(--font-mono)' }}>
                          {resp.controlNo || 'SFMS-NO-CTRL'}
                        </strong>
                        <span className="chip" style={{ fontSize: '0.75rem', padding: '0.15rem 0.5rem' }}>
                          {resp.stakeholderCategory.name}
                        </span>
                        {resp.hardCopyPhotoUrl && (
                          <span className="chip chip-accent" style={{ fontSize: '0.75rem', padding: '0.15rem 0.5rem' }}>
                            📷 Hard Copy
                          </span>
                        )}
                      </div>
                      <p style={{ color: 'var(--ink)', margin: '0.25rem 0 0.15rem', fontSize: '0.9375rem', fontWeight: 500 }}>
                        {resp.name || 'Anonymous Respondent'} {resp.department && `· ${resp.department}`}
                      </p>
                      <p className="microlabel" style={{ color: 'var(--gray-500)', margin: 0 }}>
                        Form: {resp.form.title} · Submitted: {new Date(resp.submittedAt).toLocaleDateString()}
                        {resp.archivedAt && ` · Archived: ${new Date(resp.archivedAt).toLocaleDateString()}`}
                      </p>
                    </div>

                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', flexWrap: 'wrap' }}>
                      {resp.hardCopyPhotoUrl && (
                        <a
                          href={resp.hardCopyPhotoUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="btn"
                          style={{ fontSize: '0.8125rem', padding: '0.45rem 0.75rem', background: 'var(--gray-100)' }}
                        >
                          View Photo
                        </a>
                      )}
                      <button
                        onClick={() => handleRestoreResp(resp.id, resp.controlNo)}
                        disabled={isLoading}
                        className="btn btn-success"
                        style={{ fontSize: '0.8125rem', padding: '0.45rem 0.85rem' }}
                      >
                        Restore Record
                      </button>
                      {isSuperAdmin && (
                        <button
                          onClick={() => handleDeleteRespPermanent(resp.id, resp.controlNo)}
                          disabled={isLoading}
                          className="btn btn-danger"
                          style={{ fontSize: '0.8125rem', padding: '0.45rem 0.85rem' }}
                        >
                          Delete
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* ARCHIVED FORMS SECTION */}
          {(activeTab === 'all' || activeTab === 'forms') && forms.length > 0 && (
            <div style={{ display: 'grid', gap: '0.6rem', marginTop: activeTab === 'all' ? '0.75rem' : 0 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.2rem' }}>
                <span className="microlabel" style={{ color: 'var(--primary)' }}>survey forms ({forms.length})</span>
              </div>
              {forms.map((form) => {
                const isLoading = loadingId === form.id;
                return (
                  <div
                    key={form.id}
                    className="card"
                    style={{
                      display: 'flex',
                      justifyContent: 'space-between',
                      gap: '1rem',
                      alignItems: 'center',
                      padding: '1.25rem',
                      background: 'var(--bg)',
                      opacity: isLoading ? 0.6 : 1,
                      flexWrap: 'wrap',
                    }}
                  >
                    <div>
                      <strong style={{ color: 'var(--ink)', fontSize: '1.05rem', fontWeight: 600, fontFamily: 'var(--font-mono)' }}>
                        {form.title}
                      </strong>
                      <p style={{ color: 'var(--gray-500)', margin: '0.35rem 0 0.25rem', fontSize: '0.9375rem' }}>
                        {form.event.name} · <strong style={{ color: 'var(--ink)', fontWeight: 600 }}>{form.academicYear || 'AY 2026–2027'} ({form.semester || 'First Semester'})</strong>
                      </p>
                      <p className="microlabel" style={{ color: 'var(--gray-500)', margin: 0, lineHeight: 1.7 }}>
                        Created: {new Date(form.createdAt).toLocaleDateString()} by {form.createdBy || 'Admin'}
                        {form.archivedAt && ` · Archived: ${new Date(form.archivedAt).toLocaleDateString()} by ${form.archivedBy || 'System'}`}
                      </p>
                      <span className="chip" style={{ marginTop: '0.5rem', borderColor: 'var(--gray-300)' }}>
                        preserved responses: {form._count.Responses}
                      </span>
                    </div>

                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem', flexWrap: 'wrap' }}>
                      <button
                        onClick={() => handleRestoreForm(form.id, form.title)}
                        disabled={isLoading}
                        className="btn btn-success"
                        style={{ fontSize: '0.8125rem' }}
                      >
                        Restore Form
                      </button>

                      {isSuperAdmin && (
                        <button
                          onClick={() => handleDeleteFormPermanent(form.id, form.title)}
                          disabled={isLoading}
                          className="btn btn-danger"
                          style={{ fontSize: '0.8125rem' }}
                        >
                          Permanent Delete
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
