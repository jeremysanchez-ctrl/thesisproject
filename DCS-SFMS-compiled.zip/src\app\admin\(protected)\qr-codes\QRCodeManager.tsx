'use client';

import { useState } from 'react';
import { createQRCode } from './actions';

type Event = { id: string; name: string; department: string; activeFormTitle: string | null };

export default function QRCodeManager({
  events,
  currentAppUrl,
}: {
  events: Event[];
  currentAppUrl: string;
}) {
  const [eventId, setEventId] = useState(events[0]?.id ?? '');
  const [expiresAt, setExpiresAt] = useState('');
  const [appUrl, setAppUrl] = useState(currentAppUrl);
  const [savedUrlMsg, setSavedUrlMsg] = useState('');
  const [error, setError] = useState('');
  const [isCreating, setIsCreating] = useState(false);

  // Sync client-configured URL on client mount
  useState(() => {
    if (typeof window !== 'undefined') {
      const customUrl = localStorage.getItem('sfms_public_app_url');
      if (customUrl) {
        setAppUrl(customUrl);
      } else {
        setAppUrl(currentAppUrl);
      }
    }
  });

  const submit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setError('');
    setIsCreating(true);
    try {
      await createQRCode(eventId, expiresAt || undefined);
      window.location.reload();
    } catch (caughtError) {
      setError(caughtError instanceof Error ? caughtError.message : 'Unable to create QR code.');
      setIsCreating(false);
    }
  };

  const handleSavePublicUrl = async () => {
    setSavedUrlMsg('');
    try {
      localStorage.setItem('sfms_public_app_url', appUrl);
      setSavedUrlMsg('Public URL saved. Reloading QR codes…');
      setTimeout(() => {
        window.location.reload();
      }, 500);
    } catch {
      alert('Failed to save public URL setting.');
    }
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>

      {/* Public / Ngrok Tunnel URL Configurator */}
      <div className="card" style={{ padding: '1.25rem 1.5rem', background: 'var(--bg)', display: 'grid', gap: '0.85rem' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '0.5rem' }}>
          <div>
            <p className="microlabel" style={{ marginBottom: '0.35rem' }}>tunnel config</p>
            <strong style={{ fontFamily: 'var(--font-mono)', fontSize: '0.9375rem', fontWeight: 600 }}>
              Public Server / Ngrok Tunnel URL Configurator
            </strong>
            <p style={{ margin: '0.25rem 0 0', fontSize: '0.906rem', color: 'var(--gray-500)' }}>
              Enter your free Ngrok URL or LAN IP address so respondents can scan QR codes from mobile phones on any network:
            </p>
          </div>
        </div>

        <div style={{ display: 'flex', gap: '0.6rem', flexWrap: 'wrap', alignItems: 'center' }}>
          <input
            type="text"
            value={appUrl}
            onChange={(e) => setAppUrl(e.target.value)}
            placeholder="e.g. https://your-ngrok-domain.ngrok-free.app or http://192.168.18.57:3000"
            className="input"
            style={{ flex: '1 1 350px', fontFamily: 'var(--font-mono)', fontSize: '0.8125rem' }}
          />
          <button
            type="button"
            onClick={handleSavePublicUrl}
            className="btn btn-primary"
          >
            Save Public URL
          </button>
          <button
            type="button"
            onClick={() => {
              localStorage.removeItem('sfms_public_app_url');
              setAppUrl(currentAppUrl);
              setSavedUrlMsg('Reset to auto-detected tunnel URL. Reloading…');
              setTimeout(() => {
                window.location.reload();
              }, 500);
            }}
            className="btn btn-secondary"
            title="Clear stored URL and use the latest live tunnel automatically"
          >
            Auto-Detect Tunnel
          </button>
        </div>

        {savedUrlMsg && (
          <p style={{ margin: 0, color: 'var(--positive)', fontWeight: 600, fontSize: '0.875rem' }}>
            ✓ {savedUrlMsg}
          </p>
        )}
      </div>

      {/* QR Code Creation Form */}
      {events.length === 0 ? (
        <p style={{ color: 'var(--gray-500)', fontSize: '0.9375rem' }}>Create an event and an active form before generating a QR code.</p>
      ) : (
        <form onSubmit={submit} className="card" style={{ padding: '1.5rem', background: 'var(--bg)', display: 'flex', flexWrap: 'wrap', alignItems: 'flex-end', gap: '1.25rem' }}>
          <label style={labelStyle}>
            Select Event &amp; Active Form
            <select value={eventId} onChange={(event) => setEventId(event.target.value)} className="input">
              {events.map((event) => (
                <option key={event.id} value={event.id} disabled={!event.activeFormTitle}>
                  {event.name} — {event.activeFormTitle ?? 'No active form'}
                </option>
              ))}
            </select>
          </label>
          <label style={labelStyle}>
            Expiration Date (Optional)
            <input type="datetime-local" value={expiresAt} onChange={(event) => setExpiresAt(event.target.value)} className="input" />
          </label>
          <button disabled={isCreating} className="btn btn-primary" style={{ whiteSpace: 'nowrap' }}>
            {isCreating ? 'Generating QR Code…' : 'Generate Event QR Code'}
          </button>
          {error && <p role="alert" style={{ color: 'var(--danger)', margin: 0, width: '100%', fontWeight: 600, fontSize: '0.875rem' }}>{error}</p>}
        </form>
      )}
    </div>
  );
}

const labelStyle: React.CSSProperties = { display: 'grid', gap: '0.4rem', color: 'var(--gray-500)', fontSize: '0.8125rem', fontWeight: 600, flex: '1 1 280px' };