'use server';

import { revalidatePath } from 'next/cache';
import { prisma } from '@/lib/prisma';
import { requireAuth } from '@/lib/auth';

export async function archiveAllActiveRecords() {
  const session = await requireAuth();
  if (!['SUPER_ADMIN', 'ADMIN'].includes(session.role)) {
    throw new Error('FORBIDDEN: You do not have permission to archive records.');
  }

  const now = new Date();

  // Archive only feedback response submissions (keeps the active survey form and QR codes untouched)
  const updateResponses = await prisma.response.updateMany({
    where: { isArchived: false },
    data: {
      isArchived: true,
      archivedAt: now,
    },
  });

  // Log the action
  await prisma.auditLog.create({
    data: {
      userId: session.userId,
      action: 'ARCHIVE_ALL_RESPONSES',
      module: 'DASHBOARD',
      description: `Moved all active response records to archive/trash: ${updateResponses.count} response(s) archived. Dashboard telemetry and charts reset. Survey forms and QR codes remain fully functional.`,
    },
  });

  revalidatePath('/admin/dashboard');
  revalidatePath('/admin/archive');
  revalidatePath('/admin/forms');
  revalidatePath('/admin/reports');

  return {
    success: true,
    responsesArchived: updateResponses.count,
    formsArchived: 0,
  };
}

export async function restoreResponse(responseId: string) {
  const session = await requireAuth();
  if (!['SUPER_ADMIN', 'ADMIN'].includes(session.role)) {
    throw new Error('FORBIDDEN');
  }

  await prisma.response.update({
    where: { id: responseId },
    data: {
      isArchived: false,
      archivedAt: null,
    },
  });

  await prisma.auditLog.create({
    data: {
      userId: session.userId,
      action: 'RESTORE_RESPONSE',
      module: 'ARCHIVE',
      description: `Restored response record ${responseId} from archive.`,
    },
  });

  revalidatePath('/admin/dashboard');
  revalidatePath('/admin/archive');
}

export async function deleteResponsePermanently(responseId: string) {
  const session = await requireAuth();
  if (session.role !== 'SUPER_ADMIN') {
    throw new Error('FORBIDDEN: Only Super Admin can permanently delete records.');
  }

  await prisma.response.delete({
    where: { id: responseId },
  });

  await prisma.auditLog.create({
    data: {
      userId: session.userId,
      action: 'DELETE_RESPONSE_PERMANENT',
      module: 'ARCHIVE',
      description: `Permanently deleted response record ${responseId}.`,
    },
  });

  revalidatePath('/admin/dashboard');
  revalidatePath('/admin/archive');
}

export async function emptyArchiveTrash() {
  const session = await requireAuth();
  if (session.role !== 'SUPER_ADMIN') {
    throw new Error('FORBIDDEN: Only Super Admin can permanently empty the trash/archive.');
  }

  // Delete all archived responses
  const delResponses = await prisma.response.deleteMany({
    where: { isArchived: true },
  });

  // Delete all archived survey forms (cascades to their questions/responses)
  const delForms = await prisma.surveyForm.deleteMany({
    where: { status: 'ARCHIVED' },
  });

  await prisma.auditLog.create({
    data: {
      userId: session.userId,
      action: 'EMPTY_ARCHIVE_TRASH',
      module: 'ARCHIVE',
      description: `Permanently emptied trash/archive: purged ${delResponses.count} archived response(s) and ${delForms.count} archived form(s).`,
    },
  });

  revalidatePath('/admin/dashboard');
  revalidatePath('/admin/archive');
  revalidatePath('/admin/forms');

  return {
    deletedResponses: delResponses.count,
    deletedForms: delForms.count,
  };
}
