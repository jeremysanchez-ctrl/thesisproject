globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/JexLKIp_5JzLv0J00Vo-g/_buildManifest.js",
    "static/JexLKIp_5JzLv0J00Vo-g/_ssgManifest.js",
    "static/JexLKIp_5JzLv0J00Vo-g/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/3r_54x8s49_ln.js",
    "static/chunks/1t8qwu5vfev2c.js",
    "static/chunks/0zywfdud_823o.js",
    "static/chunks/0up-500cfizpx.js",
    "static/chunks/1fq7n0o0iqhl_.js",
    "static/chunks/turbopack-2dd_0arzazf4x.js"
  ]
};
