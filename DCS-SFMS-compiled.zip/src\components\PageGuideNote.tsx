'use client';

import { useState } from 'react';

interface GuideStep {
  title: string;
  description: string;
}

interface PageGuideNoteProps {
  pageTitle: string;
  overview: string;
  steps: GuideStep[];
}

export default function PageGuideNote({ pageTitle, overview, steps }: PageGuideNoteProps) {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="card" style={{ padding: 0, marginBottom: '1.5rem', overflow: 'hidden', background: 'var(--bg)' }}>
      {/* Clickable Header Bar */}
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        style={{
          width: '100%',
          padding: '0.9rem 1.25rem',
          background: 'transparent',
          border: 'none',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          cursor: 'pointer',
          textAlign: 'left',
          gap: '1rem',
          color: 'var(--ink)',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.9rem', flexWrap: 'wrap' }}>
          <span className="chip" style={{ padding: '0.2rem 0.7rem' }}>guide</span>
          <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.8125rem', fontWeight: 600, letterSpacing: '0.02em' }}>
            How {pageTitle} works
          </span>
        </div>
        <span style={{
          fontFamily: 'var(--font-mono)', fontSize: '0.75rem', color: 'var(--gray-500)',
          transform: isOpen ? 'rotate(180deg)' : 'rotate(0deg)',
          transition: 'transform var(--motion-1)',
        }}>
          ▼
        </span>
      </button>

      {/* Expanded Content Body */}
      {isOpen && (
        <div style={{ borderTop: 'var(--hairline)', background: 'var(--gray-50)', padding: '1.25rem 1.25rem' }}>
          <p style={{ margin: '0 0 1.25rem', color: 'var(--gray-600)', fontSize: '0.9375rem', lineHeight: 1.7 }}>
            {overview}
          </p>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))', gap: '0.75rem' }}>
            {steps.map((step, idx) => (
              <div key={idx} style={{
                background: 'var(--bg)',
                border: 'var(--hairline)',
                borderRadius: 'var(--radius-sm)',
                padding: '0.9rem 1rem',
              }}>
                <p className="microlabel" style={{ margin: '0 0 0.35rem', color: 'var(--gray-500)' }}>
                  {String(idx + 1).padStart(2, '0')} — {step.title}
                </p>
                <p style={{ fontSize: '0.875rem', color: 'var(--gray-600)', lineHeight: 1.5, margin: 0 }}>
                  {step.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}