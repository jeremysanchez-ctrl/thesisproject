module.exports=[51174,(__turbopack_context__,module1,exports)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_system_shutdown_route_actions_1uq1q74.js.map