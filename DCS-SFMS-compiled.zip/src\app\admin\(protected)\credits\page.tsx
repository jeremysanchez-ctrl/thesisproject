export default function CreditsPage() {
  return (
    <div className="content-wrap" style={{ maxWidth: '48rem', display: 'grid', gap: '1.75rem' }}>
      <header className="rise">
        <span className="num-label">10 — credits</span>
        <h1 className="page-title" style={{ fontSize: 'clamp(1.8rem, 4vw, 2.6rem)' }}>Credits &amp; Authorship</h1>
        <p className="page-desc">
          Official development team behind the Stakeholder Feedback Management System.
        </p>
      </header>

      <section className="card rise rise-1" style={{
        padding: '3rem 2rem',
        background: 'var(--bg)',
        textAlign: 'center',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        gap: '2rem',
      }}>
        {/* Department Shield Symbol */}
        <div style={{
          width: '80px', height: '80px', borderRadius: '50%',
          background: 'var(--ink)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          color: 'var(--bg)', fontFamily: 'var(--font-mono)', fontWeight: 600, fontSize: '0.875rem', letterSpacing: '0.04em',
        }}>
          CvSU
        </div>

        <div>
          <p className="microlabel" style={{ color: 'var(--gray-500)', margin: '0 0 1.25rem' }}>prepared by</p>
          <div style={{ display: 'grid', gap: '0.5rem', margin: '0 0 1.5rem' }}>
            {['Gabriel Grajo', 'Christian Remulla', 'Jeremy Sanchez'].map((name) => (
              <strong key={name} style={{ fontFamily: 'var(--font-mono)', fontSize: '1.15rem', fontWeight: 600, color: 'var(--ink)', display: 'block' }}>
                {name}
              </strong>
            ))}
          </div>

          <div style={{ borderTop: 'var(--hairline)', paddingTop: '1.25rem' }}>
            <h3 className="chip-inverted" style={{ margin: '0 0 0.35rem', fontSize: '0.75rem', fontWeight: 600 }}>
              Department of Computer Studies
            </h3>
            <p style={{ color: 'var(--gray-500)', fontSize: '0.906rem', margin: '0' }}>
              Cavite State University — Imus Campus
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}