'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

type UserItem = {
  id: string;
  name: string;
  email: string;
  role: string;
  isActive: boolean;
  createdAt: Date;
};

type Role = 'SUPER_ADMIN' | 'ADMIN' | 'DEPT_HEAD' | 'QA_OFFICER';

export default function UserManagementClient({
  users,
  currentUserId,
}: {
  users: UserItem[];
  currentUserId: string;
}) {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState<Role>('ADMIN');
  const [isCreating, setIsCreating] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [loadingId, setLoadingId] = useState<string | null>(null);

  // Edit State
  const [editingUser, setEditingUser] = useState<UserItem | null>(null);
  const [editName, setEditName] = useState('');
  const [editEmail, setEditEmail] = useState('');
  const [editPassword, setEditPassword] = useState('');
  const [editRole, setEditRole] = useState<Role>('ADMIN');

  const router = useRouter();

  const handleCreateUser = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    setIsCreating(true);

    try {
      const res = await fetch('/api/admin/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'CREATE', name, email, password, role }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to create user');
      setSuccess(`Account created for ${name} (${role}).`);
      setName('');
      setEmail('');
      setPassword('');
      router.refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Error creating account');
    } finally {
      setIsCreating(false);
    }
  };

  const handleToggleActive = async (user: UserItem) => {
    if (user.id === currentUserId) {
      alert('You cannot deactivate your own logged-in account.');
      return;
    }
    const nextState = !user.isActive;
    if (!confirm(`${nextState ? 'Activate' : 'Deactivate'} account for ${user.name}?`)) return;
    setLoadingId(user.id);
    try {
      const res = await fetch('/api/admin/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'TOGGLE_ACTIVE', userId: user.id, isActive: nextState }),
      });
      if (!res.ok) throw new Error('Failed to update user status');
      router.refresh();
    } catch {
      alert('Failed to update account status.');
    } finally {
      setLoadingId(null);
    }
  };

  const handleStartEdit = (user: UserItem) => {
    setEditingUser(user);
    setEditName(user.name);
    setEditEmail(user.email);
    setEditRole(user.role as Role);
    setEditPassword('');
  };

  const handleCancelEdit = () => {
    setEditingUser(null);
  };

  const handleUpdateUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingUser) return;
    setError('');
    setSuccess('');
    setLoadingId(editingUser.id);

    try {
      const res = await fetch('/api/admin/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'UPDATE',
          userId: editingUser.id,
          name: editName,
          email: editEmail,
          password: editPassword || undefined,
          role: editRole
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to update user');
      setSuccess(`Account details updated for ${editName}.`);
      setEditingUser(null);
      router.refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Error updating account');
    } finally {
      setLoadingId(null);
    }
  };

  const handleDeleteUser = async (user: UserItem) => {
    if (user.id === currentUserId) {
      alert('You cannot delete your own account.');
      return;
    }
    if (!confirm(`⚠ WARNING: Are you sure you want to PERMANENTLY DELETE the account for "${user.name}"? This action cannot be undone.`)) {
      return;
    }
    setLoadingId(user.id);
    try {
      const res = await fetch('/api/admin/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'DELETE', userId: user.id }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to delete user');
      setSuccess(`Account for ${user.name} permanently deleted.`);
      router.refresh();
    } catch (err) {
      alert(err instanceof Error ? err.message : 'Failed to delete account.');
    } finally {
      setLoadingId(null);
    }
  };

  return (
    <div style={{ display: 'grid', gap: '1.5rem' }}>

      {/* Edit Form Modal/Section */}
      {editingUser && (
        <form onSubmit={handleUpdateUser} className="card" style={{
          padding: '1.5rem', background: 'var(--bg)',
          display: 'grid', gap: '1rem',
        }}>
          <div>
            <p className="microlabel" style={{ marginBottom: '0.35rem', color: 'var(--warning)' }}>editing</p>
            <h2 style={{ margin: 0, fontSize: '1rem', fontFamily: 'var(--font-mono)', fontWeight: 600 }}>
              Edit Account: {editingUser.name}
            </h2>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '1rem' }}>
            <div>
              <label style={labelStyle}>Full Name</label>
              <input required type="text" value={editName} onChange={(e) => setEditName(e.target.value)} className="input" />
            </div>
            <div>
              <label style={labelStyle}>Email Address</label>
              <input required type="email" value={editEmail} onChange={(e) => setEditEmail(e.target.value)} className="input" />
            </div>
            <div>
              <label style={labelStyle}>New Password (leave blank to keep current)</label>
              <input type="password" value={editPassword} onChange={(e) => setEditPassword(e.target.value)} placeholder="••••••••" className="input" />
            </div>
            <div>
              <label style={labelStyle}>System Role</label>
              <select value={editRole} onChange={(e) => setEditRole(e.target.value as Role)} className="input">
                <option value="ADMIN">Regular Admin (Assigned)</option>
                <option value="SUPER_ADMIN">Main / Super Admin</option>
                <option value="DEPT_HEAD">Department Head</option>
                <option value="QA_OFFICER">Quality Assurance Officer</option>
              </select>
            </div>
          </div>

          <div style={{ display: 'flex', gap: '0.6rem', justifyContent: 'flex-end' }}>
            <button type="button" onClick={handleCancelEdit} className="btn btn-ghost">
              Cancel
            </button>
            <button type="submit" className="btn btn-primary">
              Save Changes
            </button>
          </div>
        </form>
      )}

      {/* Create Account Form */}
      {!editingUser && (
        <form onSubmit={handleCreateUser} className="card" style={{
          padding: '1.5rem', background: 'var(--bg)',
          display: 'grid', gap: '1rem',
        }}>
          <div>
            <p className="microlabel" style={{ marginBottom: '0.35rem' }}>create</p>
            <h2 style={{ margin: 0, fontSize: '1rem', fontFamily: 'var(--font-mono)', fontWeight: 600 }}>
              Create New System User / Admin Account
            </h2>
          </div>

          {error && <div style={{ color: 'var(--danger)', background: 'var(--bg)', padding: '0.75rem 1rem', borderRadius: 'var(--radius-sm)', border: 'var(--hairline)', fontWeight: 600, fontSize: '0.875rem' }}>⚠ {error}</div>}
          {success && <div style={{ color: 'var(--positive)', background: 'var(--bg)', padding: '0.75rem 1rem', borderRadius: 'var(--radius-sm)', border: 'var(--hairline)', fontWeight: 600, fontSize: '0.875rem' }}>✓ {success}</div>}

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '1rem' }}>
            <div>
              <label style={labelStyle}>Full Name</label>
              <input required type="text" value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Maria Santos" className="input" />
            </div>
            <div>
              <label style={labelStyle}>Email Address</label>
              <input required type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="e.g. msantos@sfms.local" className="input" />
            </div>
            <div>
              <label style={labelStyle}>Password</label>
              <input required type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="••••••••" className="input" />
            </div>
            <div>
              <label style={labelStyle}>System Role</label>
              <select value={role} onChange={(e) => setRole(e.target.value as Role)} className="input">
                <option value="ADMIN">Regular Admin (Assigned)</option>
                <option value="SUPER_ADMIN">Main / Super Admin</option>
                <option value="DEPT_HEAD">Department Head</option>
                <option value="QA_OFFICER">Quality Assurance Officer</option>
              </select>
            </div>
          </div>

          <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
            <button disabled={isCreating} className="btn btn-primary">
              {isCreating ? 'Creating Account…' : 'Create Account'}
            </button>
          </div>
        </form>
      )}

      {/* Account Roster Table */}
      <section className="card" style={{ padding: '1.5rem', background: 'var(--bg)' }}>
        <p className="microlabel" style={{ marginBottom: '0.35rem' }}>roster</p>
        <h2 style={{ margin: '0 0 1rem', fontSize: '1rem', fontFamily: 'var(--font-mono)', fontWeight: 600 }}>
          System Accounts &amp; Role Permissions
        </h2>

        <div className="table-scroll">
          <table className="table">
            <thead>
              <tr>
                <th>User / Email</th>
                <th>Role</th>
                <th>Status</th>
                <th>Created</th>
                <th style={{ textAlign: 'right' }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {users.map((user) => (
                <tr key={user.id}>
                  <td>
                    <strong style={{ color: 'var(--ink)', display: 'block', fontWeight: 600 }}>{user.name}</strong>
                    <span className="microlabel" style={{ color: 'var(--gray-400)' }}>{user.email}</span>
                  </td>
                  <td>
                    <span className={user.role === 'SUPER_ADMIN' ? 'chip-inverted' : 'chip'}>{user.role.toLowerCase()}</span>
                  </td>
                  <td>
                    <span className="chip" style={user.isActive ? { color: 'var(--positive)' } : { color: 'var(--danger)' }}>
                      {user.isActive ? 'active' : 'deactivated'}
                    </span>
                  </td>
                  <td style={{ color: 'var(--gray-500)', fontSize: '0.8125rem' }}>
                    {new Date(user.createdAt).toLocaleDateString()}
                  </td>
                  <td style={{ textAlign: 'right' }}>
                    <div style={{ display: 'inline-flex', gap: '0.4rem', flexWrap: 'wrap', justifyContent: 'flex-end' }}>
                      <button
                        onClick={() => handleStartEdit(user)}
                        disabled={loadingId === user.id}
                        className="btn btn-ghost"
                        style={{ fontSize: '0.75rem', padding: '0.4rem 0.85rem' }}
                      >
                        edit
                      </button>
                      <button
                        onClick={() => handleToggleActive(user)}
                        disabled={loadingId === user.id || user.id === currentUserId}
                        className="btn btn-ghost"
                        style={{
                          fontSize: '0.75rem', padding: '0.4rem 0.85rem',
                          color: user.isActive ? 'var(--danger)' : 'var(--positive)',
                          borderColor: 'var(--gray-300)',
                          cursor: user.id === currentUserId ? 'not-allowed' : 'pointer',
                          opacity: user.id === currentUserId ? 0.5 : 1,
                        }}
                      >
                        {user.isActive ? 'deactivate' : 'activate'}
                      </button>
                      <button
                        onClick={() => handleDeleteUser(user)}
                        disabled={loadingId === user.id || user.id === currentUserId}
                        className="btn btn-danger"
                        style={{
                          fontSize: '0.75rem', padding: '0.4rem 0.85rem',
                          cursor: user.id === currentUserId ? 'not-allowed' : 'pointer',
                          opacity: user.id === currentUserId ? 0.5 : 1,
                        }}
                      >
                        delete
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

    </div>
  );
}

const labelStyle: React.CSSProperties = { display: 'block', fontSize: '0.8125rem', fontWeight: 600, color: 'var(--gray-500)', marginBottom: '0.35rem' };