'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

type RequestItem = {
  id: string;
  academicYear: string;
  semester: string;
  reportType: string;
  status: string;
  requestedAt: string;
  rejectionNote: string | null;
  requester: { name: string; email: string };
};

export default function ReportRequestsClient({
  requests,
  userRole,
}: {
  requests: RequestItem[];
  currentUserId: string;
  userRole: string;
}) {
  const router = useRouter();
  const [academicYear, setAcademicYear] = useState('AY 2026–2027');
  const [semester, setSemester] = useState('First Semester');
  const [reportType, setReportType] = useState('Summary Report');
  const [submitting, setSubmitting] = useState(false);
  const [loadingId, setLoadingId] = useState<string | null>(null);
  const [rejectionNote, setRejectionNote] = useState('');
  const [activeRejectId, setActiveRejectId] = useState<string | null>(null);

  const handleCreateRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      const res = await fetch('/api/admin/report-requests', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'CREATE', academicYear, semester, reportType }),
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || 'Request failed');
      }
      router.refresh();
    } catch (error) {
      alert(error instanceof Error ? error.message : 'Error submitting request');
    } finally {
      setSubmitting(false);
    }
  };

  const handleApprove = async (id: string) => {
    if (!confirm('Approve this report request? The requesting admin will gain download privileges.')) return;
    setLoadingId(id);
    try {
      const res = await fetch('/api/admin/report-requests', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'APPROVE', requestId: id }),
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || 'Approval failed');
      }
      router.refresh();
    } catch (error) {
      alert(error instanceof Error ? error.message : 'Error approving request');
    } finally {
      setLoadingId(null);
    }
  };

  const handleReject = async (id: string) => {
    if (!rejectionNote.trim()) {
      alert('Please specify a rejection reason.');
      return;
    }
    setLoadingId(id);
    try {
      const res = await fetch('/api/admin/report-requests', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'REJECT', requestId: id, rejectionNote }),
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || 'Rejection failed');
      }
      setActiveRejectId(null);
      setRejectionNote('');
      router.refresh();
    } catch (error) {
      alert(error instanceof Error ? error.message : 'Error rejecting request');
    } finally {
      setLoadingId(null);
    }
  };

  const isSelf = (req: RequestItem) => req.requester.name === '';

  return (
    <div style={{ display: 'grid', gap: '1.5rem' }}>

      {/* Request Form (Visible to Admins / Hidden for Super Admins) */}
      {userRole !== 'SUPER_ADMIN' && (
        <form onSubmit={handleCreateRequest} className="card" style={{
          padding: '1.5rem',
          background: 'var(--bg)',
          display: 'grid',
          gap: '1rem',
        }}>
          <div>
            <p className="microlabel" style={{ marginBottom: '0.35rem' }}>new request</p>
            <h2 style={{ margin: 0, fontSize: '1rem', fontFamily: 'var(--font-mono)', fontWeight: 600 }}>
              Create New Report Request
            </h2>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '1rem' }}>
            <div>
              <label style={labelStyle}>Academic Year</label>
              <input required type="text" value={academicYear} onChange={(e) => setAcademicYear(e.target.value)} placeholder="e.g. AY 2026–2027" className="input" />
            </div>
            <div>
              <label style={labelStyle}>Semester</label>
              <select value={semester} onChange={(e) => setSemester(e.target.value)} className="input">
                <option value="First Semester">First Semester</option>
                <option value="Midyear">Midyear</option>
                <option value="Second Semester">Second Semester</option>
              </select>
            </div>
            <div>
              <label style={labelStyle}>Report Type</label>
              <select value={reportType} onChange={(e) => setReportType(e.target.value)} className="input">
                <option value="Summary Report">Summary Report</option>
                <option value="Detailed Response Export">Detailed Response Export</option>
              </select>
            </div>
          </div>

          <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
            <button type="submit" disabled={submitting} className="btn btn-primary">
              {submitting ? 'Submitting Request…' : 'Submit Report Request'}
            </button>
          </div>
        </form>
      )}

      {/* Requests History List */}
      <section className="card" style={{
        padding: '1.5rem', background: 'var(--bg)',
      }}>
        <p className="microlabel" style={{ marginBottom: '0.35rem' }}>request log</p>
        <h2 style={{ margin: '0 0 1rem', fontSize: '1rem', fontFamily: 'var(--font-mono)', fontWeight: 600 }}>
          Report Requests Log &amp; Approval Flow
        </h2>

        <div className="table-scroll">
          <table className="table">
            <thead>
              <tr>
                <th>Request Details</th>
                <th>Requested By</th>
                <th>Status</th>
                <th style={{ textAlign: 'right' }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {requests.length === 0 ? (
                <tr>
                  <td colSpan={4} style={{ padding: '2rem', textAlign: 'center', color: 'var(--gray-500)' }}>
                    No report requests found.
                  </td>
                </tr>
              ) : requests.map((req) => {
                const isPending = req.status === 'PENDING';
                const isApproved = req.status === 'APPROVED';
                const isRejected = req.status === 'REJECTED';
                const self = isSelf(req);
                const canReview = userRole === 'SUPER_ADMIN' && !self;

                return (
                  <tr key={req.id}>
                    <td>
                      <strong style={{ color: 'var(--ink)', display: 'block', fontWeight: 600 }}>{req.reportType}</strong>
                      <span className="microlabel" style={{ color: 'var(--gray-500)' }}>
                        {req.academicYear} · {req.semester}
                      </span>
                      <span className="microlabel" style={{ color: 'var(--gray-400)', display: 'block', marginTop: '0.15rem', lineHeight: 1.7 }}>
                        Requested: {new Date(req.requestedAt).toLocaleString()}
                      </span>
                      {req.rejectionNote && (
                        <p style={{ margin: '0.4rem 0 0', fontSize: '0.8125rem', color: 'var(--danger)', background: 'var(--bg)', padding: '0.4rem 0.6rem', borderRadius: 'var(--radius-xs)', border: 'var(--hairline)' }}>
                          Rejection Reason: {req.rejectionNote}
                        </p>
                      )}
                    </td>
                    <td>
                      <strong style={{ color: 'var(--ink)', display: 'block', fontWeight: 600 }}>{req.requester.name}</strong>
                      <span className="microlabel" style={{ color: 'var(--gray-400)' }}>{req.requester.email}</span>
                    </td>
                    <td>
                      <span className={isApproved ? 'chip-inverted' : isRejected ? 'chip' : 'chip'} style={isRejected ? { color: 'var(--danger)' } : undefined}>
                        {req.status.toLowerCase()}
                      </span>
                    </td>
                    <td style={{ textAlign: 'right', verticalAlign: 'middle' }}>
                      {isPending && canReview && (
                        <div style={{ display: 'inline-flex', gap: '0.5rem', alignItems: 'center', flexWrap: 'wrap', justifyContent: 'flex-end' }}>
                          <button
                            onClick={() => handleApprove(req.id)}
                            disabled={loadingId === req.id}
                            className="btn btn-success"
                            style={{ fontSize: '0.75rem', padding: '0.4rem 0.85rem' }}
                          >
                            approve
                          </button>

                          {activeRejectId === req.id ? (
                            <div style={{ display: 'flex', gap: '0.35rem', alignItems: 'center' }}>
                              <input
                                type="text"
                                placeholder="Specify reason…"
                                value={rejectionNote}
                                onChange={(e) => setRejectionNote(e.target.value)}
                                className="input"
                                style={{ padding: '0.35rem 0.6rem', fontSize: '0.8125rem', width: '150px' }}
                              />
                              <button
                                onClick={() => handleReject(req.id)}
                                disabled={loadingId === req.id}
                                className="btn btn-danger"
                                style={{ fontSize: '0.75rem', padding: '0.4rem 0.85rem' }}
                              >
                                submit
                              </button>
                            </div>
                          ) : (
                            <button
                              onClick={() => {
                                setActiveRejectId(req.id);
                                setRejectionNote('');
                              }}
                              className="btn btn-danger"
                              style={{ fontSize: '0.75rem', padding: '0.4rem 0.85rem' }}
                            >
                              reject
                            </button>
                          )}
                        </div>
                      )}

                      {isApproved && (
                        <span className="microlabel" style={{ color: 'var(--positive)' }}>✓ ready for generation</span>
                      )}

                      {isPending && self && (
                        <span className="microlabel" style={{ color: 'var(--warning)' }}>⌛ awaiting review</span>
                      )}

                      {isPending && !self && !canReview && (
                        <span className="microlabel" style={{ color: 'var(--gray-400)' }}>review restricted</span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}

const labelStyle: React.CSSProperties = { display: 'block', fontSize: '0.8125rem', fontWeight: 600, color: 'var(--gray-500)', marginBottom: '0.35rem' };