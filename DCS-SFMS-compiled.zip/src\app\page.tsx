import Link from 'next/link';
import ThemeToggle from '@/components/ThemeToggle';

export default function Home() {
  return (
    <div style={{
      minHeight: '100vh',
      background: 'var(--bg)',
      color: 'var(--ink)',
      display: 'flex',
      flexDirection: 'column',
      fontFamily: 'var(--font-body)',
      position: 'relative',
      zIndex: 1,
    }}>
      {/* Header */}
      <header style={{
        maxWidth: '1200px',
        width: '100%',
        margin: '0 auto',
        padding: '1.5rem 1.5rem',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        borderBottom: 'var(--hairline)',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.85rem' }}>
          <div style={{
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontFamily: 'var(--font-mono)', fontSize: '1rem', fontWeight: 600,
          }}>
            <span style={{ background: 'var(--primary)', color: '#ffffff', padding: '0.25rem 0.5rem', borderRadius: 'var(--radius-xs)' }}>CS</span>
          </div>
          <div>
            <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.8125rem', fontWeight: 600, display: 'block', letterSpacing: '0.02em' }}>
              CvSU — Imus Campus
            </span>
            <span className="microlabel">Department of Computer Studies</span>
          </div>
        </div>
        <ThemeToggle />
      </header>

      {/* Hero */}
      <main style={{
        flex: 1,
        maxWidth: '1000px',
        width: '100%',
        margin: '0 auto',
        padding: '4rem 1.5rem 3rem',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        textAlign: 'center',
      }}>
        <span className="num-label rise" style={{ fontSize: '0.8125rem', marginBottom: '1.5rem' }}>01 — system</span>

        <h1 className="rise rise-1" style={{
          fontFamily: 'var(--font-display)',
          fontSize: 'clamp(2.4rem, 7vw, 4.5rem)',
          fontWeight: 600,
          lineHeight: 1.05,
          letterSpacing: '-0.02em',
          margin: '0 0 1.75rem',
          textTransform: 'lowercase',
        }}>
          Stakeholder Feedback
          <br />
          Management System
        </h1>

        <p className="rise rise-2" style={{
          maxWidth: '560px',
          fontSize: '1.0625rem',
          lineHeight: 1.75,
          color: 'var(--gray-500)',
          margin: '0 0 3rem',
        }}>
          A streamlined digital platform for capturing, structuring, and analyzing stakeholder
          telemetry. Deploy instant feedback surveys via QR code and track satisfaction metrics
          in real time.
        </p>

        {/* QR icon — halftone, monochrome */}
        <div className="rise rise-3" style={{
          background: 'var(--gray-50)',
          border: 'var(--hairline)',
          borderRadius: 'var(--radius-lg)',
          padding: '1.5rem 2rem',
          display: 'flex',
          alignItems: 'center',
          gap: '1.5rem',
          flexWrap: 'nowrap',
          justifyContent: 'center',
          maxWidth: '500px',
          margin: '0 auto 2.5rem',
          boxShadow: 'var(--shadow-card)',
        }}>
          <div style={{
            width: '64px', height: '64px', borderRadius: 'var(--radius-sm)',
            background: 'var(--ink)', padding: '10px', flexShrink: 0,
          }}>
            <svg width="44" height="44" viewBox="0 0 240 240" fill="var(--bg)">
              <rect x="20" y="20" width="60" height="60" fill="none" stroke="var(--bg)" strokeWidth="12"/>
              <rect x="36" y="36" width="28" height="28"/>
              <rect x="160" y="20" width="60" height="60" fill="none" stroke="var(--bg)" strokeWidth="12"/>
              <rect x="176" y="36" width="28" height="28"/>
              <rect x="20" y="160" width="60" height="60" fill="none" stroke="var(--bg)" strokeWidth="12"/>
              <rect x="36" y="176" width="28" height="28"/>
              <rect x="100" y="20" width="16" height="40"/>
              <rect x="105" y="100" width="60" height="16"/>
            </svg>
          </div>
          <div style={{ textAlign: 'left' }}>
            <strong style={{ display: 'block', fontFamily: 'var(--font-mono)', fontSize: '0.875rem', letterSpacing: '0.04em' }}>
              Instant Mobile QR Access
            </strong>
            <span style={{ fontSize: '0.875rem', color: 'var(--gray-500)' }}>
              Scan event QR codes with any smartphone camera to answer.
            </span>
          </div>
        </div>

        <div className="rise rise-4" style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap', justifyContent: 'center' }}>
          <Link href="/admin/login" className="btn btn-primary" style={{ padding: '0.85rem 2rem' }}>
            Access Admin Portal →
          </Link>
          <Link href="/scan" className="btn btn-ghost" style={{ padding: '0.85rem 2rem' }}>
            View Active Surveys
          </Link>
        </div>
      </main>

      {/* Footer */}
      <footer style={{
        borderTop: 'var(--hairline)',
        padding: '1.5rem',
        textAlign: 'center',
      }}>
        <p className="microlabel" style={{ margin: 0 }}>Department of Computer Studies · Cavite State University — Imus Campus © 2026</p>
      </footer>
    </div>
  );
}