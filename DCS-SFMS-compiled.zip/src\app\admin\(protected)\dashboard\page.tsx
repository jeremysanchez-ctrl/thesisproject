import DashboardCharts from './DashboardCharts';
import { getDashboardData } from '@/lib/analytics';
import PageGuideNote from '@/components/PageGuideNote';
import ArchiveDashboardButton from './ArchiveDashboardButton';
import { requireAuth } from '@/lib/auth';

export default async function DashboardPage() {
  const [data, session] = await Promise.all([
    getDashboardData(),
    requireAuth(),
  ]);

  // Top Summary Cards
  const summaryCards = [
    { label: 'Total Respondents', value: data.totals.totalRespondents, sub: 'cumulative database count' },
    { label: 'Current Academic Year', value: data.totals.currentAcademicYear, sub: 'form configuration' },
    { label: 'Current Semester', value: data.totals.currentSemester, sub: 'active evaluation term' },
    { label: 'Most Common Stakeholder', value: data.totals.mostCommonStakeholder, sub: 'highest respondent group' },
    { label: 'Most Common Purpose', value: data.totals.mostCommonPurpose, sub: 'top transaction reason' },
  ];

  return (
    <div className="content-wrap" style={{ display: 'grid', gap: '1.75rem' }}>
      <header className="rise" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '1rem' }}>
        <div>
          <span className="num-label">01 — telemetry</span>
          <h1 className="page-title" style={{ fontSize: 'clamp(1.8rem, 4vw, 2.6rem)' }}>Feedback Dashboard</h1>
          <p className="page-desc">Live telemetry metrics, semester volume breakdowns, and satisfaction signals computed strictly from database records.</p>
        </div>
        <div style={{ marginTop: '0.5rem' }}>
          <ArchiveDashboardButton userRole={session.role} />
        </div>
      </header>

      <PageGuideNote
        pageTitle="the Dashboard"
        overview="The Dashboard automatically aggregates respondent metrics, computes semester trends, identifies high/low satisfaction concerns, and breaks down stakeholder demographics using real-time database calculations."
        steps={[
          { title: 'Top Summary Cards', description: 'Monitor Total Respondents, Current Academic Year, Current Semester, Most Common Stakeholder, and Most Common Purpose.' },
          { title: 'Respondents & Purpose per Semester', description: 'Review bar charts tracking survey volume and transaction visit reasons across academic terms.' },
          { title: 'Satisfaction Concerns Comparison', description: 'Identify top-performing service dimensions vs areas requiring department attention.' }
        ]}
      />

      {/* TOP SUMMARY CARDS */}
      <section className="rise rise-1" style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '0.75rem' }}>
        {summaryCards.map((card) => (
          <article key={card.label} className="card card-hover" style={{ padding: '1.25rem', display: 'grid', gap: '0.35rem' }}>
            <p className="microlabel" style={{ margin: 0 }}>{card.label}</p>
            <strong style={{
              color: 'var(--ink)',
              fontSize: card.value.toString().length > 15 ? '1.5rem' : '1.75rem',
              fontFamily: 'var(--font-display)',
              fontWeight: 600,
              lineHeight: 1.1,
            }}>
              {card.value}
            </strong>
            <span className="microlabel" style={{ color: 'var(--gray-500)' }}>{card.sub}</span>
          </article>
        ))}
      </section>

      {/* CHARTS */}
      <div className="rise rise-2">
        <DashboardCharts data={data} />
      </div>

      {/* RECENT SUBMISSIONS & TOP QR ACCESS */}
      <section className="rise rise-3" style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: '1rem' }}>
        <article className="card" style={{ padding: '1.5rem' }}>
          <p className="microlabel" style={{ marginBottom: '1rem' }}>qr access</p>
          <h2 style={{ fontFamily: 'var(--font-mono)', fontSize: '1rem', fontWeight: 600, margin: '0 0 1rem' }}>Top Active QR Codes</h2>
          <div style={{ display: 'grid', gap: '0.75rem' }}>
            {data.topQrCodes.length === 0 ? (
              <p style={{ color: 'var(--gray-500)', fontSize: '0.9375rem', margin: 0 }}>No QR code scans recorded yet.</p>
            ) : data.topQrCodes.map((qrCode) => (
              <div key={qrCode.id} style={{
                display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                borderBottom: 'var(--hairline)', paddingBottom: '0.75rem',
              }}>
                <span style={{ fontSize: '0.9375rem', fontWeight: 500 }}>{qrCode.eventName}</span>
                <strong style={{ fontFamily: 'var(--font-mono)', fontSize: '0.9375rem' }}>{qrCode.scanCount} scans</strong>
              </div>
            ))}
          </div>
        </article>

        <article className="card" style={{ padding: '1.5rem' }}>
          <p className="microlabel" style={{ marginBottom: '1rem' }}>responses</p>
          <h2 style={{ fontFamily: 'var(--font-mono)', fontSize: '1rem', fontWeight: 600, margin: '0 0 1rem' }}>Recent Response Activity</h2>
          <div style={{ display: 'grid', gap: '0.85rem' }}>
            {data.recentResponses.length === 0 ? (
              <p style={{ color: 'var(--gray-500)', fontSize: '0.9375rem', margin: 0 }}>No responses submitted yet.</p>
            ) : data.recentResponses.map((resp) => (
              <div key={resp.id} style={{ borderBottom: 'var(--hairline)', paddingBottom: '0.75rem' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <strong style={{ fontFamily: 'var(--font-mono)', fontSize: '0.875rem' }}>{resp.controlNo}</strong>
                  <span className="microlabel">{resp.dateOfVisit}</span>
                </div>
                <p style={{ color: 'var(--ink)', margin: '0.15rem 0 0', fontSize: '0.9375rem', fontWeight: 600 }}>{resp.formTitle}</p>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: '0.25rem', flexWrap: 'wrap', gap: '0.5rem' }}>
                  <p style={{ color: 'var(--gray-500)', margin: 0, fontSize: '0.875rem' }}>
                    {resp.department !== 'N/A' ? `${resp.department} · ` : ''}{resp.categoryName} · {resp.eventName}
                  </p>
                  {resp.hardCopyPhotoUrl && (
                    <a
                      href={resp.hardCopyPhotoUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="chip chip-accent"
                      style={{ fontSize: '0.75rem', textDecoration: 'none', display: 'inline-flex', alignItems: 'center', gap: '0.3rem', padding: '0.2rem 0.55rem' }}
                    >
                      📷 View Hard Copy
                    </a>
                  )}
                </div>
              </div>
            ))}
          </div>
        </article>
      </section>
    </div>
  );
}