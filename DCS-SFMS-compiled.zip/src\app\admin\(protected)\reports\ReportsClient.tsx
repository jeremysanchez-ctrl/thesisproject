'use client';

import { useState } from 'react';
import Link from 'next/link';

type FormOption = { id: string; label: string };

export default function ReportsClient({
  formOptions,
  canDownloadSummary,
  canDownloadDetailed,
}: {
  formOptions: FormOption[];
  canDownloadSummary: boolean;
  canDownloadDetailed: boolean;
  isSuperAdmin: boolean;
}) {
  const [selectedFormId, setSelectedFormId] = useState(formOptions[0]?.id ?? '');

  const reportTypes = [
    {
      id: 'summary',
      dbType: 'Summary Report',
      label: 'Summary of Results — Stakeholder Feedback Form',
      description:
        'Official Cavite State University summary report formatted to match the DCS Stakeholder Feedback form: satisfaction ratings per area of concern, demographic breakdown, and signature block.',
      canDownload: canDownloadSummary,
    },
    {
      id: 'stakeholder',
      dbType: 'Detailed Response Export',
      label: 'Detailed Stakeholder Response Report',
      description:
        'Individual response records per respondent, replicating the exact feedback form layout with checkmarked answers for each area of concern.',
      canDownload: canDownloadDetailed,
    },
  ];

  const formats = ['pdf', 'xlsx', 'csv'];

  return (
    <div style={{ display: 'grid', gap: '1.5rem' }}>

      {/* Form Selector */}
      <div className="card" style={{ padding: '1.25rem 1.5rem', background: 'var(--bg)', display: 'grid', gap: '0.6rem' }}>
        <label className="microlabel" style={{ color: 'var(--gray-500)' }}>
          Select Active Survey Form to Report On
        </label>
        {formOptions.length === 0 ? (
          <p style={{ color: 'var(--danger)', fontWeight: 600, fontSize: '0.906rem' }}>
            ⚠ No active forms found. Activate a survey form first before generating reports.
          </p>
        ) : (
          <select
            value={selectedFormId}
            onChange={e => setSelectedFormId(e.target.value)}
            className="input"
          >
            {formOptions.map(f => (
              <option key={f.id} value={f.id}>{f.label}</option>
            ))}
          </select>
        )}
      </div>

      {/* Report Cards */}
      <section style={{ display: 'grid', gap: '0.75rem' }}>
        {reportTypes.map(report => (
          <article key={report.id} className="card" style={{
            padding: '1.5rem',
            background: 'var(--bg)',
            display: 'flex',
            gap: '1.25rem',
            alignItems: 'center',
            flexWrap: 'wrap',
          }}>
            <div style={{ flex: '1 1 400px' }}>
              <p className="microlabel" style={{ marginBottom: '0.4rem' }}>{report.dbType}</p>
              <h2 style={{ fontFamily: 'var(--font-mono)', fontSize: '1rem', fontWeight: 600, margin: '0 0 0.5rem' }}>
                {report.label}
              </h2>
              <p style={{ color: 'var(--gray-500)', margin: 0, fontSize: '0.9375rem', lineHeight: 1.6 }}>
                {report.description}
              </p>
              {!report.canDownload && (
                <p style={{ color: 'var(--warning)', margin: '0.5rem 0 0', fontWeight: 600, fontSize: '0.875rem' }}>
                  ⚠ Download locked. Request approval in the{' '}
                  <Link href="/admin/report-requests" style={{ textDecoration: 'underline', textDecorationColor: 'var(--gray-400)' }}>Report Approvals</Link> section.
                </p>
              )}
            </div>
            <div style={{ display: 'flex', gap: '0.6rem', flexWrap: 'wrap' }}>
              {formats.map(format => {
                if (report.canDownload && selectedFormId) {
                  return (
                    <a
                      key={format}
                      href={`/api/reports/${report.id}?format=${format}&formId=${selectedFormId}`}
                      className="btn btn-primary"
                    >
                      Export {format.toUpperCase()}
                    </a>
                  );
                } else {
                  return (
                    <span
                      key={format}
                      style={{
                        border: 'var(--hairline)', borderRadius: 'var(--radius-sm)',
                        padding: '0.65rem 1.15rem', color: 'var(--gray-400)',
                        fontWeight: 600, fontSize: '0.8125rem', cursor: 'not-allowed',
                        display: 'inline-block',
                      }}
                    >
                      Export {format.toUpperCase()}
                    </span>
                  );
                }
              })}
            </div>
          </article>
        ))}
      </section>
    </div>
  );
}