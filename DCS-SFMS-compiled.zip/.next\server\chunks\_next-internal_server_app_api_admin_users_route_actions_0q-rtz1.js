module.exports=[38653,(__turbopack_context__,module1,exports)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_users_route_actions_0q-rtz1.js.map