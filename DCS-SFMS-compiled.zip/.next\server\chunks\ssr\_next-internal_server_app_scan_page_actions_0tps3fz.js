module.exports=[70841,(__turbopack_context__,module1,exports)=>{}];

//# sourceMappingURL=_next-internal_server_app_scan_page_actions_0tps3fz.js.map