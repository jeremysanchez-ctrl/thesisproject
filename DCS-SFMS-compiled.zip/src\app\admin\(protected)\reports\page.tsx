import PageGuideNote from '@/components/PageGuideNote';
import { requireAuth } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import ReportsClient from './ReportsClient';

export default async function ReportsPage() {
  const session = await requireAuth();

  // Find all approved report requests for this user (if not Super Admin)
  const approvedRequests = session.role === 'SUPER_ADMIN' ? [] : await prisma.reportRequest.findMany({
    where: {
      requestedBy: session.userId,
      status: 'APPROVED',
    },
    select: { reportType: true },
  });

  const approvedSet = new Set(approvedRequests.map(r => r.reportType));
  const isSuperAdmin = session.role === 'SUPER_ADMIN';
  const canDownloadSummary = isSuperAdmin || approvedSet.has('Summary Report');
  const canDownloadDetailed = isSuperAdmin || approvedSet.has('Detailed Response Export');

  // Load all ACTIVE forms for the form selector
  const activeForms = await prisma.surveyForm.findMany({
    where: { status: 'ACTIVE' },
    include: { event: true },
    orderBy: { createdAt: 'desc' },
  });

  const formOptions = activeForms.map(f => ({
    id: f.id,
    label: `${f.title} — ${f.event.name} (${f.academicYear ?? ''} ${f.semester ?? ''})`,
  }));

  return (
    <div className="content-wrap" style={{ display: 'grid', gap: '1.75rem' }}>
      <header className="rise">
        <span className="num-label">05 — reporting & export</span>
        <h1 className="page-title" style={{ fontSize: 'clamp(1.8rem, 4vw, 2.6rem)' }}>Export Feedback Reports</h1>
        <p className="page-desc">Download PDF, Excel, or CSV reports for departmental quality assurance, accreditation, and administrative review.</p>
      </header>

      <PageGuideNote
        pageTitle="Reports & Exports"
        overview="The Reports page generates formatted downloadable documents summarizing stakeholder responses. Select the active survey form to generate reports for that specific form."
        steps={[
          { title: 'Select Active Form', description: 'Choose which active survey form to generate the report for.' },
          { title: 'Choose Format', description: 'Download as PDF (official format), Excel, or CSV.' },
          ...(isSuperAdmin ? [] : [{ title: 'Approval Required', description: 'Non-super admin roles must have an approved request before downloading.' }]),
        ]}
      />

      <div className="rise rise-1">
        <ReportsClient
          formOptions={formOptions}
          canDownloadSummary={canDownloadSummary}
          canDownloadDetailed={canDownloadDetailed}
          isSuperAdmin={isSuperAdmin}
        />
      </div>
    </div>
  );
}