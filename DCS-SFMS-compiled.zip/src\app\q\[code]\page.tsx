import { notFound, redirect } from 'next/navigation';
import { prisma } from '@/lib/prisma';

export default async function QRScanPage({ params }: { params: Promise<{ code: string }> }) {
  const { code } = await params;
  const qrCode = await prisma.qRCode.findUnique({
    where: { codeString: code },
    include: { event: { include: { Forms: { where: { status: 'ACTIVE' }, orderBy: { createdAt: 'desc' }, take: 1 } } } },
  });
  const now = new Date();
  const form = qrCode?.event.Forms[0];
  if (!qrCode || !form || (qrCode.expiresAt && qrCode.expiresAt < now) || (form.scheduledStart && form.scheduledStart > now) || (form.scheduledEnd && form.scheduledEnd < now)) {
    notFound();
  }

  await prisma.qRCode.update({ where: { id: qrCode.id }, data: { scanCount: { increment: 1 } } });
  redirect(`/form/${form.id}`);
}
