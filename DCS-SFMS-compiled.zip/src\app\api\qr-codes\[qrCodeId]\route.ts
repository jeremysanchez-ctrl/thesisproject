import QRCode from 'qrcode';
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getAppUrl } from '@/lib/appUrl';

export async function GET(request: NextRequest, context: { params: Promise<{ qrCodeId: string }> }) {
  const { qrCodeId } = await context.params;
  const qrCode = await prisma.qRCode.findUnique({ where: { id: qrCodeId }, select: { codeString: true } });
  if (!qrCode) {
    return NextResponse.json({ error: 'QR code not found' }, { status: 404 });
  }

  // Allow client to pass the public/tunnel URL so the QR encodes the correct address
  const customBase = request.nextUrl.searchParams.get('baseUrl');
  const baseUrl = customBase ? customBase.replace(/\/$/, '') : await getAppUrl();

  const image = await QRCode.toBuffer(`${baseUrl}/q/${qrCode.codeString}`, {
    width: 480,
    margin: 2,
    color: { dark: '#0B1120', light: '#FFFFFF' },
  });

  return new NextResponse(Uint8Array.from(image), {
    headers: {
      'Content-Type': 'image/png',
      'Cache-Control': 'no-cache, no-store, must-revalidate',
    },
  });
}
