'use client';

import { useState } from 'react';

export default function SystemControlClient() {
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState('');

  const handleShutdown = async () => {
    if (!confirm('⚠ WARNING: This will immediately SHUT DOWN the survey backend server. The site will become offline and unreachable. You will have to run the Desktop "Start_DCS_SFMS" script to turn it back on. Proceed?')) {
      return;
    }
    setLoading(true);
    setMsg('Sending shutdown command to PM2 process controller…');
    try {
      const res = await fetch('/api/admin/system/shutdown', {
        method: 'POST'
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Shutdown call failed');
      setMsg('Shutdown sequence initiated successfully. The application server is closing down…');
    } catch (err) {
      setMsg(err instanceof Error ? err.message : 'Error executing shutdown sequence.');
      setLoading(false);
    }
  };

  return (
    <div className="card" style={{
      padding: '2rem', background: 'var(--bg)',
      display: 'grid', gap: '1.5rem',
    }}>
      <div>
        <p className="microlabel" style={{ marginBottom: '0.35rem', color: 'var(--danger)' }}>shutdown</p>
        <h3 style={{ margin: 0, fontFamily: 'var(--font-mono)', fontSize: '1rem', fontWeight: 600 }}>
          Remote Application Shutdown
        </h3>
        <p style={{ margin: '0.5rem 0 0', color: 'var(--gray-500)', fontSize: '0.9375rem', lineHeight: 1.6 }}>
          Clicking the shutdown button will gracefully stop the running Next.js application service in the background. The survey and administrator panels will be completely offline until restarted.
        </p>
      </div>

      <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', flexWrap: 'wrap' }}>
        <button
          onClick={handleShutdown}
          disabled={loading}
          className="btn"
          style={{
            background: 'var(--danger)',
            color: '#fff',
            padding: '0.85rem 1.5rem',
          }}
        >
          {loading ? 'Shutting Down Server…' : '\u25C9 Shut Down Server Process'}
        </button>

        {msg && (
          <span style={{
            color: 'var(--warning)', background: 'var(--bg)',
            padding: '0.6rem 1rem', borderRadius: 'var(--radius-xs)', fontWeight: 600,
            fontSize: '0.875rem', border: 'var(--hairline)',
          }}>
            {msg}
          </span>
        )}
      </div>
    </div>
  );
}