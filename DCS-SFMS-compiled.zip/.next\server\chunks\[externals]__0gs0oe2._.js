module.exports=[14747,(__turbopack_context__,module1,exports)=>{module1.exports=__turbopack_context__.x("path",()=>require("path"))},22734,(__turbopack_context__,module1,exports)=>{module1.exports=__turbopack_context__.x("fs",()=>require("fs"))}];

//# sourceMappingURL=%5Bexternals%5D__0gs0oe2._.js.map