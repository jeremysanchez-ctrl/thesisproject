module.exports=[28873,(__turbopack_context__,module1,exports)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_%28protected%29_users_page_actions_1y6jaul.js.map