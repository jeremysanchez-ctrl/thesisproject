var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/system/shutdown/route.js")
R.c("server/chunks/[root-of-the-server]__17y8cta._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_0htkyro._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_system_shutdown_route_actions_1uq1q74.js")
R.m(13273)
module.exports=R.m(13273).exports
