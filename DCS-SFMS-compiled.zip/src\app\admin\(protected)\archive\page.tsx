import { prisma } from '@/lib/prisma';
import { requireAuth } from '@/lib/auth';
import { redirect } from 'next/navigation';
import PageGuideNote from '@/components/PageGuideNote';
import ArchiveListClient from './ArchiveListClient';

export default async function ArchivePage() {
  const session = await requireAuth();
  if (!['SUPER_ADMIN', 'ADMIN'].includes(session.role)) {
    redirect('/admin/dashboard');
  }

  const [archivedForms, archivedResponses] = await Promise.all([
    prisma.surveyForm.findMany({
      where: { status: 'ARCHIVED' },
      include: {
        event: true,
        _count: { select: { Questions: true, Responses: true } }
      },
      orderBy: { archivedAt: 'desc' }
    }),
    prisma.response.findMany({
      where: { isArchived: true },
      include: {
        form: { select: { title: true } },
        stakeholderCategory: { select: { name: true } },
      },
      orderBy: { submittedAt: 'desc' },
      take: 200,
    }),
  ]);

  return (
    <div className="content-wrap" style={{ display: 'grid', gap: '1.75rem' }}>
      <header className="rise">
        <span className="num-label">04 — trash / archive</span>
        <h1 className="page-title" style={{ fontSize: 'clamp(1.8rem, 4vw, 2.6rem)' }}>Trash &amp; Archive Management</h1>
        <p className="page-desc">View, restore, or permanently delete archived feedback forms and respondent records.</p>
      </header>

      <PageGuideNote
        pageTitle="Trash / Archive"
        overview="The Archive safety bin prevents accidental data loss by preserving survey forms and their associated respondent records instead of deleting them permanently."
        steps={[
          { title: 'Preserved Responses', description: 'Archived responses and forms are safely separated from live dashboard metrics.' },
          { title: 'Restore Option', description: 'Click Restore on any record to reactivate it back to the active dashboard.' },
          { title: 'Permanent Delete / Empty Trash', description: 'Permanently remove records or empty the entire trash when no longer needed.' }
        ]}
      />

      <section className="rise rise-1">
        <ArchiveListClient forms={archivedForms} responses={archivedResponses} userRole={session.role} />
      </section>
    </div>
  );
}