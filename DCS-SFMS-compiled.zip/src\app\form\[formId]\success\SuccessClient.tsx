'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { useSearchParams, useParams } from 'next/navigation';

function CheckmarkAnimation() {
  return (
    <div style={{ position: 'relative', width: '110px', height: '110px', margin: '0 auto 2rem' }}>
      <style>{`
        @keyframes scaleIn {
          0% { transform: scale(0); opacity: 0; }
          60% { transform: scale(1.15); opacity: 1; }
          100% { transform: scale(1); opacity: 1; }
        }
        @keyframes drawCheck {
          0% { stroke-dashoffset: 60; opacity: 0; }
          40% { opacity: 1; }
          100% { stroke-dashoffset: 0; opacity: 1; }
        }
        @keyframes rippleRing {
          0% { transform: scale(0.8); opacity: 0.6; }
          100% { transform: scale(1.8); opacity: 0; }
        }
        @keyframes fadeSlideUp {
          0% { opacity: 0; transform: translateY(24px); }
          100% { opacity: 1; transform: translateY(0); }
        }
        .anim-circle { animation: scaleIn 0.6s cubic-bezier(0.34, 1.56, 0.64, 1) forwards; }
        .anim-check { stroke-dasharray: 60; animation: drawCheck 0.6s 0.35s ease forwards; }
        .anim-ripple { animation: rippleRing 1.2s 0.5s ease-out infinite; }
        .anim-slide-1 { animation: fadeSlideUp 0.5s 0.2s ease forwards; opacity: 0; }
        .anim-slide-2 { animation: fadeSlideUp 0.5s 0.4s ease forwards; opacity: 0; }
        .anim-slide-3 { animation: fadeSlideUp 0.5s 0.6s ease forwards; opacity: 0; }
        .anim-slide-4 { animation: fadeSlideUp 0.5s 0.8s ease forwards; opacity: 0; }
        .btn-answer-again:hover { box-shadow: 0 8px 24px rgba(0,0,0,0.4) !important; transform: translateY(-2px); }
        .btn-exit:hover { background: var(--gray-100) !important; }
        .btn-answer-again, .btn-exit { transition: all 0.2s ease !important; }
      `}</style>

      {/* Ripple ring */}
      <div className="anim-ripple" style={{
        position: 'absolute', inset: 0, borderRadius: '50%',
        border: '2px solid var(--ink)', pointerEvents: 'none'
      }} />

      {/* Inverted circle */}
      <div className="anim-circle" style={{
        width: '110px', height: '110px', borderRadius: '50%',
        background: 'var(--ink)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        boxShadow: 'var(--shadow-card-hover)',
        position: 'relative', zIndex: 1,
      }}>
        <svg width="52" height="52" viewBox="0 0 24 24" fill="none" stroke="var(--bg)" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
          <path className="anim-check" d="M5 13l4 4L19 7" />
        </svg>
      </div>
    </div>
  );
}

export default function SuccessPageClient() {
  const searchParams = useSearchParams();
  const params = useParams();
  const formId = params.formId as string;
  const controlNumber = searchParams.get('ctrl') || 'SFMS-SUBMITTED';
  const [copied, setCopied] = useState(false);
  const [submittedAt, setSubmittedAt] = useState('');

  useEffect(() => {
    // Timestamp is generated client-side only to avoid SSR/hydration mismatch.
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setSubmittedAt(new Date().toLocaleString('en-US', {
      weekday: 'long', year: 'numeric', month: 'long',
      day: 'numeric', hour: '2-digit', minute: '2-digit', second: '2-digit'
    }));
  }, []);

  const handleCopy = () => {
    navigator.clipboard.writeText(controlNumber).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  return (
    <div style={{
      minHeight: '100vh',
      background: 'var(--bg)',
      color: 'var(--ink)',
      display: 'flex', flexDirection: 'column',
      alignItems: 'center', justifyContent: 'center',
      padding: '2rem 1rem',
      fontFamily: 'var(--font-body)',
      position: 'relative', zIndex: 1,
    }}>
      <main style={{
        maxWidth: '620px', width: '100%',
        background: 'var(--gray-50)',
        border: 'var(--hairline)',
        borderRadius: 'var(--radius-lg)',
        boxShadow: 'var(--shadow-card)',
        overflow: 'hidden',
      }}>

        {/* Inverted header strip */}
        <div style={{
          background: 'var(--ink)',
          color: 'var(--bg)',
          padding: '2rem 2rem 1.25rem',
          textAlign: 'center',
        }}>
          <p className="microlabel anim-slide-1" style={{ color: 'var(--gray-400)', letterSpacing: '0.16em', margin: '0 0 0.3rem' }}>
            Republic of the Philippines
          </p>
          <h2 className="anim-slide-1" style={{ fontFamily: 'var(--font-mono)', fontSize: '1.05rem', fontWeight: 600, color: 'var(--bg)', margin: 0, letterSpacing: '0.04em' }}>
            CAVITE STATE UNIVERSITY — IMUS CAMPUS
          </h2>
          <p className="microlabel anim-slide-1" style={{ color: 'var(--gray-400)', margin: '0.3rem 0 0' }}>
            Department of Computer Studies
          </p>
        </div>

        {/* Main content body */}
        <div style={{ padding: '2.5rem 2rem 1.75rem', textAlign: 'center' }}>

          {/* Animated checkmark */}
          <CheckmarkAnimation />

          <div className="anim-slide-2">
            <h1 style={{
              fontFamily: 'var(--font-mono)',
              fontSize: '1.75rem', fontWeight: 600,
              color: 'var(--ink)', margin: '0 0 0.6rem',
              letterSpacing: '0.02em',
            }}>
              Thank you!
            </h1>
            <p style={{ color: 'var(--gray-500)', fontSize: '0.9375rem', lineHeight: 1.65, margin: '0 0 0.5rem' }}>
              Your feedback has been <strong style={{ color: 'var(--ink)' }}>successfully recorded</strong>.
            </p>
            <p style={{ color: 'var(--gray-500)', fontSize: '0.875rem', lineHeight: 1.6, margin: 0 }}>
              Your response helps Cavite State University — Imus Campus continuously improve the quality,
              timeliness, and efficiency of our services.
            </p>
          </div>

          {/* Control Number Card */}
          <div className="anim-slide-3" style={{
            background: 'var(--bg)',
            border: 'var(--hairline)',
            borderStyle: 'dashed',
            borderRadius: 'var(--radius-md)',
            padding: '1.25rem',
            margin: '1.75rem 0',
          }}>
            <span className="microlabel" style={{ display: 'block', color: 'var(--gray-500)', marginBottom: '0.5rem' }}>
              Submission Control Number
            </span>
            <strong style={{
              display: 'block', fontSize: '1.4rem',
              color: 'var(--ink)', fontFamily: 'var(--font-mono)',
              letterSpacing: '0.04em', marginBottom: '0.6rem', fontWeight: 600,
            }}>
              {controlNumber}
            </strong>
            {submittedAt && (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.25rem', margin: '0 0 0.75rem' }}>
                <p className="microlabel" style={{ color: 'var(--gray-600)', margin: 0 }}>
                  date of visit: {new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}
                </p>
                <p className="microlabel" style={{ color: 'var(--gray-400)', margin: 0 }}>
                  submitted at: {submittedAt}
                </p>
              </div>
            )}
            <button
              onClick={handleCopy}
              className="btn btn-ghost"
              style={{
                background: copied ? 'var(--ink)' : 'transparent',
                color: copied ? 'var(--bg)' : 'var(--ink)',
                transition: 'all var(--motion-1)',
              }}
            >
              {copied ? 'Copied!' : 'Copy control no.'}
            </button>
          </div>

          {/* Answer Again section */}
          <div className="anim-slide-4" style={{
            borderTop: 'var(--hairline)',
            paddingTop: '1.5rem',
          }}>
            <p style={{ fontFamily: 'var(--font-mono)', fontWeight: 600, color: 'var(--ink)', marginBottom: '0.5rem', fontSize: '0.9375rem' }}>
              Would you like to answer again?
            </p>
            <p style={{ color: 'var(--gray-500)', fontSize: '0.875rem', marginBottom: '1.25rem', lineHeight: 1.5 }}>
              If you have additional feedback or a different purpose of visit, you may submit another response.
            </p>

            <div style={{ display: 'flex', gap: '0.75rem', justifyContent: 'center', flexWrap: 'wrap' }}>
              <Link
                href={`/form/${formId}`}
                className="btn btn-primary btn-answer-again"
                style={{ flex: '1', minWidth: '170px' }}
              >
                Yes, answer again →
              </Link>

              <button
                className="btn btn-ghost btn-exit"
                onClick={() => window.close()}
                style={{ flex: '1', minWidth: '150px' }}
              >
                No, I&apos;m done
              </button>
            </div>
          </div>
        </div>

        {/* Footer bar */}
        <div style={{
          background: 'var(--gray-50)',
          borderTop: 'var(--hairline)',
          padding: '0.9rem 2rem',
          textAlign: 'center',
          display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.6rem', flexWrap: 'wrap',
        }}>
          <span className="microlabel" style={{ color: 'var(--gray-500)' }}>
            CvSU HRDO-QF-07 · Stakeholders&apos; Feedback Management System
          </span>
          <span style={{ color: 'var(--gray-300)', fontSize: '0.8rem' }}>|</span>
          <span className="microlabel" style={{ color: 'var(--gray-500)' }}>V01-2018-06-19</span>
        </div>
      </main>
    </div>
  );
}