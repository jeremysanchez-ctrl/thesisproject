var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/reports/[reportType]/route.js")
R.c("server/chunks/[root-of-the-server]__04rypl6._.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_1ks8rgj.js")
R.c("server/chunks/_0htkyro._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_reports_[reportType]_route_actions_1fwpbsq.js")
R.m(52392)
module.exports=R.m(52392).exports
