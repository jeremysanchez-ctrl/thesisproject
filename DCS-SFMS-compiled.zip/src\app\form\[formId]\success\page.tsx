import { Suspense } from 'react';
import SuccessClient from './SuccessClient';

export default function SuccessPage() {
  return (
    <Suspense fallback={
      <div style={{
        minHeight: '100vh',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        background: 'var(--bg)',
        fontFamily: 'var(--font-body)',
        color: 'var(--ink)',
        position: 'relative', zIndex: 1,
      }}>
        <div style={{ textAlign: 'center' }}>
          <div style={{
            width: '56px', height: '56px', borderRadius: '50%',
            border: '2px solid var(--gray-200)', borderTopColor: 'var(--ink)',
            animation: 'spin 0.8s linear infinite', margin: '0 auto 1rem'
          }} />
          <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
          <p className="microlabel" style={{ color: 'var(--gray-500)', margin: 0 }}>loading</p>
        </div>
      </div>
    }>
      <SuccessClient />
    </Suspense>
  );
}