module.exports=[27572,__turbopack_context__=>{"use strict";var __TURBOPACK__imported__module__7997__=__turbopack_context__.i(7997);function RootLayout({children}){return(0,__TURBOPACK__imported__module__7997__.jsxs)("html",{lang:"en",children:[(0,__TURBOPACK__imported__module__7997__.jsxs)("head",{children:[(0,__TURBOPACK__imported__module__7997__.jsx)("link",{rel:"preconnect",href:"https://fonts.googleapis.com"}),(0,__TURBOPACK__imported__module__7997__.jsx)("link",{rel:"preconnect",href:"https://fonts.gstatic.com",crossOrigin:"anonymous"}),(0,__TURBOPACK__imported__module__7997__.jsx)("link",{href:"https://fonts.googleapis.com/css2?family=Geist:wght@400;500;600;700&family=Geist+Mono:wght@400;500;600&family=Source+Serif+4:ital,opsz,wght@0,8..60,400;0,8..60,600;1,8..60,400&display=swap",rel:"stylesheet"}),(0,__TURBOPACK__imported__module__7997__.jsx)("script",{dangerouslySetInnerHTML:{__html:`
              (function () {
                try {
                  var stored = localStorage.getItem('bm-theme');
                  var theme = stored || 'system';
                  var dark = theme === 'dark' || (theme === 'system' && window.matchMedia('(prefers-color-scheme: dark)').matches);
                  document.documentElement.setAttribute('data-theme', dark ? 'dark' : 'light');
                } catch (e) {
                  document.documentElement.setAttribute('data-theme', 'light');
                }
              })();
            `}})]}),(0,__TURBOPACK__imported__module__7997__.jsx)("body",{children:children})]})}__turbopack_context__.s(["default",0,RootLayout,"metadata",0,{title:"CvSU-Imus DCS SFMS",description:"Collect and analyze stakeholder feedback."}])},50645,__turbopack_context__=>{__turbopack_context__.n(__turbopack_context__.i(27572))}];

//# sourceMappingURL=src_app_layout_tsx_0r5yz5t._.js.map