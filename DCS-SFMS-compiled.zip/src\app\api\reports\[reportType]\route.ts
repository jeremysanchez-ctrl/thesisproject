import { NextRequest, NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';
import { requireAuth } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import type { Prisma } from '@prisma/client';
import type { jsPDF as JsPDF } from 'jspdf';

type FullForm = Prisma.SurveyFormGetPayload<{
  include: {
    event: true;
    Questions: { orderBy: { order: 'asc' } };
    Responses: {
      include: { stakeholderCategory: true; Answers: { include: { question: true } } };
      orderBy: { submittedAt: 'desc' };
    };
  };
}>;

type AutoTableDoc = JsPDF & { lastAutoTable: { finalY: number } };

const tableEndY = (doc: JsPDF) => (doc as AutoTableDoc).lastAutoTable.finalY;

const allowedFormats = new Set(['pdf', 'xlsx', 'csv']);

export async function GET(request: NextRequest, context: { params: Promise<{ reportType: string }> }) {
  const session = await requireAuth();
  if (!['SUPER_ADMIN', 'ADMIN', 'QA_OFFICER', 'DEPT_HEAD'].includes(session.role)) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
  }

  const { reportType } = await context.params;
  if (!['summary', 'stakeholder'].includes(reportType)) {
    return NextResponse.json({ error: 'Unknown report type' }, { status: 404 });
  }

  // Enforce approval workflow for non-super-admins
  if (session.role !== 'SUPER_ADMIN') {
    const dbType = reportType === 'summary' ? 'Summary Report' : 'Detailed Response Export';
    const activeRequest = await prisma.reportRequest.findFirst({
      where: { requestedBy: session.userId, status: 'APPROVED', reportType: dbType }
    });
    if (!activeRequest) {
      return NextResponse.json({ error: 'Forbidden. You must have an approved report request first.' }, { status: 403 });
    }
  }

  const format = request.nextUrl.searchParams.get('format') ?? 'pdf';
  const formId = request.nextUrl.searchParams.get('formId');

  if (!allowedFormats.has(format)) {
    return NextResponse.json({ error: 'Unknown report format' }, { status: 400 });
  }

  if (!formId) {
    return NextResponse.json({ error: 'A formId parameter is required.' }, { status: 400 });
  }

  // Load the specific form with its questions and responses
  const form = await prisma.surveyForm.findUnique({
    where: { id: formId },
    include: {
      event: true,
      Questions: { orderBy: { order: 'asc' } },
      Responses: {
        where: { isArchived: false },
        include: {
          stakeholderCategory: true,
          Answers: { include: { question: true } }
        },
        orderBy: { submittedAt: 'desc' }
      }
    }
  });

  if (!form) {
    return NextResponse.json({ error: 'Form not found.' }, { status: 404 });
  }

  const filename = `dcs-sfms-${reportType}-${form.event.name.replace(/[^a-z0-9]/gi, '_')}.${format}`;

  if (reportType === 'summary') {
    if (format === 'pdf') return createSummaryPdf(form, filename);
    const rows = buildSummaryExportRows(form);
    if (format === 'xlsx') return createWorkbook(rows, filename);
    return createCsv(rows, filename);
  }

  // Detailed stakeholder report
  if (format === 'pdf') return createDetailedPdf(form, filename);
  const rows = buildDetailedExportRows(form);
  if (format === 'xlsx') return createWorkbook(rows, filename);
  return createCsv(rows, filename);
}

// ─── SUMMARY PDF ────────────────────────────────────────────────────────────
async function createSummaryPdf(form: FullForm, filename: string) {
  const { jsPDF } = await import('jspdf');
  const { default: autoTable } = await import('jspdf-autotable');

  const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
  const responses = form.Responses;
  const likertQuestions = form.Questions.filter((q) => q.questionType === 'LIKERT' || q.questionType === 'RATING');
  const total = responses.length;

  // Score breakdown per Likert question (1–5 scale)
  const scoreMap: Record<string, { 5: number; 4: number; 3: number; 2: number; 1: number; total: number }> = {};
  for (const q of likertQuestions) {
    scoreMap[q.id] = { 5: 0, 4: 0, 3: 0, 2: 0, 1: 0, total: 0 };
  }

  let totalScoreSum = 0;
  let totalScoreCount = 0;

  for (const resp of responses) {
    for (const ans of resp.Answers) {
      const entry = scoreMap[ans.questionId];
      if (!entry) continue;
      const numericMatch = ans.answerValue.match(/^([1-5])/);
      if (numericMatch) {
        const score = parseInt(numericMatch[1], 10) as 1 | 2 | 3 | 4 | 5;
        entry[score]++;
        entry.total++;
        totalScoreSum += score;
        totalScoreCount++;
      }
    }
  }

  const avg = totalScoreCount > 0 ? (totalScoreSum / totalScoreCount).toFixed(2) : '0.00';
  const pct = (val: number, t: number = total) => t > 0 ? `${(val / t * 100).toFixed(1)}%` : '0.0%';

  // ─── HEADER ────────────────────────────────────────────────────────────────
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.text('Republic of the Philippines', 105, 12, { align: 'center' });
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(12);
  doc.text('CAVITE STATE UNIVERSITY', 105, 17, { align: 'center' });
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10);
  doc.text('Imus Campus', 105, 22, { align: 'center' });
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.text('Imus City, Cavite', 105, 26, { align: 'center' });

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.text('SUMMARY OF RESULTS — STAKEHOLDERS\' FEEDBACK FORM', 105, 34, { align: 'center' });
  doc.setLineWidth(0.5);
  doc.line(14, 37, 196, 37);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.text(`Office/Unit: Department of Computer Studies (DCS) — ${form.event.department}`, 14, 43);
  doc.text(`Survey Form: ${form.title}`, 14, 48);
  doc.text(`Event: ${form.event.name}`, 14, 53);
  doc.text(`Period: ${form.academicYear ?? ''} — ${form.semester ?? ''}`, 14, 58);
  doc.text(`Total Respondents: ${total}`, 120, 43);
  doc.text(`Overall Avg. Score: ${avg} / 5.00`, 120, 48);
  doc.text(`Generated: ${new Date().toLocaleString('en-PH')}`, 120, 53);

  doc.line(14, 62, 196, 62);

  // ─── SATISFACTION TABLE ────────────────────────────────────────────────────
  let currentY = 66;

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10);
  doc.text('Area of Concern — Satisfaction Rating Summary', 14, currentY);
  currentY += 4;

  const tableBody = likertQuestions.map((q, idx: number) => {
    const s = scoreMap[q.id];
    const avgScore = s.total > 0 ? (( s[5] * 5 + s[4] * 4 + s[3] * 3 + s[2] * 2 + s[1] * 1) / s.total).toFixed(2) : '—';
    return [
      `${String.fromCharCode(65 + idx)}. ${q.questionText}`,
      String(s[5]),
      String(s[4]),
      String(s[3]),
      String(s[2]),
      String(s[1]),
      String(s.total),
      avgScore,
    ];
  });

  // Add totals row
  const totals5 = likertQuestions.reduce((acc: number, q) => acc + scoreMap[q.id][5], 0);
  const totals4 = likertQuestions.reduce((acc: number, q) => acc + scoreMap[q.id][4], 0);
  const totals3 = likertQuestions.reduce((acc: number, q) => acc + scoreMap[q.id][3], 0);
  const totals2 = likertQuestions.reduce((acc: number, q) => acc + scoreMap[q.id][2], 0);
  const totals1 = likertQuestions.reduce((acc: number, q) => acc + scoreMap[q.id][1], 0);

  autoTable(doc, {
    startY: currentY,
    head: [[
      'Area of Concern',
      'Highly Satisfied (5)',
      'Very Satisfied (4)',
      'Moderately Satisfied (3)',
      'Barely Satisfied (2)',
      'Not Satisfied (1)',
      'Total',
      'Avg. Score',
    ]],
    body: [
      ...tableBody,
      [
        { content: 'TOTAL', styles: { fontStyle: 'bold' } },
        { content: String(totals5), styles: { fontStyle: 'bold', halign: 'center' } },
        { content: String(totals4), styles: { fontStyle: 'bold', halign: 'center' } },
        { content: String(totals3), styles: { fontStyle: 'bold', halign: 'center' } },
        { content: String(totals2), styles: { fontStyle: 'bold', halign: 'center' } },
        { content: String(totals1), styles: { fontStyle: 'bold', halign: 'center' } },
        { content: String(totalScoreCount), styles: { fontStyle: 'bold', halign: 'center' } },
        { content: avg, styles: { fontStyle: 'bold', halign: 'center' } },
      ]
    ],
    theme: 'grid',
    headStyles: { fillColor: [255, 255, 255], textColor: [0, 0, 0], fontStyle: 'bold', halign: 'center', lineColor: [0, 0, 0], lineWidth: 0.3 },
    styles: { fontSize: 8, cellPadding: 2, textColor: [0, 0, 0], lineColor: [0, 0, 0], lineWidth: 0.2 },
    columnStyles: {
      0: { cellWidth: 65, halign: 'left' },
      1: { halign: 'center' },
      2: { halign: 'center' },
      3: { halign: 'center' },
      4: { halign: 'center' },
      5: { halign: 'center' },
      6: { halign: 'center' },
      7: { halign: 'center' },
    },
  });

  currentY = tableEndY(doc) + 8;

  // ─── DEMOGRAPHICS ──────────────────────────────────────────────────────────
  // Sex distribution
  let maleCount = 0, femaleCount = 0;
  const purposeMap: Record<string, number> = {};
  const categoryMap: Record<string, number> = {};
  const deptMap: Record<string, number> = {};

  for (const resp of responses) {
    const sex = (resp.sex || '').toLowerCase();
    if (sex.includes('male') || sex === 'lalaki') maleCount++;
    else if (sex.includes('female') || sex === 'babae') femaleCount++;

    const purpose = resp.purposeOfVisit || 'Not specified';
    purposeMap[purpose] = (purposeMap[purpose] || 0) + 1;

    const cat = resp.stakeholderCategory?.name || 'Other';
    categoryMap[cat] = (categoryMap[cat] || 0) + 1;

    if (resp.department) {
      deptMap[resp.department] = (deptMap[resp.department] || 0) + 1;
    }
  }

  // Check if we need a new page
  if (currentY > 200) { doc.addPage(); currentY = 15; }

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10);
  doc.text('Respondent Demographics', 14, currentY);
  currentY += 4;

  const departmentRows = Object.keys(deptMap).length > 0 ? [
    [{ content: 'Department', colSpan: 3, styles: { fontStyle: 'bold' as const, fillColor: [240, 240, 240] as [number, number, number] } }],
    ...Object.entries(deptMap).map(([dept, count]) => [dept, String(count), pct(count)]),
  ] : [];

  autoTable(doc, {
    startY: currentY,
    head: [['Category', 'Count', 'Percentage']],
    body: [
      ...departmentRows,
      [{ content: 'Sex', colSpan: 3, styles: { fontStyle: 'bold', fillColor: [240, 240, 240] } }],
      ['Male', String(maleCount), pct(maleCount)],
      ['Female', String(femaleCount), pct(femaleCount)],
      [{ content: 'Stakeholder Category', colSpan: 3, styles: { fontStyle: 'bold', fillColor: [240, 240, 240] } }],
      ...Object.entries(categoryMap).map(([cat, count]) => [cat, String(count), pct(count)]),
      [{ content: 'Purpose of Visit', colSpan: 3, styles: { fontStyle: 'bold', fillColor: [240, 240, 240] } }],
      ...Object.entries(purposeMap).slice(0, 8).map(([purpose, count]) => [purpose, String(count), pct(count)]),
    ],
    theme: 'grid',
    headStyles: { fillColor: [255, 255, 255], textColor: [0, 0, 0], fontStyle: 'bold', halign: 'center', lineColor: [0, 0, 0], lineWidth: 0.3 },
    styles: { fontSize: 8, cellPadding: 2, textColor: [0, 0, 0], lineColor: [0, 0, 0], lineWidth: 0.2 },
    columnStyles: { 0: { cellWidth: 100 }, 1: { halign: 'center' }, 2: { halign: 'center' } },
  });

  currentY = tableEndY(doc) + 12;

  // ─── COMMENTS / TEXT ANSWERS ───────────────────────────────────────────────
  const commentRows: string[][] = [];
  for (const resp of responses) {
    for (const ans of resp.Answers) {
      const q = form.Questions.find((fq) => fq.id === ans.questionId);
      if (q?.questionType === 'TEXT' && ans.answerValue.trim()) {
        commentRows.push([
          resp.controlNo || '—',
          q.questionText,
          ans.answerValue,
        ]);
      }
    }
  }

  if (commentRows.length > 0) {
    if (currentY > 220) { doc.addPage(); currentY = 15; }
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(10);
    doc.text('Open-Ended Comments / Suggestions', 14, currentY);
    currentY += 4;

    autoTable(doc, {
      startY: currentY,
      head: [['Control No.', 'Question', 'Response']],
      body: commentRows,
      theme: 'grid',
      headStyles: { fillColor: [255, 255, 255], textColor: [0, 0, 0], fontStyle: 'bold', lineColor: [0, 0, 0], lineWidth: 0.3 },
      styles: { fontSize: 7.5, cellPadding: 2, textColor: [0, 0, 0], lineColor: [0, 0, 0], lineWidth: 0.2 },
      columnStyles: { 0: { cellWidth: 25 }, 1: { cellWidth: 60 }, 2: { cellWidth: 97 } },
    });
    currentY = tableEndY(doc) + 12;
  }

  // ─── SIGNATURE BLOCK ───────────────────────────────────────────────────────
  if (currentY > 240) { doc.addPage(); currentY = 15; }

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.text('Prepared by:', 14, currentY + 10);
  doc.text('_______________________________', 14, currentY + 22);
  doc.setFont('helvetica', 'bold');
  doc.text('Authorized Signatory', 14, currentY + 27);
  doc.setFont('helvetica', 'normal');
  doc.text('Date: ____________________', 14, currentY + 33);

  doc.text('Noted by:', 110, currentY + 10);
  doc.text('_______________________________', 110, currentY + 22);
  doc.setFont('helvetica', 'bold');
  doc.text('GRACE S. IBAÑEZ', 110, currentY + 27);
  doc.setFont('helvetica', 'normal');
  doc.text('Department Chair, Dept. of Computer Studies', 110, currentY + 32);

  const buf = doc.output('arraybuffer');
  return new NextResponse(buf, {
    headers: {
      'Content-Type': 'application/pdf',
      'Content-Disposition': `attachment; filename="${filename}"`,
    },
  });
}

// ─── DETAILED PDF (matching the Stakeholders' Feedback Form photo) ──────────
async function createDetailedPdf(form: FullForm, filename: string) {
  const { jsPDF } = await import('jspdf');

  const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
  const responses = form.Responses;
  const likertQuestions = form.Questions.filter((q) => q.questionType === 'LIKERT' || q.questionType === 'RATING');
  const textQuestions = form.Questions.filter((q) => q.questionType === 'TEXT');

  const RATINGS = [
    { label: 'Highly Satisfied', value: '5' },
    { label: 'Very Satisfied', value: '4' },
    { label: 'Moderately Satisfied', value: '3' },
    { label: 'Barely Satisfied', value: '2' },
    { label: 'Not Satisfied', value: '1' },
  ];

  responses.forEach((resp, pageIdx: number) => {
    if (pageIdx > 0) doc.addPage();

    // Build answer map
    const answerMap: Record<string, string> = {};
    for (const ans of resp.Answers) {
      answerMap[ans.questionId] = ans.answerValue;
    }

    let y = 10;

    // ─── FORM HEADER ────────────────────────────────────────────────────────
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7);
    doc.text('HRDO-QF-07', 190, y, { align: 'right' });

    doc.setFontSize(8);
    doc.text('Republic of the Philippines', 105, y, { align: 'center' });
    y += 5;
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(11);
    doc.text('CAVITE STATE UNIVERSITY', 105, y, { align: 'center' });
    y += 5;
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9);
    doc.text('Imus Campus', 105, y, { align: 'center' });
    y += 4;
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.text('Imus City, Cavite', 105, y, { align: 'center' });
    y += 6;

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(10);
    doc.text("STAKEHOLDERS' FEEDBACK FORM", 105, y, { align: 'center' });
    y += 5;
    doc.setLineWidth(0.3);
    doc.line(14, y, 196, y);
    y += 4;

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7.5);
    const intro = 'Please let us know how we can improve our service by giving your honest feedback. We value our stakeholders, hence, your comments and suggestions will be highly appreciated.';
    const introLines = doc.splitTextToSize(intro, 180);
    doc.text(introLines, 14, y);
    y += introLines.length * 4 + 3;

    // ─── RESPONDENT INFO FIELDS ──────────────────────────────────────────────
    doc.setFontSize(8);
    const fieldStartY = y;

    // Row 1: Department (and Hard Copy Photo indicator if present)
    doc.setFont('helvetica', 'bold');
    doc.text('Department:', 14, fieldStartY);
    doc.setFont('helvetica', 'normal');
    const deptLineEnd = resp.hardCopyPhotoUrl ? 130 : 196;
    doc.line(38, fieldStartY + 0.5, deptLineEnd, fieldStartY + 0.5);
    doc.text(resp.department || '—', 39, fieldStartY);

    if (resp.hardCopyPhotoUrl) {
      doc.setFont('helvetica', 'bold');
      doc.text('Hard Copy:', 134, fieldStartY);
      doc.setFont('helvetica', 'normal');
      doc.line(152, fieldStartY + 0.5, 196, fieldStartY + 0.5);
      doc.text('Photo Attached', 153, fieldStartY);
    }

    const infoLeft = [
      ['Name:', resp.name || ''],
      ['Agency:', resp.agency || resp.organization || ''],
      ['Email Address:', resp.email || ''],
    ];
    const infoRight = [
      ['Date of Visit:', resp.dateOfVisit || ''],
      ['Attending Staff:', resp.attendingStaff || ''],
      ['Purpose of Visit:', resp.purposeOfVisit || ''],
    ];

    infoLeft.forEach((row, i) => {
      const fy = fieldStartY + (i + 1) * 5.5;
      doc.setFont('helvetica', 'bold');
      doc.text(row[0], 14, fy);
      doc.setFont('helvetica', 'normal');
      doc.line(38, fy + 0.5, 105, fy + 0.5);
      doc.text(row[1], 39, fy);
    });

    infoRight.forEach((row, i) => {
      const fy = fieldStartY + (i + 1) * 5.5;
      doc.setFont('helvetica', 'bold');
      doc.text(row[0], 110, fy);
      doc.setFont('helvetica', 'normal');
      doc.line(136, fy + 0.5, 196, fy + 0.5);
      doc.text(row[1], 137, fy);
    });

    y = fieldStartY + (infoLeft.length + 1) * 5.5 + 4;
    doc.line(14, y, 196, y);
    y += 5;

    // ─── RATING COLUMN HEADERS ──────────────────────────────────────────────
    const colXs = [115, 132, 150, 165, 180];  // x positions for 5,4,3,2,1 columns
    const colW = 14;
    const areaColW = 99;

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7.5);
    doc.text('Area of Concern', 16, y);

    RATINGS.forEach((r, i) => {
      doc.text(r.label, colXs[i] + colW / 2, y - 2, { align: 'center' });
      doc.text(r.value, colXs[i] + colW / 2, y + 2.5, { align: 'center' });
    });

    y += 5;
    doc.setLineWidth(0.2);
    doc.line(14, y, 196, y);
    y += 3;

    // ─── LIKERT QUESTION ROWS ──────────────────────────────────────────────
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);

    likertQuestions.forEach((q, qi: number) => {
      const label = `${String.fromCharCode(65 + qi)}. ${q.questionText}`;
      const lines = doc.splitTextToSize(label, areaColW - 6);
      const rowH = Math.max(lines.length * 4.5, 8);

      // Draw row background alternating
      if (qi % 2 === 1) {
        doc.setFillColor(248, 250, 252);
        doc.rect(14, y - 1, 182, rowH + 2, 'F');
      }

      doc.setTextColor(0, 0, 0);
      doc.text(lines, 16, y + 3);

      // Get answer value for this question
      const answerVal = answerMap[q.id] || '';
      const selectedScore = answerVal.match(/^([1-5])/)?.[1] || '';

      // Draw checkbox for each rating column
      RATINGS.forEach((r, ri) => {
        const cx = colXs[ri] + colW / 2;
        const cy = y + rowH / 2;
        const boxSize = 4;

        doc.setLineWidth(0.4);
        doc.rect(cx - boxSize / 2, cy - boxSize / 2, boxSize, boxSize);

        if (selectedScore === r.value) {
          // Draw checkmark / X inside the box
          doc.setLineWidth(0.6);
          doc.line(cx - 1.5, cy, cx - 0.2, cy + 1.5);
          doc.line(cx - 0.2, cy + 1.5, cx + 1.8, cy - 1.5);
        }
      });

      y += rowH + 3;

      if (y > 260) {
        doc.addPage();
        y = 15;
      }
    });

    doc.setLineWidth(0.2);
    doc.line(14, y, 196, y);
    y += 5;

    // ─── COMMENTS / TEXT QUESTIONS ───────────────────────────────────────────
    for (const tq of textQuestions) {
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(8);
      doc.text(`${tq.questionText}:`, 14, y);
      const ansText = answerMap[tq.id] || '';
      doc.setFont('helvetica', 'normal');
      doc.line(50, y + 0.5, 196, y + 0.5);
      if (ansText) {
        const commentLines = doc.splitTextToSize(ansText, 144);
        doc.text(commentLines, 52, y);
        y += commentLines.length * 4 + 2;
      } else {
        y += 6;
      }
      doc.line(14, y, 196, y);
      y += 4;
    }

    // ─── E-SIGNATURE (if provided) ──────────────────────────────────────────
    const sigUrl = resp.signatureUrl;
    if (sigUrl) {
      const cleanSig = sigUrl.replace(/^\//, '');
      const sigDiskPath = path.join(process.cwd(), 'public', cleanSig);
      if (fs.existsSync(sigDiskPath)) {
        try {
          const sigBuffer = fs.readFileSync(sigDiskPath);
          const sigBase64 = `data:image/png;base64,${sigBuffer.toString('base64')}`;
          if (y > 250) {
            doc.addPage();
            y = 20;
          }
          doc.setFont('helvetica', 'bold');
          doc.setFontSize(8);
          doc.text('Respondent Signature:', 14, y + 6);
          doc.addImage(sigBase64, 'PNG', 50, y, 40, 15);
          y += 18;
        } catch {
          // Ignore image embed errors
        }
      }
    }

    // ─── FOOTER ────────────────────────────────────────────────────────────
    doc.setFontSize(7);
    doc.setFont('helvetica', 'normal');
    doc.text(`Control No: ${resp.controlNo || '—'}`, 14, 285);
    doc.text('V01-2018-06-19', 196, 285, { align: 'right' });

    // ─── HARD COPY PHOTO ATTACHMENT PAGE (if uploaded) ─────────────────────
    if (resp.hardCopyPhotoUrl) {
      const cleanRel = resp.hardCopyPhotoUrl.replace(/^\//, '');
      const photoDiskPath = path.join(process.cwd(), 'public', cleanRel);
      if (fs.existsSync(photoDiskPath)) {
        try {
          doc.addPage();
          doc.setFont('helvetica', 'bold');
          doc.setFontSize(10);
          doc.text(`ATTACHED HARD COPY PHOTO — Control No: ${resp.controlNo || '—'}`, 105, 14, { align: 'center' });
          doc.setFont('helvetica', 'normal');
          doc.setFontSize(8);
          doc.text(`Respondent: ${resp.name || 'Anonymous'} | Department: ${resp.department || '—'} | Date: ${resp.dateOfVisit || '—'}`, 105, 19, { align: 'center' });
          doc.setLineWidth(0.3);
          doc.line(14, 22, 196, 22);

          const imgBuffer = fs.readFileSync(photoDiskPath);
          const base64Data = imgBuffer.toString('base64');
          const ext = path.extname(photoDiskPath).toLowerCase();
          const format = ext === '.png' ? 'PNG' : 'JPEG';
          doc.addImage(`data:image/${format === 'PNG' ? 'png' : 'jpeg'};base64,${base64Data}`, format, 14, 25, 182, 250, undefined, 'FAST');
        } catch (imgErr) {
          console.error('Failed to attach hard copy photo to PDF report:', imgErr);
        }
      }
    }
  });

  const buf = doc.output('arraybuffer');
  return new NextResponse(buf, {
    headers: {
      'Content-Type': 'application/pdf',
      'Content-Disposition': `attachment; filename="${filename}"`,
    },
  });
}

// ─── EXPORT ROW BUILDERS ─────────────────────────────────────────────────────
function buildSummaryExportRows(form: FullForm) {
  const likertQuestions = form.Questions.filter((q) => q.questionType === 'LIKERT' || q.questionType === 'RATING');
  const rows: Record<string, unknown>[] = [];

  for (const q of likertQuestions) {
    const counts: Record<string, number> = { 5: 0, 4: 0, 3: 0, 2: 0, 1: 0 };
    let total = 0;
    let scoreSum = 0;

    for (const resp of form.Responses) {
      for (const ans of resp.Answers) {
        if (ans.questionId === q.id) {
          const m = ans.answerValue.match(/^([1-5])/);
          if (m) {
            const s = parseInt(m[1], 10);
            counts[s]++;
            total++;
            scoreSum += s;
          }
        }
      }
    }

    rows.push({
      'Form': form.title,
      'Event': form.event.name,
      'Question': q.questionText,
      'Highly Satisfied (5)': counts[5],
      'Very Satisfied (4)': counts[4],
      'Moderately Satisfied (3)': counts[3],
      'Barely Satisfied (2)': counts[2],
      'Not Satisfied (1)': counts[1],
      'Total Responses': total,
      'Average Score': total > 0 ? (scoreSum / total).toFixed(2) : '—',
    });
  }
  return rows;
}

function buildDetailedExportRows(form: FullForm) {
  const rows: Record<string, unknown>[] = [];
  for (const resp of form.Responses) {
    const baseRow = {
      'Control No': resp.controlNo ?? '',
      'Department': resp.department ?? '',
      'Hard Copy Photo': resp.hardCopyPhotoUrl ?? 'None',
      'Date of Visit': resp.dateOfVisit ?? '',
      'Name': resp.name ?? '',
      'Agency': resp.agency ?? '',
      'Email': resp.email ?? '',
      'Contact': resp.contactNumber ?? '',
      'Sex': resp.sex ?? '',
      'Age': resp.age ?? '',
      'Purpose of Visit': resp.purposeOfVisit ?? '',
      'Attending Staff': resp.attendingStaff ?? '',
      'Stakeholder Category': resp.stakeholderCategory?.name ?? '',
    };

    if (resp.Answers.length === 0) {
      rows.push({
        ...baseRow,
        'Question': resp.hardCopyPhotoUrl ? 'Hard Copy Form Attached' : 'N/A',
        'Answer': resp.hardCopyPhotoUrl ? 'See Attached Photo' : 'N/A',
      });
    } else {
      for (const ans of resp.Answers) {
        rows.push({
          ...baseRow,
          'Question': ans.question?.questionText ?? '',
          'Answer': ans.answerValue,
        });
      }
    }
  }
  return rows;
}

// ─── UTILITY FUNCTIONS ───────────────────────────────────────────────────────
function createCsv(rows: Array<Record<string, unknown>>, filename: string) {
  const columns = Object.keys(rows[0] ?? { notice: 'No records available' });
  const lines = [columns.join(',')];
  for (const row of rows) {
    lines.push(columns.map(c => escapeCsv(row[c])).join(','));
  }
  return new NextResponse(lines.join('\n'), {
    headers: {
      'Content-Type': 'text/csv; charset=utf-8',
      'Content-Disposition': `attachment; filename="${filename}"`,
    },
  });
}

async function createWorkbook(rows: Array<Record<string, unknown>>, filename: string) {
  const XLSX = await import('xlsx');
  const worksheet = XLSX.utils.json_to_sheet(rows);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Report');
  const buffer = XLSX.write(workbook, { type: 'buffer', bookType: 'xlsx' }) as Buffer;
  return new NextResponse(Uint8Array.from(buffer), {
    headers: {
      'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'Content-Disposition': `attachment; filename="${filename}"`,
    },
  });
}

function escapeCsv(value: unknown) {
  const text = String(value ?? '');
  if (!/[",\n\r]/.test(text)) return text;
  return `"${text.replaceAll('"', '""')}"`;
}
